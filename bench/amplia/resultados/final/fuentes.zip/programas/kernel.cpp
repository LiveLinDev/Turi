#include <cstdint>
#include <vector>
static int64_t v_val(int64_t v_i, int64_t v_s) {
    int64_t v_x = (((v_i * 73) + (v_s * 101)) % 1009);
    return ((((v_x * v_x) + (17 * v_x)) + 19) % 1009);
}

static int64_t v_low(int64_t v_x, int64_t v_y) {
    if (v_x < v_y) {
        return v_x;
    }
    return v_y;
}

static int64_t v_high(int64_t v_x, int64_t v_y) {
    if (v_x > v_y) {
        return v_x;
    }
    return v_y;
}

static int64_t v_dist(int64_t v_x, int64_t v_y) {
    if (v_x >= v_y) {
        return (v_x - v_y);
    }
    return (v_y - v_x);
}

static int64_t v_euclidBatch(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_a = (v_val(v_i, v_s) + 1);
        int64_t v_b = (v_i + 19);
        while (v_b > 0) {
            int64_t v_r = (v_a % v_b);
            v_a = v_b;
            v_b = v_r;
        }
        v_total = v_total + v_a;
    }
    return v_total;
}

static int64_t v_primeTrial(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_a = ((v_i + v_s) + 2);
        int64_t v_d = 2;
        while (((v_d * v_d) <= v_a) && ((v_a % v_d) != 0)) {
            v_d = v_d + 1;
        }
        if ((v_d * v_d) > v_a) {
            v_total = v_total + 1;
        }
    }
    return v_total;
}

static int64_t v_modularPower(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_e = v_val(v_i, v_s);
        int64_t v_b = (v_i + 3);
        int64_t v_v = 1;
        while (v_e > 0) {
            if ((v_e % 2) == 1) {
                v_v = ((v_v * v_b) % 65521);
            }
            v_b = ((v_b * v_b) % 65521);
            v_e = (v_e / 2);
        }
        v_total = v_total + v_v;
    }
    return v_total;
}

static int64_t v_newtonRoot(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_a = (((v_i + v_s) * 97) + 1);
        int64_t v_x = v_a;
        int64_t v_y = ((v_x + 1) / 2);
        while (v_y < v_x) {
            v_x = v_y;
            v_y = ((v_x + (v_a / v_x)) / 2);
        }
        v_total = v_total + v_x;
    }
    return v_total;
}

static int64_t v_digitSum(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_a = ((v_i + 1) * (v_s + 1));
        while (v_a > 0) {
            v_total = v_total + (v_a % 10);
            v_a = (v_a / 10);
        }
    }
    return v_total;
}

static int64_t v_binomialRows(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_a = (((v_i + v_s) % 27) + 1);
        int64_t v_v = 1;
        for (int64_t v_j = 1; v_j < (v_a + 1); ++v_j) {
            v_v = ((v_v * ((v_a + 1) - v_j)) / v_j);
            v_total = v_total + v_v;
        }
    }
    return v_total;
}

static int64_t v_factorMultiplicity(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = (v_val(v_i, v_s) + 1);
        int64_t v_d = 2;
        while ((v_d * v_d) <= v_x) {
            while ((v_x % v_d) == 0) {
                v_total = v_total + 1;
                v_x = (v_x / v_d);
            }
            v_d = v_d + 1;
        }
        if (v_x > 1) {
            v_total = v_total + 1;
        }
    }
    return v_total;
}

static int64_t v_binaryOnes(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = ((v_val(v_i, v_s) * 177) + v_i);
        while (v_x > 0) {
            v_total = v_total + (v_x % 2);
            v_x = (v_x / 2);
        }
    }
    return v_total;
}

static int64_t v_totientBatch(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = (v_val(v_i, v_s) + 1);
        int64_t v_phi = v_x;
        int64_t v_d = 2;
        while ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_phi = v_phi - (v_phi / v_d);
                while ((v_x % v_d) == 0) {
                    v_x = (v_x / v_d);
                }
            }
            v_d = v_d + 1;
        }
        if (v_x > 1) {
            v_phi = v_phi - (v_phi / v_x);
        }
        v_total = v_total + v_phi;
    }
    return v_total;
}

static int64_t v_divisorsPaired(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = (v_val(v_i, v_s) + 1);
        int64_t v_d = 1;
        while ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_total = v_total + v_d;
                if ((v_d * v_d) != v_x) {
                    v_total = v_total + (v_x / v_d);
                }
            }
            v_d = v_d + 1;
        }
    }
    return v_total;
}

static int64_t v_affineStream(int64_t v_n, int64_t v_s) {
    int64_t v_x = v_s;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_x = (((v_x * 48271) + 1) % 2147483647);
    }
    return v_x;
}

static int64_t v_fibonacciMod(int64_t v_n, int64_t v_s) {
    int64_t v_a = 0;
    int64_t v_b = v_s;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_c = ((v_a + v_b) % 65521);
        v_a = v_b;
        v_b = v_c;
    }
    return v_b;
}

static int64_t v_adlerStream(int64_t v_n, int64_t v_s) {
    int64_t v_a = 1;
    int64_t v_b = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_a = ((v_a + (v_val(v_i, v_s) % 256)) % 65521);
        v_b = ((v_b + v_a) % 65521);
    }
    return ((v_b * 65536) + v_a);
}

static int64_t v_polynomialHash(int64_t v_n, int64_t v_s) {
    int64_t v_h = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_h = (((v_h * 257) + v_val(v_i, v_s)) % 1000003);
    }
    return v_h;
}

static int64_t v_exponentialFilter(int64_t v_n, int64_t v_s) {
    int64_t v_state = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_state = (((v_state * 7) + (v_val(v_i, v_s) * 8)) / 8);
    }
    return v_state;
}

static int64_t v_hysteresis(int64_t v_n, int64_t v_s) {
    int64_t v_state = 0;
    int64_t v_transitions = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_v = v_val(v_i, v_s);
        if ((v_state == 0) && (v_v > 765)) {
            v_state = 1;
            v_transitions = v_transitions + 1;
        }
        if ((v_state == 1) && (v_v < 201)) {
            v_state = 0;
        }
    }
    return v_transitions;
}

static int64_t v_longestStreak(int64_t v_n, int64_t v_s) {
    int64_t v_streak = 0;
    int64_t v_best = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if ((v_val(v_i, v_s) % 3) != 0) {
            v_streak = v_streak + 1;
            v_best = v_high(v_best, v_streak);
        } else {
            v_streak = 0;
        }
    }
    return v_best;
}

static int64_t v_majorityVote(int64_t v_n, int64_t v_s) {
    int64_t v_balance = 0;
    int64_t v_candidate = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_v = (v_val(v_i, v_s) % 7);
        if (v_balance == 0) {
            v_candidate = v_v;
        }
        if (v_candidate == v_v) {
            v_balance = v_balance + 1;
        } else {
            v_balance = v_balance - 1;
        }
    }
    return ((v_candidate * 100) + v_balance);
}

static int64_t v_crossingCount(int64_t v_n, int64_t v_s) {
    int64_t v_prev = (v_s % 1009);
    int64_t v_count = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = v_val(v_i, v_s);
        if ((v_prev <= 500) && (v_x > 500)) {
            v_count = v_count + 1;
        }
        v_prev = v_x;
    }
    return v_count;
}

static int64_t v_cumulativeDrawdown(int64_t v_n, int64_t v_s) {
    int64_t v_price = 1000;
    int64_t v_peak = v_price;
    int64_t v_draw = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_price = v_price + ((v_val(v_i, v_s) % 31) - 15);
        v_peak = v_high(v_peak, v_price);
        v_draw = v_high(v_draw, (v_peak - v_price));
    }
    return v_draw;
}

static int64_t v_insertionSort(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    for (int64_t v_i = 1; v_i < v_n; ++v_i) {
        int64_t v_v = v_a[v_i];
        int64_t v_j = v_i;
        while ((v_j > 0) && (v_a[(v_j - 1)] > v_v)) {
            v_a[v_j] = v_a[(v_j - 1)];
            v_j = v_j - 1;
        }
        v_a[v_j] = v_v;
    }
    return (v_a[(v_n / 3)] + v_a[(v_n - 1)]);
}

static int64_t v_selectionSort(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_k = v_i;
        for (int64_t v_j = (v_i + 1); v_j < v_n; ++v_j) {
            if (v_a[v_j] < v_a[v_k]) {
                v_k = v_j;
            }
        }
        int64_t v_v = v_a[v_k];
        v_a[v_k] = v_a[v_i];
        v_a[v_i] = v_v;
    }
    return (v_a[(v_n / 2)] + v_a[0]);
}

static int64_t v_bubbleEarly(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_edge = v_n;
    while (v_edge > 1) {
        int64_t v_last = 0;
        for (int64_t v_j = 1; v_j < v_edge; ++v_j) {
            if (v_a[(v_j - 1)] > v_a[v_j]) {
                int64_t v_v = v_a[v_j];
                v_a[v_j] = v_a[(v_j - 1)];
                v_a[(v_j - 1)] = v_v;
                v_last = v_j;
            }
        }
        v_edge = v_last;
    }
    return (v_a[(v_n / 4)] + v_a[(v_n - 1)]);
}

static int64_t v_shellSort(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_gap = (v_n / 2);
    while (v_gap > 0) {
        for (int64_t v_i = v_gap; v_i < v_n; ++v_i) {
            int64_t v_v = v_a[v_i];
            int64_t v_j = v_i;
            while ((v_j >= v_gap) && (v_a[(v_j - v_gap)] > v_v)) {
                v_a[v_j] = v_a[(v_j - v_gap)];
                v_j = v_j - v_gap;
            }
            v_a[v_j] = v_v;
        }
        v_gap = (v_gap / 2);
    }
    return v_a[(v_n / 2)];
}

static int64_t v_countingRank(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_h(1009, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_h[v_a[v_i]] = v_h[v_a[v_i]] + 1;
    }
    int64_t v_rank = (v_n / 2);
    int64_t v_v = 0;
    while (v_rank >= v_h[v_v]) {
        v_rank = v_rank - v_h[v_v];
        v_v = v_v + 1;
    }
    return v_v;
}

static int64_t v_lowerBound(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_a[v_i] = ((v_i * 3) + (v_i / 5));
    }
    int64_t v_t = 0;
    for (int64_t v_j = 0; v_j < (v_n / 4); ++v_j) {
        int64_t v_x = ((v_val(v_j, v_s) * 31) % (v_n * 4));
        int64_t v_lo = 0;
        int64_t v_hi = v_n;
        while (v_lo < v_hi) {
            int64_t v_mid = ((v_lo + v_hi) / 2);
            if (v_a[v_mid] < v_x) {
                v_lo = (v_mid + 1);
            } else {
                v_hi = v_mid;
            }
        }
        v_t = v_t + v_lo;
    }
    return v_t;
}

static int64_t v_sentinelFind(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n + 1), 0);
    for (int64_t ix = 0; ix < (v_n + 1); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_q = 0; v_q < 40; ++v_q) {
        int64_t v_x = v_val((v_q + v_n), v_s);
        v_a[v_n] = v_x;
        int64_t v_j = 0;
        while (v_a[v_j] != v_x) {
            v_j = v_j + 1;
        }
        v_t = v_t + v_j;
    }
    return v_t;
}

static int64_t v_partitionPivot(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_pivot = v_a[(v_n / 2)];
    int64_t v_left = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if (v_a[v_i] < v_pivot) {
            int64_t v_v = v_a[v_left];
            v_a[v_left] = v_a[v_i];
            v_a[v_i] = v_v;
            v_left = v_left + 1;
        }
    }
    return (v_left + v_a[(v_n / 2)]);
}

static int64_t v_mergeRuns(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    std::vector<int64_t> v_b(v_n, 0);
    int64_t v_x = 0;
    int64_t v_y = 0;
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_x = v_x + (v_val(v_i, v_s) % 7);
        v_y = v_y + (v_val((v_i + 3), v_s) % 11);
        v_a[v_i] = v_x;
        v_b[v_i] = v_y;
    }
    int64_t v_l = 0;
    int64_t v_r = 0;
    for (int64_t v_k = 0; v_k < (v_n * 2); ++v_k) {
        if ((v_r == v_n) || ((v_l < v_n) && (v_a[v_l] <= v_b[v_r]))) {
            v_t = v_t + (v_a[v_l] * (v_k % 7));
            v_l = v_l + 1;
        } else {
            v_t = v_t + (v_b[v_r] * (v_k % 7));
            v_r = v_r + 1;
        }
    }
    return v_t;
}

static int64_t v_heapBuild(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_i = (v_n / 2);
    while (v_i > 0) {
        v_i = v_i - 1;
        int64_t v_root = v_i;
        int64_t v_child = ((2 * v_root) + 1);
        while (v_child < v_n) {
            if (((v_child + 1) < v_n) && (v_a[(v_child + 1)] > v_a[v_child])) {
                v_child = v_child + 1;
            }
            if (v_a[v_root] >= v_a[v_child]) {
                v_child = v_n;
            } else {
                int64_t v_v = v_a[v_root];
                v_a[v_root] = v_a[v_child];
                v_a[v_child] = v_v;
                v_root = v_child;
                v_child = ((2 * v_root) + 1);
            }
        }
    }
    return (v_a[0] + v_a[(v_n / 3)]);
}

static int64_t v_reverseBuffer(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    for (int64_t v_i = 0; v_i < (v_n / 2); ++v_i) {
        int64_t v_j = ((v_n - 1) - v_i);
        int64_t v_t = v_a[v_i];
        v_a[v_i] = v_a[v_j];
        v_a[v_j] = v_t;
    }
    int64_t v_total = 0;
    for (int64_t v_k = 0; v_k < v_n; ++v_k) {
        v_total = v_total + (v_a[v_k] * (v_k % 11));
    }
    return v_total;
}

static int64_t v_rotateCycles(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = v_a[(v_n - 1)];
    for (int64_t v_i = 1; v_i < v_n; ++v_i) {
        v_a[(v_n - v_i)] = v_a[((v_n - v_i) - 1)];
    }
    v_a[0] = v_t;
    int64_t v_total = 0;
    for (int64_t v_j = 0; v_j < v_n; ++v_j) {
        v_total = v_total + (v_a[v_j] * (v_j % 17));
    }
    return v_total;
}

static int64_t v_strideGather(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    int64_t v_pos = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_t = v_t + v_a[v_pos];
        v_pos = ((v_pos + 61) % v_n);
    }
    return v_t;
}

static int64_t v_permutedScatter(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    int64_t v_j = (v_s % v_n);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_a[v_j] = (v_i + 1);
        v_j = ((v_j + 31) % v_n);
    }
    int64_t v_t = 0;
    for (int64_t v_k = 0; v_k < v_n; ++v_k) {
        v_t = v_t + (v_a[v_k] * (v_k % 5));
    }
    return v_t;
}

static int64_t v_chainedLoads(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_a[v_i] = ((v_a[v_i] + (v_i * 59)) % v_n);
    }
    int64_t v_p = (v_s % v_n);
    int64_t v_t = 0;
    for (int64_t v_j = 0; v_j < v_n; ++v_j) {
        v_p = v_a[v_p];
        v_t = v_t + v_p;
    }
    return v_t;
}

static int64_t v_copyIsolation(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b = v_a;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if ((v_i % 3) == 0) {
            v_b[v_i] = (v_a[v_i] + v_i);
        }
    }
    int64_t v_t = 0;
    for (int64_t v_j = 0; v_j < v_n; ++v_j) {
        v_t = v_t + ((v_b[v_j] * 3) - v_a[v_j]);
    }
    return v_t;
}

static int64_t v_scopeChurn(int64_t v_n, int64_t v_s) {
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_width = ((v_val(v_i, v_s) % 377) + 4);
        std::vector<int64_t> v_a(v_width, v_i);
        for (int64_t v_j = 0; v_j < v_width; ++v_j) {
            v_a[v_j] = ((v_a[v_j] + (v_j * 17)) % 173);
        }
        v_t = v_t + v_a[((v_i + v_s) % v_width)];
    }
    return v_t;
}

static int64_t v_compactStable(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_write = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if ((v_a[v_i] % 3) == 0) {
            v_a[v_write] = v_a[v_i];
            v_write = v_write + 1;
        }
    }
    int64_t v_t = 0;
    for (int64_t v_j = 0; v_j < v_write; ++v_j) {
        v_t = v_t + (v_a[v_j] * (v_j % 5));
    }
    return v_t;
}

static int64_t v_interleaveBuffers(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    std::vector<int64_t> v_c((v_n * 2), 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_c[(2 * v_i)] = v_a[v_i];
        v_c[((2 * v_i) + 1)] = v_b[v_i];
    }
    int64_t v_t = 0;
    for (int64_t v_j = 1; v_j < (v_n * 2); ++v_j) {
        v_t = v_t + v_dist(v_c[v_j], v_c[(v_j - 1)]);
    }
    return v_t;
}

static int64_t v_sparsePages(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, v_s);
    for (int64_t v_i = 0; v_i < ((v_n + 511) / 512); ++v_i) {
        v_a[(v_i * 512)] = v_val(v_i, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_k = 0; v_k < v_n; ++v_k) {
        v_t = v_t + v_a[v_k];
    }
    return v_t;
}

static int64_t v_dotProduct(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_t = v_t + (v_a[v_i] * v_b[v_i]);
    }
    return v_t;
}

static int64_t v_integerVariance(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_t = v_t + v_a[v_i];
    }
    int64_t v_mean = (v_t / v_n);
    int64_t v_v = 0;
    for (int64_t v_j = 0; v_j < v_n; ++v_j) {
        int64_t v_d = (v_a[v_j] - v_mean);
        v_v = v_v + (v_d * v_d);
    }
    return v_v;
}

static int64_t v_frequencyMode(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(257, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_a[(v_val(v_i, v_s) % 257)] = v_a[(v_val(v_i, v_s) % 257)] + 1;
    }
    int64_t v_best = 0;
    for (int64_t v_k = 1; v_k < 257; ++v_k) {
        if (v_a[v_k] > v_a[v_best]) {
            v_best = v_k;
        }
    }
    return v_best;
}

static int64_t v_slidingWindow(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_window = 0;
    int64_t v_best = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_window = v_window + v_a[v_i];
        if (v_i >= 23) {
            v_window = v_window - v_a[(v_i - 23)];
        }
        v_best = v_high(v_best, v_window);
    }
    return v_best;
}

static int64_t v_prefixQueries(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n + 1), 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_a[(v_i + 1)] = (v_a[v_i] + v_val(v_i, v_s));
    }
    int64_t v_t = 0;
    for (int64_t v_j = 0; v_j < (v_n / 4); ++v_j) {
        int64_t v_lo = (v_val(v_j, v_s) % v_n);
        int64_t v_hi = (v_lo + (v_val((v_j + 1), v_s) % (v_n - v_lo)));
        v_t = v_t + (v_a[(v_hi + 1)] - v_a[v_lo]);
    }
    return v_t;
}

static int64_t v_minmaxSpan(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_mn = v_a[0];
    int64_t v_mx = v_a[0];
    for (int64_t v_i = 1; v_i < v_n; ++v_i) {
        v_mn = v_low(v_mn, v_a[v_i]);
        v_mx = v_high(v_mx, v_a[v_i]);
    }
    return (v_mx - v_mn);
}

static int64_t v_normalizedCov(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_b[ix] = v_val(ix, (v_s + 2));
    }
    int64_t v_x = 0;
    int64_t v_y = 0;
    int64_t v_xy = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_x = v_x + v_a[v_i];
        v_y = v_y + v_b[v_i];
        v_xy = v_xy + (v_a[v_i] * v_b[v_i]);
    }
    return ((v_n * v_xy) - (v_x * v_y));
}

static int64_t v_lowpassMedian(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_total = 0;
    for (int64_t v_i = 2; v_i < v_n; ++v_i) {
        int64_t v_x = v_low(v_a[v_i], v_a[(v_i - 1)]);
        int64_t v_y = v_high(v_a[v_i], v_a[(v_i - 1)]);
        v_total = v_total + v_high(v_x, v_low(v_a[(v_i - 2)], v_y));
    }
    return v_total;
}

static int64_t v_lagCorrelation(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    int64_t v_lag = ((v_s % 23) + 1);
    for (int64_t v_i = v_lag; v_i < v_n; ++v_i) {
        v_t = v_t + ((v_a[v_i] - 500) * (v_a[(v_i - v_lag)] - 500));
    }
    return v_t;
}

static int64_t v_trimmedThreshold(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    int64_t v_count = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if ((v_a[v_i] >= 100) && (v_a[v_i] < 900)) {
            v_t = v_t + v_a[v_i];
            v_count = v_count + 1;
        }
    }
    return (v_t / (v_count + 1));
}

static int64_t v_matrixMultiply(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        for (int64_t v_j = 0; v_j < v_n; ++v_j) {
            int64_t v_v = 0;
            for (int64_t v_k = 0; v_k < v_n; ++v_k) {
                v_v = v_v + (v_a[((v_i * v_n) + v_k)] * v_b[((v_k * v_n) + v_j)]);
            }
            v_t = v_t + (v_v % 101);
        }
    }
    return v_t;
}

static int64_t v_matrixTranspose(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b((v_n * v_n), 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        for (int64_t v_j = 0; v_j < v_n; ++v_j) {
            v_b[((v_j * v_n) + v_i)] = v_a[((v_i * v_n) + v_j)];
        }
    }
    int64_t v_t = 0;
    for (int64_t v_k = 0; v_k < (v_n * v_n); ++v_k) {
        v_t = v_t + (v_b[v_k] * (v_k % 13));
    }
    return v_t;
}

static int64_t v_fivePoint(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_i = 1; v_i < (v_n - 1); ++v_i) {
        for (int64_t v_j = 1; v_j < (v_n - 1); ++v_j) {
            int64_t v_p = ((v_i * v_n) + v_j);
            v_t = v_t + (((((v_a[v_p] + v_a[(v_p - 1)]) + v_a[(v_p + 1)]) + v_a[(v_p - v_n)]) + v_a[(v_p + v_n)]) / 5);
        }
    }
    return v_t;
}

static int64_t v_sobelHorizontal(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_i = 1; v_i < (v_n - 1); ++v_i) {
        for (int64_t v_j = 1; v_j < (v_n - 1); ++v_j) {
            int64_t v_p = ((v_i * v_n) + v_j);
            int64_t v_l = ((v_a[((v_p - v_n) - 1)] + (v_a[(v_p - 1)] * 2)) + v_a[((v_p + v_n) - 1)]);
            int64_t v_r = ((v_a[((v_p - v_n) + 1)] + (v_a[(v_p + 1)] * 2)) + v_a[((v_p + v_n) + 1)]);
            v_t = v_t + v_dist(v_l, v_r);
        }
    }
    return v_t;
}

static int64_t v_summedArea(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_p(((v_n + 1) * (v_n + 1)), 0);
    int64_t v_w = (v_n + 1);
    for (int64_t v_i = 1; v_i < v_w; ++v_i) {
        int64_t v_row = 0;
        for (int64_t v_j = 1; v_j < v_w; ++v_j) {
            v_row = v_row + v_val(((v_i * v_w) + v_j), v_s);
            v_p[((v_i * v_w) + v_j)] = (v_row + v_p[(((v_i - 1) * v_w) + v_j)]);
        }
    }
    return (v_p[((v_n * v_w) + v_n)] + v_p[(((v_n / 2) * v_w) + (v_n / 3))]);
}

static int64_t v_lifeOneStep(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_alive = 0;
    for (int64_t v_i = 1; v_i < (v_n - 1); ++v_i) {
        for (int64_t v_j = 1; v_j < (v_n - 1); ++v_j) {
            int64_t v_p = ((v_i * v_n) + v_j);
            int64_t v_count = 0;
            for (int64_t v_y = 0; v_y < 3; ++v_y) {
                for (int64_t v_x = 0; v_x < 3; ++v_x) {
                    if ((v_y != 1) || (v_x != 1)) {
                        v_count = v_count + (v_a[(((v_p + ((v_y - 1) * v_n)) + v_x) - 1)] % 2);
                    }
                }
            }
            if ((v_count == 3) || ((v_count == 2) && ((v_a[v_p] % 2) == 1))) {
                v_alive = v_alive + 1;
            }
        }
    }
    return v_alive;
}

static int64_t v_diagonalEnergy(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_d = 0; v_d < v_n; ++v_d) {
        int64_t v_v = 0;
        for (int64_t v_i = 0; v_i < (v_n - v_d); ++v_i) {
            v_v = v_v + v_a[(((v_i * v_n) + v_i) + v_d)];
        }
        v_t = v_t + (v_v * v_v);
    }
    return v_t;
}

static int64_t v_triangularSolve(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_x(v_n, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_v = v_val(v_i, v_s);
        for (int64_t v_j = 0; v_j < v_i; ++v_j) {
            v_v = v_v + ((v_val((v_i + v_j), v_s) % 5) * v_x[v_j]);
        }
        v_x[v_i] = (v_v % 997);
    }
    return v_x[(v_n - 1)];
}

static int64_t v_rowNormalize(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_mx = 1;
        for (int64_t v_j = 0; v_j < v_n; ++v_j) {
            v_mx = v_high(v_mx, v_a[((v_i * v_n) + v_j)]);
        }
        for (int64_t v_k = 0; v_k < v_n; ++v_k) {
            v_t = v_t + ((v_a[((v_i * v_n) + v_k)] * 255) / v_mx);
        }
    }
    return v_t;
}

static int64_t v_maxPool(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < (v_n / 2); ++v_i) {
        for (int64_t v_j = 0; v_j < (v_n / 2); ++v_j) {
            int64_t v_p = (((2 * v_i) * v_n) + (2 * v_j));
            v_t = v_t + v_high(v_high(v_a[v_p], v_a[(v_p + 1)]), v_high(v_a[(v_p + v_n)], v_a[((v_p + v_n) + 1)]));
        }
    }
    return v_t;
}

static int64_t v_editDistance(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    std::vector<int64_t> v_d((v_n + 1), 0);
    for (int64_t v_j = 0; v_j < (v_n + 1); ++v_j) {
        v_d[v_j] = v_j;
    }
    for (int64_t v_i = 1; v_i < (v_n + 1); ++v_i) {
        int64_t v_diag = v_d[0];
        v_d[0] = v_i;
        for (int64_t v_k = 1; v_k < (v_n + 1); ++v_k) {
            int64_t v_old = v_d[v_k];
            int64_t v_cost = 0;
            if ((v_a[(v_i - 1)] % 7) != (v_b[(v_k - 1)] % 7)) {
                v_cost = 1;
            }
            v_d[v_k] = v_low((v_low(v_d[(v_k - 1)], v_old) + 1), (v_diag + v_cost));
            v_diag = v_old;
        }
    }
    return v_d[v_n];
}

static int64_t v_commonSubsequence(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_b(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_b[ix] = v_val(ix, (v_s + 2));
    }
    std::vector<int64_t> v_d((v_n + 1), 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_diag = 0;
        for (int64_t v_j = 1; v_j < (v_n + 1); ++v_j) {
            int64_t v_old = v_d[v_j];
            if ((v_a[v_i] % 11) == (v_b[(v_j - 1)] % 11)) {
                v_d[v_j] = (v_diag + 1);
            } else {
                v_d[v_j] = v_high(v_d[v_j], v_d[(v_j - 1)]);
            }
            v_diag = v_old;
        }
    }
    return v_d[v_n];
}

static int64_t v_knapsack(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_d((v_n + 1), 0);
    for (int64_t v_i = 0; v_i < 48; ++v_i) {
        int64_t v_w = ((v_val(v_i, v_s) % 37) + 1);
        int64_t v_price = (v_val((v_i + 1), v_s) % 89);
        int64_t v_j = v_n;
        while (v_j >= v_w) {
            v_d[v_j] = v_high(v_d[v_j], (v_d[(v_j - v_w)] + v_price));
            v_j = v_j - 1;
        }
    }
    return v_d[v_n];
}

static int64_t v_coinMinimum(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_d((v_n + 1), (v_n + 1));
    v_d[0] = 0;
    for (int64_t v_i = 1; v_i < (v_n + 1); ++v_i) {
        v_d[v_i] = (v_d[(v_i - 1)] + 1);
        for (int64_t v_j = 0; v_j < 5; ++v_j) {
            int64_t v_c = ((v_val(v_j, v_s) % 33) + 1);
            if (v_i >= v_c) {
                v_d[v_i] = v_low(v_d[v_i], (v_d[(v_i - v_c)] + 1));
            }
        }
    }
    return v_d[v_n];
}

static int64_t v_increasingSubseq(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    std::vector<int64_t> v_d(v_n, 1);
    int64_t v_best = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        for (int64_t v_j = 0; v_j < v_i; ++v_j) {
            if (v_a[v_j] < v_a[v_i]) {
                v_d[v_i] = v_high(v_d[v_i], (v_d[v_j] + 1));
            }
        }
        v_best = v_high(v_best, v_d[v_i]);
    }
    return v_best;
}

static int64_t v_gridMinPath(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_d(v_n, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        for (int64_t v_j = 0; v_j < v_n; ++v_j) {
            int64_t v_v = v_val(((v_i * v_n) + v_j), v_s);
            if (v_j == 0) {
                v_d[v_j] = v_d[v_j] + v_v;
            } else {
                if (v_i == 0) {
                    v_d[v_j] = (v_d[(v_j - 1)] + v_v);
                } else {
                    v_d[v_j] = (v_low(v_d[v_j], v_d[(v_j - 1)]) + v_v);
                }
            }
        }
    }
    return v_d[(v_n - 1)];
}

static int64_t v_maxNonAdjacent(int64_t v_n, int64_t v_s) {
    int64_t v_prev = 0;
    int64_t v_best = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_take = (v_prev + v_val(v_i, v_s));
        v_prev = v_best;
        v_best = v_high(v_best, v_take);
    }
    return v_best;
}

static int64_t v_rodCut(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_d((v_n + 1), 0);
    std::vector<int64_t> v_price((v_n + 1), 0);
    for (int64_t ix = 0; ix < (v_n + 1); ++ix) {
        v_price[ix] = v_val(ix, v_s);
    }
    for (int64_t v_i = 1; v_i < (v_n + 1); ++v_i) {
        for (int64_t v_j = 1; v_j < (v_i + 1); ++v_j) {
            v_d[v_i] = v_high(v_d[v_i], (v_price[v_j] + v_d[(v_i - v_j)]));
        }
    }
    return v_d[v_n];
}

static int64_t v_segmentGain(int64_t v_n, int64_t v_s) {
    int64_t v_best = 0;
    int64_t v_current = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_current = v_high(0, ((v_current + v_val(v_i, v_s)) - 503));
        v_best = v_high(v_best, v_current);
    }
    return v_best;
}

static int64_t v_subsetReach(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_d((v_n + 1), 0);
    v_d[0] = 1;
    for (int64_t v_i = 0; v_i < 30; ++v_i) {
        int64_t v_w = ((v_val(v_i, v_s) % 70) + 1);
        int64_t v_j = v_n;
        while (v_j >= v_w) {
            if (v_d[(v_j - v_w)] == 1) {
                v_d[v_j] = 1;
            }
            v_j = v_j - 1;
        }
    }
    int64_t v_total = 0;
    for (int64_t v_k = 0; v_k < (v_n + 1); ++v_k) {
        v_total = v_total + v_d[v_k];
    }
    return v_total;
}

static int64_t v_unionFind(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_p(v_n, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_p[v_i] = v_i;
    }
    int64_t v_joined = 0;
    for (int64_t v_j = 0; v_j < v_n; ++v_j) {
        int64_t v_a = (((v_j * 37) + v_s) % v_n);
        int64_t v_b = (((v_j * 19) + v_val(v_j, v_s)) % v_n);
        while (v_p[v_a] != v_a) {
            v_p[v_a] = v_p[v_p[v_a]];
            v_a = v_p[v_a];
        }
        while (v_p[v_b] != v_b) {
            v_b = v_p[v_b];
        }
        if (v_a != v_b) {
            v_p[v_a] = v_b;
            v_joined = v_joined + 1;
        }
    }
    return v_joined;
}

static int64_t v_fenwickUpdateQuery(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_tree((v_n + 1), 0);
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_k = (v_i + 1);
        int64_t v_bit = 1;
        while ((v_k % (v_bit * 2)) == 0) {
            v_bit = v_bit * 2;
        }
        v_tree[v_k] = v_tree[v_k] + v_val(v_i, v_s);
        int64_t v_parent = (v_k + v_bit);
        if (v_parent <= v_n) {
            v_tree[v_parent] = v_tree[v_parent] + v_tree[v_k];
        }
        if ((v_k % 17) == 0) {
            v_t = v_t + v_tree[v_k];
        }
    }
    return (v_t + v_tree[v_n]);
}

static int64_t v_ringQueue(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_q(127, 0);
    int64_t v_head = 0;
    int64_t v_tail = 0;
    int64_t v_count = 0;
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = v_val(v_i, v_s);
        if ((v_count == 0) || ((v_count < 127) && ((v_x % 3) != 0))) {
            v_q[v_tail] = v_x;
            v_tail = ((v_tail + 1) % 127);
            v_count = v_count + 1;
        } else {
            v_t = v_t + v_q[v_head];
            v_head = ((v_head + 1) % 127);
            v_count = v_count - 1;
        }
    }
    return (v_t + v_count);
}

static int64_t v_monotoneStack(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_st(v_n, 0);
    int64_t v_size = 0;
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = v_val(v_i, v_s);
        while ((v_size > 0) && (v_st[(v_size - 1)] <= v_x)) {
            v_size = v_size - 1;
        }
        if (v_size > 0) {
            v_t = v_t + v_st[(v_size - 1)];
        }
        v_st[v_size] = v_x;
        v_size = v_size + 1;
    }
    return v_t;
}

static int64_t v_openAddress(int64_t v_n, int64_t v_s) {
    int64_t v_cap = ((2 * v_n) + 1);
    std::vector<int64_t> v_slots(v_cap, 0);
    int64_t v_probes = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_key = (((v_i * 231) + v_val(v_i, v_s)) + 1);
        int64_t v_p = (v_key % v_cap);
        while (v_slots[v_p] != 0) {
            v_probes = v_probes + 1;
            v_p = ((v_p + 1) % v_cap);
        }
        v_slots[v_p] = v_key;
    }
    return (v_probes + v_slots[(v_s % v_cap)]);
}

static int64_t v_floydDistances(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_d((v_n * v_n), 0);
    for (int64_t ix = 0; ix < (v_n * v_n); ++ix) {
        v_d[ix] = v_val(ix, v_s);
    }
    for (int64_t v_k = 0; v_k < v_n; ++v_k) {
        for (int64_t v_i = 0; v_i < v_n; ++v_i) {
            for (int64_t v_j = 0; v_j < v_n; ++v_j) {
                int64_t v_p = ((v_i * v_n) + v_j);
                v_d[v_p] = v_low(v_d[v_p], (v_d[((v_i * v_n) + v_k)] + v_d[((v_k * v_n) + v_j)]));
            }
        }
    }
    return (v_d[(v_s % v_n)] + v_d[((v_n * v_n) - 1)]);
}

static int64_t v_breadthFirst(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_seen(v_n, 0);
    std::vector<int64_t> v_q(v_n, 0);
    v_q[0] = (v_s % v_n);
    v_seen[v_q[0]] = 1;
    int64_t v_head = 0;
    int64_t v_tail = 1;
    int64_t v_t = 0;
    while (v_head < v_tail) {
        int64_t v_v = v_q[v_head];
        v_head = v_head + 1;
        for (int64_t v_j = 0; v_j < 2; ++v_j) {
            int64_t v_w = ((((v_v * (v_j + 2)) + v_j) + 1) % v_n);
            if (v_seen[v_w] == 0) {
                v_seen[v_w] = (v_seen[v_v] + 1);
                v_q[v_tail] = v_w;
                v_tail = v_tail + 1;
                v_t = v_t + v_seen[v_w];
            }
        }
    }
    return v_t;
}

static int64_t v_treeFold(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_i = (v_n - 1);
    while (v_i > 0) {
        v_a[((v_i - 1) / 2)] = v_a[((v_i - 1) / 2)] + v_a[v_i];
        v_i = v_i - 1;
    }
    return (v_a[0] + v_a[(v_n / 7)]);
}

static int64_t v_sparseEdges(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_target(v_n, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        for (int64_t v_j = 0; v_j < 3; ++v_j) {
            int64_t v_dst = ((((v_i * 17) + (v_j * 29)) + v_s) % v_n);
            v_target[v_dst] = v_target[v_dst] + (v_val((v_i + v_j), v_s) % 19);
        }
    }
    int64_t v_t = 0;
    for (int64_t v_k = 0; v_k < v_n; ++v_k) {
        v_t = v_t + (v_target[v_k] * (v_k % 11));
    }
    return v_t;
}

static int64_t v_intervalSweep(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_hits((v_n + 1), 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_start = ((v_val(v_i, v_s) + v_i) % v_n);
        int64_t v_end = v_low(v_n, ((v_start + (v_val((v_i + 1), v_s) % 41)) + 1));
        v_hits[v_start] = v_hits[v_start] + 1;
        v_hits[v_end] = v_hits[v_end] - 1;
    }
    int64_t v_active = 0;
    int64_t v_best = 0;
    for (int64_t v_k = 0; v_k < v_n; ++v_k) {
        v_active = v_active + v_hits[v_k];
        v_best = v_high(v_active, v_best);
    }
    return v_best;
}

static int64_t v_luhnDigits(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_d = (v_val(v_i, v_s) % 10);
        if ((v_i % 2) == 1) {
            v_d = v_d * 2;
            if (v_d > 9) {
                v_d = v_d - 9;
            }
        }
        v_total = v_total + v_d;
    }
    return (v_total % 10);
}

static int64_t v_runLengths(int64_t v_n, int64_t v_s) {
    int64_t v_prev = (-1);
    int64_t v_size = 0;
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_v = (v_val(v_i, v_s) % 3);
        if (v_v == v_prev) {
            v_size = v_size + 1;
        } else {
            v_t = v_t + (v_size * v_size);
            v_size = 1;
            v_prev = v_v;
        }
    }
    return (v_t + (v_size * v_size));
}

static int64_t v_varintLength(int64_t v_n, int64_t v_s) {
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = ((v_i + v_val(v_i, v_s)) * (v_s + 1));
        v_t = v_t + 1;
        while (v_x >= 128) {
            v_t = v_t + 1;
            v_x = (v_x / 128);
        }
    }
    return v_t;
}

static int64_t v_decimalFields(int64_t v_n, int64_t v_s) {
    int64_t v_value = 0;
    int64_t v_total = 0;
    int64_t v_digits = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_token = (v_val(v_i, v_s) % 13);
        if ((v_token < 10) && (v_digits < 8)) {
            v_value = ((v_value * 10) + v_token);
            v_digits = v_digits + 1;
        } else {
            v_total = v_total + v_value;
            v_value = 0;
            v_digits = 0;
        }
    }
    return (v_total + v_value);
}

static int64_t v_csvQuoted(int64_t v_n, int64_t v_s) {
    int64_t v_quoted = 0;
    int64_t v_fields = 1;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_c = (v_val(v_i, v_s) % 17);
        if (v_c == 0) {
            v_quoted = (1 - v_quoted);
        }
        if ((v_c == 1) && (v_quoted == 0)) {
            v_fields = v_fields + 1;
        }
    }
    return v_fields;
}

static int64_t v_bracketDepth(int64_t v_n, int64_t v_s) {
    int64_t v_depth = 0;
    int64_t v_errors = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_k = (v_val(v_i, v_s) % 5);
        if (v_k == 0) {
            v_depth = v_depth + 1;
        }
        if (v_k == 1) {
            if (v_depth == 0) {
                v_errors = v_errors + 1;
            } else {
                v_depth = v_depth - 1;
            }
        }
    }
    return (v_errors + v_depth);
}

static int64_t v_utf8Widths(int64_t v_n, int64_t v_s) {
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_cp = (((v_val(v_i, v_s) * 1237) + v_i) % 1114112);
        int64_t v_width = 1;
        if (v_cp >= 128) {
            v_width = v_width + 1;
        }
        if (v_cp >= 2048) {
            v_width = v_width + 1;
        }
        if (v_cp >= 65536) {
            v_width = v_width + 1;
        }
        v_total = v_total + v_width;
    }
    return v_total;
}

static int64_t v_patternAutomaton(int64_t v_n, int64_t v_s) {
    int64_t v_state = 0;
    int64_t v_hits = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = (v_val(v_i, v_s) % 3);
        if (v_x == 0) {
            if (v_state == 2) {
                v_hits = v_hits + 1;
            }
            v_state = 1;
        } else {
            if ((v_x == 1) && (v_state == 1)) {
                v_state = 2;
            } else {
                v_state = 0;
            }
        }
    }
    return v_hits;
}

static int64_t v_zigzagDelta(int64_t v_n, int64_t v_s) {
    int64_t v_last = 0;
    int64_t v_total = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = v_val(v_i, v_s);
        int64_t v_d = (v_x - v_last);
        if (v_d < 0) {
            v_total = v_total + (((0 - v_d) * 2) - 1);
        } else {
            v_total = v_total + (v_d * 2);
        }
        v_last = v_x;
    }
    return v_total;
}

static int64_t v_packedNibbles(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < (v_n / 2); ++v_i) {
        int64_t v_byte = (((v_a[(2 * v_i)] % 16) * 16) + (v_a[((2 * v_i) + 1)] % 16));
        v_t = v_t + (v_byte * ((v_i % 7) + 1));
    }
    return v_t;
}

static int64_t v_tokenBucket(int64_t v_n, int64_t v_s) {
    int64_t v_credit = 65;
    int64_t v_ok = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        v_credit = v_low(100, (v_credit + 5));
        int64_t v_request = (v_val(v_i, v_s) % 16);
        if (v_credit >= v_request) {
            v_credit = v_credit - v_request;
            v_ok = v_ok + 1;
        }
    }
    return v_ok;
}

static int64_t v_orderBookLevel(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_bids(128, 0);
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = v_val(v_i, v_s);
        int64_t v_index = (v_x % 128);
        if ((v_x % 3) == 0) {
            int64_t v_used = v_low(v_bids[v_index], (v_x % 19));
            v_bids[v_index] = v_bids[v_index] - v_used;
            v_t = v_t + v_used;
        } else {
            v_bids[v_index] = v_bids[v_index] + (v_x % 23);
        }
    }
    return v_t;
}

static int64_t v_roundRobin(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_budget(17, 0);
    for (int64_t v_i = 0; v_i < 17; ++v_i) {
        v_budget[v_i] = (v_val(v_i, v_s) + 1);
    }
    int64_t v_served = 0;
    int64_t v_p = 0;
    for (int64_t v_j = 0; v_j < v_n; ++v_j) {
        int64_t v_take = v_low(13, v_budget[v_p]);
        v_served = v_served + v_take;
        v_budget[v_p] = v_budget[v_p] - v_take;
        if (v_budget[v_p] == 0) {
            v_budget[v_p] = (v_val(v_j, v_s) + 1);
        }
        v_p = ((v_p + 1) % 17);
    }
    return v_served;
}

static int64_t v_inventoryReorder(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_stock(61, 20);
    int64_t v_orders = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_k = (v_val(v_i, v_s) % 61);
        v_stock[v_k] = v_stock[v_k] - (v_i % 5);
        if (v_stock[v_k] < 5) {
            v_stock[v_k] = v_stock[v_k] + 24;
            v_orders = v_orders + 1;
        }
    }
    return v_orders;
}

static int64_t v_thermostat(int64_t v_n, int64_t v_s) {
    int64_t v_temp = 190;
    int64_t v_power = 0;
    int64_t v_consumed = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if (v_temp < 184) {
            v_power = 1;
        }
        if (v_temp > 211) {
            v_power = 0;
        }
        v_temp = v_temp + ((v_power * 5) - (v_val(v_i, v_s) % 6));
        v_consumed = v_consumed + v_power;
    }
    return v_consumed;
}

static int64_t v_resampleLinear(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_a(v_n, 0);
    for (int64_t ix = 0; ix < v_n; ++ix) {
        v_a[ix] = v_val(ix, v_s);
    }
    int64_t v_t = 0;
    for (int64_t v_j = 0; v_j < ((v_n * 3) - 3); ++v_j) {
        int64_t v_p = (v_j / 3);
        int64_t v_fraction = (v_j % 3);
        v_t = v_t + (((v_a[v_p] * (3 - v_fraction)) + (v_a[(v_p + 1)] * v_fraction)) / 3);
    }
    return v_t;
}

static int64_t v_envelopeFollower(int64_t v_n, int64_t v_s) {
    int64_t v_env = 0;
    int64_t v_t = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_x = v_val(v_i, v_s);
        if (v_x > v_env) {
            v_env = v_env + (((v_x - v_env) + 1) / 2);
        } else {
            v_env = v_env - ((v_env - v_x) / 8);
        }
        v_t = v_t + v_env;
    }
    return v_t;
}

static int64_t v_telemetryBuckets(int64_t v_n, int64_t v_s) {
    std::vector<int64_t> v_b(11, 0);
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_v = (v_val(v_i, v_s) + 1);
        int64_t v_level = 0;
        while (v_v > 1) {
            v_v = (v_v / 2);
            v_level = v_level + 1;
        }
        v_b[v_level] = v_b[v_level] + 1;
    }
    int64_t v_target = ((v_n * 9) / 10);
    int64_t v_k = 0;
    while (v_target > v_b[v_k]) {
        v_target = v_target - v_b[v_k];
        v_k = v_k + 1;
    }
    return v_k;
}

static int64_t v_backoffSimulation(int64_t v_n, int64_t v_s) {
    int64_t v_delay = 1;
    int64_t v_elapsed = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        if ((v_val(v_i, v_s) % 4) != 0) {
            v_delay = 1;
        } else {
            v_delay = v_low(128, (v_delay * 2));
        }
        v_elapsed = v_elapsed + v_delay;
    }
    return v_elapsed;
}

static int64_t v_packetJitter(int64_t v_n, int64_t v_s) {
    int64_t v_previous = 0;
    int64_t v_jitter = 0;
    for (int64_t v_i = 0; v_i < v_n; ++v_i) {
        int64_t v_transit = (v_val(v_i, v_s) % 127);
        int64_t v_delta = v_dist(v_transit, v_previous);
        v_jitter = (((15 * v_jitter) + (16 * v_delta)) / 16);
        v_previous = v_transit;
    }
    return v_jitter;
}

static int64_t v_group0(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 0) {
        return v_euclidBatch(v_n, v_s);
    }
    if (v_id == 1) {
        return v_primeTrial(v_n, v_s);
    }
    if (v_id == 2) {
        return v_modularPower(v_n, v_s);
    }
    if (v_id == 3) {
        return v_newtonRoot(v_n, v_s);
    }
    if (v_id == 4) {
        return v_digitSum(v_n, v_s);
    }
    if (v_id == 5) {
        return v_binomialRows(v_n, v_s);
    }
    if (v_id == 6) {
        return v_factorMultiplicity(v_n, v_s);
    }
    if (v_id == 7) {
        return v_binaryOnes(v_n, v_s);
    }
    if (v_id == 8) {
        return v_totientBatch(v_n, v_s);
    }
    if (v_id == 9) {
        return v_divisorsPaired(v_n, v_s);
    }
    return 0;
}

static int64_t v_group1(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 10) {
        return v_affineStream(v_n, v_s);
    }
    if (v_id == 11) {
        return v_fibonacciMod(v_n, v_s);
    }
    if (v_id == 12) {
        return v_adlerStream(v_n, v_s);
    }
    if (v_id == 13) {
        return v_polynomialHash(v_n, v_s);
    }
    if (v_id == 14) {
        return v_exponentialFilter(v_n, v_s);
    }
    if (v_id == 15) {
        return v_hysteresis(v_n, v_s);
    }
    if (v_id == 16) {
        return v_longestStreak(v_n, v_s);
    }
    if (v_id == 17) {
        return v_majorityVote(v_n, v_s);
    }
    if (v_id == 18) {
        return v_crossingCount(v_n, v_s);
    }
    if (v_id == 19) {
        return v_cumulativeDrawdown(v_n, v_s);
    }
    return 0;
}

static int64_t v_group2(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 20) {
        return v_insertionSort(v_n, v_s);
    }
    if (v_id == 21) {
        return v_selectionSort(v_n, v_s);
    }
    if (v_id == 22) {
        return v_bubbleEarly(v_n, v_s);
    }
    if (v_id == 23) {
        return v_shellSort(v_n, v_s);
    }
    if (v_id == 24) {
        return v_countingRank(v_n, v_s);
    }
    if (v_id == 25) {
        return v_lowerBound(v_n, v_s);
    }
    if (v_id == 26) {
        return v_sentinelFind(v_n, v_s);
    }
    if (v_id == 27) {
        return v_partitionPivot(v_n, v_s);
    }
    if (v_id == 28) {
        return v_mergeRuns(v_n, v_s);
    }
    if (v_id == 29) {
        return v_heapBuild(v_n, v_s);
    }
    return 0;
}

static int64_t v_group3(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 30) {
        return v_reverseBuffer(v_n, v_s);
    }
    if (v_id == 31) {
        return v_rotateCycles(v_n, v_s);
    }
    if (v_id == 32) {
        return v_strideGather(v_n, v_s);
    }
    if (v_id == 33) {
        return v_permutedScatter(v_n, v_s);
    }
    if (v_id == 34) {
        return v_chainedLoads(v_n, v_s);
    }
    if (v_id == 35) {
        return v_copyIsolation(v_n, v_s);
    }
    if (v_id == 36) {
        return v_scopeChurn(v_n, v_s);
    }
    if (v_id == 37) {
        return v_compactStable(v_n, v_s);
    }
    if (v_id == 38) {
        return v_interleaveBuffers(v_n, v_s);
    }
    if (v_id == 39) {
        return v_sparsePages(v_n, v_s);
    }
    return 0;
}

static int64_t v_group4(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 40) {
        return v_dotProduct(v_n, v_s);
    }
    if (v_id == 41) {
        return v_integerVariance(v_n, v_s);
    }
    if (v_id == 42) {
        return v_frequencyMode(v_n, v_s);
    }
    if (v_id == 43) {
        return v_slidingWindow(v_n, v_s);
    }
    if (v_id == 44) {
        return v_prefixQueries(v_n, v_s);
    }
    if (v_id == 45) {
        return v_minmaxSpan(v_n, v_s);
    }
    if (v_id == 46) {
        return v_normalizedCov(v_n, v_s);
    }
    if (v_id == 47) {
        return v_lowpassMedian(v_n, v_s);
    }
    if (v_id == 48) {
        return v_lagCorrelation(v_n, v_s);
    }
    if (v_id == 49) {
        return v_trimmedThreshold(v_n, v_s);
    }
    return 0;
}

static int64_t v_group5(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 50) {
        return v_matrixMultiply(v_n, v_s);
    }
    if (v_id == 51) {
        return v_matrixTranspose(v_n, v_s);
    }
    if (v_id == 52) {
        return v_fivePoint(v_n, v_s);
    }
    if (v_id == 53) {
        return v_sobelHorizontal(v_n, v_s);
    }
    if (v_id == 54) {
        return v_summedArea(v_n, v_s);
    }
    if (v_id == 55) {
        return v_lifeOneStep(v_n, v_s);
    }
    if (v_id == 56) {
        return v_diagonalEnergy(v_n, v_s);
    }
    if (v_id == 57) {
        return v_triangularSolve(v_n, v_s);
    }
    if (v_id == 58) {
        return v_rowNormalize(v_n, v_s);
    }
    if (v_id == 59) {
        return v_maxPool(v_n, v_s);
    }
    return 0;
}

static int64_t v_group6(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 60) {
        return v_editDistance(v_n, v_s);
    }
    if (v_id == 61) {
        return v_commonSubsequence(v_n, v_s);
    }
    if (v_id == 62) {
        return v_knapsack(v_n, v_s);
    }
    if (v_id == 63) {
        return v_coinMinimum(v_n, v_s);
    }
    if (v_id == 64) {
        return v_increasingSubseq(v_n, v_s);
    }
    if (v_id == 65) {
        return v_gridMinPath(v_n, v_s);
    }
    if (v_id == 66) {
        return v_maxNonAdjacent(v_n, v_s);
    }
    if (v_id == 67) {
        return v_rodCut(v_n, v_s);
    }
    if (v_id == 68) {
        return v_segmentGain(v_n, v_s);
    }
    if (v_id == 69) {
        return v_subsetReach(v_n, v_s);
    }
    return 0;
}

static int64_t v_group7(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 70) {
        return v_unionFind(v_n, v_s);
    }
    if (v_id == 71) {
        return v_fenwickUpdateQuery(v_n, v_s);
    }
    if (v_id == 72) {
        return v_ringQueue(v_n, v_s);
    }
    if (v_id == 73) {
        return v_monotoneStack(v_n, v_s);
    }
    if (v_id == 74) {
        return v_openAddress(v_n, v_s);
    }
    if (v_id == 75) {
        return v_floydDistances(v_n, v_s);
    }
    if (v_id == 76) {
        return v_breadthFirst(v_n, v_s);
    }
    if (v_id == 77) {
        return v_treeFold(v_n, v_s);
    }
    if (v_id == 78) {
        return v_sparseEdges(v_n, v_s);
    }
    if (v_id == 79) {
        return v_intervalSweep(v_n, v_s);
    }
    return 0;
}

static int64_t v_group8(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 80) {
        return v_luhnDigits(v_n, v_s);
    }
    if (v_id == 81) {
        return v_runLengths(v_n, v_s);
    }
    if (v_id == 82) {
        return v_varintLength(v_n, v_s);
    }
    if (v_id == 83) {
        return v_decimalFields(v_n, v_s);
    }
    if (v_id == 84) {
        return v_csvQuoted(v_n, v_s);
    }
    if (v_id == 85) {
        return v_bracketDepth(v_n, v_s);
    }
    if (v_id == 86) {
        return v_utf8Widths(v_n, v_s);
    }
    if (v_id == 87) {
        return v_patternAutomaton(v_n, v_s);
    }
    if (v_id == 88) {
        return v_zigzagDelta(v_n, v_s);
    }
    if (v_id == 89) {
        return v_packedNibbles(v_n, v_s);
    }
    return 0;
}

static int64_t v_group9(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id == 90) {
        return v_tokenBucket(v_n, v_s);
    }
    if (v_id == 91) {
        return v_orderBookLevel(v_n, v_s);
    }
    if (v_id == 92) {
        return v_roundRobin(v_n, v_s);
    }
    if (v_id == 93) {
        return v_inventoryReorder(v_n, v_s);
    }
    if (v_id == 94) {
        return v_thermostat(v_n, v_s);
    }
    if (v_id == 95) {
        return v_resampleLinear(v_n, v_s);
    }
    if (v_id == 96) {
        return v_envelopeFollower(v_n, v_s);
    }
    if (v_id == 97) {
        return v_telemetryBuckets(v_n, v_s);
    }
    if (v_id == 98) {
        return v_backoffSimulation(v_n, v_s);
    }
    if (v_id == 99) {
        return v_packetJitter(v_n, v_s);
    }
    return 0;
}

static int64_t v_dispatch(int64_t v_id, int64_t v_n, int64_t v_s) {
    if (v_id < 10) {
        return v_group0(v_id, v_n, v_s);
    }
    if (v_id < 20) {
        return v_group1(v_id, v_n, v_s);
    }
    if (v_id < 30) {
        return v_group2(v_id, v_n, v_s);
    }
    if (v_id < 40) {
        return v_group3(v_id, v_n, v_s);
    }
    if (v_id < 50) {
        return v_group4(v_id, v_n, v_s);
    }
    if (v_id < 60) {
        return v_group5(v_id, v_n, v_s);
    }
    if (v_id < 70) {
        return v_group6(v_id, v_n, v_s);
    }
    if (v_id < 80) {
        return v_group7(v_id, v_n, v_s);
    }
    if (v_id < 90) {
        return v_group8(v_id, v_n, v_s);
    }
    if (v_id < 100) {
        return v_group9(v_id, v_n, v_s);
    }
    return 0;
}

extern "C" int64_t bench_case(int64_t id, int64_t n, int64_t s) { return v_dispatch(id,n,s); }
