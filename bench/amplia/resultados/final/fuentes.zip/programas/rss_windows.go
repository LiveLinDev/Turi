package main
import ("syscall";"unsafe")
var perfCounter=syscall.NewLazyDLL("kernel32.dll").NewProc("QueryPerformanceCounter")
var perfFrequency=syscall.NewLazyDLL("kernel32.dll").NewProc("QueryPerformanceFrequency")
func counter(p *syscall.LazyProc) int64 {
    var n int64
    ok,_,err:=p.Call(uintptr(unsafe.Pointer(&n)))
    if ok==0 {panic(err)}
    return n
}
var ticksPerSecond=counter(perfFrequency)
func startClock() int64 { return counter(perfCounter) }
func elapsedNS(start int64) int64 { return (counter(perfCounter)-start)*1_000_000_000/ticksPerSecond }
func rss() uint64 {
    type Mem struct { Cb, Faults uint32; Peak uintptr; Other [7]uintptr }
    var m Mem
    m.Cb=uint32(unsafe.Sizeof(m))
    h,_,_:=syscall.NewLazyDLL("kernel32.dll").NewProc("GetCurrentProcess").Call()
    v,_,err:=syscall.NewLazyDLL("psapi.dll").NewProc("GetProcessMemoryInfo").Call(h,uintptr(unsafe.Pointer(&m)),uintptr(m.Cb))
    if v==0 {panic(err)}
    return uint64(m.Peak)
}

