package main
func v_val(v_i int64, v_s int64) int64 {
    var v_x int64 = (((v_i * 73) + (v_s * 101)) % 1009)
    return ((((v_x * v_x) + (17 * v_x)) + 19) % 1009)
}

func v_low(v_x int64, v_y int64) int64 {
    if (v_x < v_y) {
        return v_x
    }
    return v_y
}

func v_high(v_x int64, v_y int64) int64 {
    if (v_x > v_y) {
        return v_x
    }
    return v_y
}

func v_dist(v_x int64, v_y int64) int64 {
    if (v_x >= v_y) {
        return (v_x - v_y)
    }
    return (v_y - v_x)
}

func v_euclidBatch(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_a int64 = (v_val(v_i, v_s) + 1)
        var v_b int64 = (v_i + 19)
        for (v_b > 0) {
            var v_r int64 = (v_a % v_b)
            v_a = v_b
            v_b = v_r
        }
        v_total = v_total + v_a
    }
    return v_total
}

func v_primeTrial(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_a int64 = ((v_i + v_s) + 2)
        var v_d int64 = 2
        for (((v_d * v_d) <= v_a) && ((v_a % v_d) != 0)) {
            v_d = v_d + 1
        }
        if ((v_d * v_d) > v_a) {
            v_total = v_total + 1
        }
    }
    return v_total
}

func v_modularPower(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_e int64 = v_val(v_i, v_s)
        var v_b int64 = (v_i + 3)
        var v_v int64 = 1
        for (v_e > 0) {
            if ((v_e % 2) == 1) {
                v_v = ((v_v * v_b) % 65521)
            }
            v_b = ((v_b * v_b) % 65521)
            v_e = (v_e / 2)
        }
        v_total = v_total + v_v
    }
    return v_total
}

func v_newtonRoot(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_a int64 = (((v_i + v_s) * 97) + 1)
        var v_x int64 = v_a
        var v_y int64 = ((v_x + 1) / 2)
        for (v_y < v_x) {
            v_x = v_y
            v_y = ((v_x + (v_a / v_x)) / 2)
        }
        v_total = v_total + v_x
    }
    return v_total
}

func v_digitSum(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_a int64 = ((v_i + 1) * (v_s + 1))
        for (v_a > 0) {
            v_total = v_total + (v_a % 10)
            v_a = (v_a / 10)
        }
    }
    return v_total
}

func v_binomialRows(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_a int64 = (((v_i + v_s) % 27) + 1)
        var v_v int64 = 1
        for v_j := int64(1); v_j < (v_a + 1); v_j++ {
            v_v = ((v_v * ((v_a + 1) - v_j)) / v_j)
            v_total = v_total + v_v
        }
    }
    return v_total
}

func v_factorMultiplicity(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = (v_val(v_i, v_s) + 1)
        var v_d int64 = 2
        for ((v_d * v_d) <= v_x) {
            for ((v_x % v_d) == 0) {
                v_total = v_total + 1
                v_x = (v_x / v_d)
            }
            v_d = v_d + 1
        }
        if (v_x > 1) {
            v_total = v_total + 1
        }
    }
    return v_total
}

func v_binaryOnes(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = ((v_val(v_i, v_s) * 177) + v_i)
        for (v_x > 0) {
            v_total = v_total + (v_x % 2)
            v_x = (v_x / 2)
        }
    }
    return v_total
}

func v_totientBatch(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = (v_val(v_i, v_s) + 1)
        var v_phi int64 = v_x
        var v_d int64 = 2
        for ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_phi = v_phi - (v_phi / v_d)
                for ((v_x % v_d) == 0) {
                    v_x = (v_x / v_d)
                }
            }
            v_d = v_d + 1
        }
        if (v_x > 1) {
            v_phi = v_phi - (v_phi / v_x)
        }
        v_total = v_total + v_phi
    }
    return v_total
}

func v_divisorsPaired(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = (v_val(v_i, v_s) + 1)
        var v_d int64 = 1
        for ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_total = v_total + v_d
                if ((v_d * v_d) != v_x) {
                    v_total = v_total + (v_x / v_d)
                }
            }
            v_d = v_d + 1
        }
    }
    return v_total
}

func v_affineStream(v_n int64, v_s int64) int64 {
    var v_x int64 = v_s
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_x = (((v_x * 48271) + 1) % 2147483647)
    }
    return v_x
}

func v_fibonacciMod(v_n int64, v_s int64) int64 {
    var v_a int64 = 0
    var v_b int64 = v_s
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_c int64 = ((v_a + v_b) % 65521)
        v_a = v_b
        v_b = v_c
    }
    return v_b
}

func v_adlerStream(v_n int64, v_s int64) int64 {
    var v_a int64 = 1
    var v_b int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_a = ((v_a + (v_val(v_i, v_s) % 256)) % 65521)
        v_b = ((v_b + v_a) % 65521)
    }
    return ((v_b * 65536) + v_a)
}

func v_polynomialHash(v_n int64, v_s int64) int64 {
    var v_h int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_h = (((v_h * 257) + v_val(v_i, v_s)) % 1000003)
    }
    return v_h
}

func v_exponentialFilter(v_n int64, v_s int64) int64 {
    var v_state int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_state = (((v_state * 7) + (v_val(v_i, v_s) * 8)) / 8)
    }
    return v_state
}

func v_hysteresis(v_n int64, v_s int64) int64 {
    var v_state int64 = 0
    var v_transitions int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_v int64 = v_val(v_i, v_s)
        if ((v_state == 0) && (v_v > 765)) {
            v_state = 1
            v_transitions = v_transitions + 1
        }
        if ((v_state == 1) && (v_v < 201)) {
            v_state = 0
        }
    }
    return v_transitions
}

func v_longestStreak(v_n int64, v_s int64) int64 {
    var v_streak int64 = 0
    var v_best int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        if ((v_val(v_i, v_s) % 3) != 0) {
            v_streak = v_streak + 1
            v_best = v_high(v_best, v_streak)
        } else {
            v_streak = 0
        }
    }
    return v_best
}

func v_majorityVote(v_n int64, v_s int64) int64 {
    var v_balance int64 = 0
    var v_candidate int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_v int64 = (v_val(v_i, v_s) % 7)
        if (v_balance == 0) {
            v_candidate = v_v
        }
        if (v_candidate == v_v) {
            v_balance = v_balance + 1
        } else {
            v_balance = v_balance - 1
        }
    }
    return ((v_candidate * 100) + v_balance)
}

func v_crossingCount(v_n int64, v_s int64) int64 {
    var v_prev int64 = (v_s % 1009)
    var v_count int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = v_val(v_i, v_s)
        if ((v_prev <= 500) && (v_x > 500)) {
            v_count = v_count + 1
        }
        v_prev = v_x
    }
    return v_count
}

func v_cumulativeDrawdown(v_n int64, v_s int64) int64 {
    var v_price int64 = 1000
    var v_peak int64 = v_price
    var v_draw int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_price = v_price + ((v_val(v_i, v_s) % 31) - 15)
        v_peak = v_high(v_peak, v_price)
        v_draw = v_high(v_draw, (v_peak - v_price))
    }
    return v_draw
}

func v_insertionSort(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    for v_i := int64(1); v_i < v_n; v_i++ {
        var v_v int64 = v_a[v_i]
        var v_j int64 = v_i
        for ((v_j > 0) && (v_a[(v_j - 1)] > v_v)) {
            v_a[v_j] = v_a[(v_j - 1)]
            v_j = v_j - 1
        }
        v_a[v_j] = v_v
    }
    return (v_a[(v_n / 3)] + v_a[(v_n - 1)])
}

func v_selectionSort(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_k int64 = v_i
        for v_j := int64((v_i + 1)); v_j < v_n; v_j++ {
            if (v_a[v_j] < v_a[v_k]) {
                v_k = v_j
            }
        }
        var v_v int64 = v_a[v_k]
        v_a[v_k] = v_a[v_i]
        v_a[v_i] = v_v
    }
    return (v_a[(v_n / 2)] + v_a[0])
}

func v_bubbleEarly(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_edge int64 = v_n
    for (v_edge > 1) {
        var v_last int64 = 0
        for v_j := int64(1); v_j < v_edge; v_j++ {
            if (v_a[(v_j - 1)] > v_a[v_j]) {
                var v_v int64 = v_a[v_j]
                v_a[v_j] = v_a[(v_j - 1)]
                v_a[(v_j - 1)] = v_v
                v_last = v_j
            }
        }
        v_edge = v_last
    }
    return (v_a[(v_n / 4)] + v_a[(v_n - 1)])
}

func v_shellSort(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_gap int64 = (v_n / 2)
    for (v_gap > 0) {
        for v_i := int64(v_gap); v_i < v_n; v_i++ {
            var v_v int64 = v_a[v_i]
            var v_j int64 = v_i
            for ((v_j >= v_gap) && (v_a[(v_j - v_gap)] > v_v)) {
                v_a[v_j] = v_a[(v_j - v_gap)]
                v_j = v_j - v_gap
            }
            v_a[v_j] = v_v
        }
        v_gap = (v_gap / 2)
    }
    return v_a[(v_n / 2)]
}

func v_countingRank(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_h := make([]int64, 1009)
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_h[v_a[v_i]] = v_h[v_a[v_i]] + 1
    }
    var v_rank int64 = (v_n / 2)
    var v_v int64 = 0
    for (v_rank >= v_h[v_v]) {
        v_rank = v_rank - v_h[v_v]
        v_v = v_v + 1
    }
    return v_v
}

func v_lowerBound(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_a[v_i] = ((v_i * 3) + (v_i / 5))
    }
    var v_t int64 = 0
    for v_j := int64(0); v_j < (v_n / 4); v_j++ {
        var v_x int64 = ((v_val(v_j, v_s) * 31) % (v_n * 4))
        var v_lo int64 = 0
        var v_hi int64 = v_n
        for (v_lo < v_hi) {
            var v_mid int64 = ((v_lo + v_hi) / 2)
            if (v_a[v_mid] < v_x) {
                v_lo = (v_mid + 1)
            } else {
                v_hi = v_mid
            }
        }
        v_t = v_t + v_lo
    }
    return v_t
}

func v_sentinelFind(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n + 1))
    for ix := int64(0); ix < (v_n + 1); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_q := int64(0); v_q < 40; v_q++ {
        var v_x int64 = v_val((v_q + v_n), v_s)
        v_a[v_n] = v_x
        var v_j int64 = 0
        for (v_a[v_j] != v_x) {
            v_j = v_j + 1
        }
        v_t = v_t + v_j
    }
    return v_t
}

func v_partitionPivot(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_pivot int64 = v_a[(v_n / 2)]
    var v_left int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        if (v_a[v_i] < v_pivot) {
            var v_v int64 = v_a[v_left]
            v_a[v_left] = v_a[v_i]
            v_a[v_i] = v_v
            v_left = v_left + 1
        }
    }
    return (v_left + v_a[(v_n / 2)])
}

func v_mergeRuns(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    v_b := make([]int64, v_n)
    var v_x int64 = 0
    var v_y int64 = 0
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_x = v_x + (v_val(v_i, v_s) % 7)
        v_y = v_y + (v_val((v_i + 3), v_s) % 11)
        v_a[v_i] = v_x
        v_b[v_i] = v_y
    }
    var v_l int64 = 0
    var v_r int64 = 0
    for v_k := int64(0); v_k < (v_n * 2); v_k++ {
        if ((v_r == v_n) || ((v_l < v_n) && (v_a[v_l] <= v_b[v_r]))) {
            v_t = v_t + (v_a[v_l] * (v_k % 7))
            v_l = v_l + 1
        } else {
            v_t = v_t + (v_b[v_r] * (v_k % 7))
            v_r = v_r + 1
        }
    }
    return v_t
}

func v_heapBuild(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_i int64 = (v_n / 2)
    for (v_i > 0) {
        v_i = v_i - 1
        var v_root int64 = v_i
        var v_child int64 = ((2 * v_root) + 1)
        for (v_child < v_n) {
            if (((v_child + 1) < v_n) && (v_a[(v_child + 1)] > v_a[v_child])) {
                v_child = v_child + 1
            }
            if (v_a[v_root] >= v_a[v_child]) {
                v_child = v_n
            } else {
                var v_v int64 = v_a[v_root]
                v_a[v_root] = v_a[v_child]
                v_a[v_child] = v_v
                v_root = v_child
                v_child = ((2 * v_root) + 1)
            }
        }
    }
    return (v_a[0] + v_a[(v_n / 3)])
}

func v_reverseBuffer(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    for v_i := int64(0); v_i < (v_n / 2); v_i++ {
        var v_j int64 = ((v_n - 1) - v_i)
        var v_t int64 = v_a[v_i]
        v_a[v_i] = v_a[v_j]
        v_a[v_j] = v_t
    }
    var v_total int64 = 0
    for v_k := int64(0); v_k < v_n; v_k++ {
        v_total = v_total + (v_a[v_k] * (v_k % 11))
    }
    return v_total
}

func v_rotateCycles(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = v_a[(v_n - 1)]
    for v_i := int64(1); v_i < v_n; v_i++ {
        v_a[(v_n - v_i)] = v_a[((v_n - v_i) - 1)]
    }
    v_a[0] = v_t
    var v_total int64 = 0
    for v_j := int64(0); v_j < v_n; v_j++ {
        v_total = v_total + (v_a[v_j] * (v_j % 17))
    }
    return v_total
}

func v_strideGather(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    var v_pos int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_t = v_t + v_a[v_pos]
        v_pos = ((v_pos + 61) % v_n)
    }
    return v_t
}

func v_permutedScatter(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    var v_j int64 = (v_s % v_n)
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_a[v_j] = (v_i + 1)
        v_j = ((v_j + 31) % v_n)
    }
    var v_t int64 = 0
    for v_k := int64(0); v_k < v_n; v_k++ {
        v_t = v_t + (v_a[v_k] * (v_k % 5))
    }
    return v_t
}

func v_chainedLoads(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_a[v_i] = ((v_a[v_i] + (v_i * 59)) % v_n)
    }
    var v_p int64 = (v_s % v_n)
    var v_t int64 = 0
    for v_j := int64(0); v_j < v_n; v_j++ {
        v_p = v_a[v_p]
        v_t = v_t + v_p
    }
    return v_t
}

func v_copyIsolation(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := append([]int64(nil), v_a...)
    for v_i := int64(0); v_i < v_n; v_i++ {
        if ((v_i % 3) == 0) {
            v_b[v_i] = (v_a[v_i] + v_i)
        }
    }
    var v_t int64 = 0
    for v_j := int64(0); v_j < v_n; v_j++ {
        v_t = v_t + ((v_b[v_j] * 3) - v_a[v_j])
    }
    return v_t
}

func v_scopeChurn(v_n int64, v_s int64) int64 {
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_width int64 = ((v_val(v_i, v_s) % 377) + 4)
        v_a := make([]int64, v_width)
        for ii := range v_a { v_a[ii] = v_i }
        for v_j := int64(0); v_j < v_width; v_j++ {
            v_a[v_j] = ((v_a[v_j] + (v_j * 17)) % 173)
        }
        v_t = v_t + v_a[((v_i + v_s) % v_width)]
    }
    return v_t
}

func v_compactStable(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_write int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        if ((v_a[v_i] % 3) == 0) {
            v_a[v_write] = v_a[v_i]
            v_write = v_write + 1
        }
    }
    var v_t int64 = 0
    for v_j := int64(0); v_j < v_write; v_j++ {
        v_t = v_t + (v_a[v_j] * (v_j % 5))
    }
    return v_t
}

func v_interleaveBuffers(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_b[ix] = v_val(ix, (v_s + 1))
    }
    v_c := make([]int64, (v_n * 2))
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_c[(2 * v_i)] = v_a[v_i]
        v_c[((2 * v_i) + 1)] = v_b[v_i]
    }
    var v_t int64 = 0
    for v_j := int64(1); v_j < (v_n * 2); v_j++ {
        v_t = v_t + v_dist(v_c[v_j], v_c[(v_j - 1)])
    }
    return v_t
}

func v_sparsePages(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ii := range v_a { v_a[ii] = v_s }
    for v_i := int64(0); v_i < ((v_n + 511) / 512); v_i++ {
        v_a[(v_i * 512)] = v_val(v_i, v_s)
    }
    var v_t int64 = 0
    for v_k := int64(0); v_k < v_n; v_k++ {
        v_t = v_t + v_a[v_k]
    }
    return v_t
}

func v_dotProduct(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_b[ix] = v_val(ix, (v_s + 1))
    }
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_t = v_t + (v_a[v_i] * v_b[v_i])
    }
    return v_t
}

func v_integerVariance(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_t = v_t + v_a[v_i]
    }
    var v_mean int64 = (v_t / v_n)
    var v_v int64 = 0
    for v_j := int64(0); v_j < v_n; v_j++ {
        var v_d int64 = (v_a[v_j] - v_mean)
        v_v = v_v + (v_d * v_d)
    }
    return v_v
}

func v_frequencyMode(v_n int64, v_s int64) int64 {
    v_a := make([]int64, 257)
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_a[(v_val(v_i, v_s) % 257)] = v_a[(v_val(v_i, v_s) % 257)] + 1
    }
    var v_best int64 = 0
    for v_k := int64(1); v_k < 257; v_k++ {
        if (v_a[v_k] > v_a[v_best]) {
            v_best = v_k
        }
    }
    return v_best
}

func v_slidingWindow(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_window int64 = 0
    var v_best int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_window = v_window + v_a[v_i]
        if (v_i >= 23) {
            v_window = v_window - v_a[(v_i - 23)]
        }
        v_best = v_high(v_best, v_window)
    }
    return v_best
}

func v_prefixQueries(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n + 1))
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_a[(v_i + 1)] = (v_a[v_i] + v_val(v_i, v_s))
    }
    var v_t int64 = 0
    for v_j := int64(0); v_j < (v_n / 4); v_j++ {
        var v_lo int64 = (v_val(v_j, v_s) % v_n)
        var v_hi int64 = (v_lo + (v_val((v_j + 1), v_s) % (v_n - v_lo)))
        v_t = v_t + (v_a[(v_hi + 1)] - v_a[v_lo])
    }
    return v_t
}

func v_minmaxSpan(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_mn int64 = v_a[0]
    var v_mx int64 = v_a[0]
    for v_i := int64(1); v_i < v_n; v_i++ {
        v_mn = v_low(v_mn, v_a[v_i])
        v_mx = v_high(v_mx, v_a[v_i])
    }
    return (v_mx - v_mn)
}

func v_normalizedCov(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_b[ix] = v_val(ix, (v_s + 2))
    }
    var v_x int64 = 0
    var v_y int64 = 0
    var v_xy int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_x = v_x + v_a[v_i]
        v_y = v_y + v_b[v_i]
        v_xy = v_xy + (v_a[v_i] * v_b[v_i])
    }
    return ((v_n * v_xy) - (v_x * v_y))
}

func v_lowpassMedian(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_total int64 = 0
    for v_i := int64(2); v_i < v_n; v_i++ {
        var v_x int64 = v_low(v_a[v_i], v_a[(v_i - 1)])
        var v_y int64 = v_high(v_a[v_i], v_a[(v_i - 1)])
        v_total = v_total + v_high(v_x, v_low(v_a[(v_i - 2)], v_y))
    }
    return v_total
}

func v_lagCorrelation(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    var v_lag int64 = ((v_s % 23) + 1)
    for v_i := int64(v_lag); v_i < v_n; v_i++ {
        v_t = v_t + ((v_a[v_i] - 500) * (v_a[(v_i - v_lag)] - 500))
    }
    return v_t
}

func v_trimmedThreshold(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    var v_count int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        if ((v_a[v_i] >= 100) && (v_a[v_i] < 900)) {
            v_t = v_t + v_a[v_i]
            v_count = v_count + 1
        }
    }
    return (v_t / (v_count + 1))
}

func v_matrixMultiply(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_b[ix] = v_val(ix, (v_s + 1))
    }
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        for v_j := int64(0); v_j < v_n; v_j++ {
            var v_v int64 = 0
            for v_k := int64(0); v_k < v_n; v_k++ {
                v_v = v_v + (v_a[((v_i * v_n) + v_k)] * v_b[((v_k * v_n) + v_j)])
            }
            v_t = v_t + (v_v % 101)
        }
    }
    return v_t
}

func v_matrixTranspose(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, (v_n * v_n))
    for v_i := int64(0); v_i < v_n; v_i++ {
        for v_j := int64(0); v_j < v_n; v_j++ {
            v_b[((v_j * v_n) + v_i)] = v_a[((v_i * v_n) + v_j)]
        }
    }
    var v_t int64 = 0
    for v_k := int64(0); v_k < (v_n * v_n); v_k++ {
        v_t = v_t + (v_b[v_k] * (v_k % 13))
    }
    return v_t
}

func v_fivePoint(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_i := int64(1); v_i < (v_n - 1); v_i++ {
        for v_j := int64(1); v_j < (v_n - 1); v_j++ {
            var v_p int64 = ((v_i * v_n) + v_j)
            v_t = v_t + (((((v_a[v_p] + v_a[(v_p - 1)]) + v_a[(v_p + 1)]) + v_a[(v_p - v_n)]) + v_a[(v_p + v_n)]) / 5)
        }
    }
    return v_t
}

func v_sobelHorizontal(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_i := int64(1); v_i < (v_n - 1); v_i++ {
        for v_j := int64(1); v_j < (v_n - 1); v_j++ {
            var v_p int64 = ((v_i * v_n) + v_j)
            var v_l int64 = ((v_a[((v_p - v_n) - 1)] + (v_a[(v_p - 1)] * 2)) + v_a[((v_p + v_n) - 1)])
            var v_r int64 = ((v_a[((v_p - v_n) + 1)] + (v_a[(v_p + 1)] * 2)) + v_a[((v_p + v_n) + 1)])
            v_t = v_t + v_dist(v_l, v_r)
        }
    }
    return v_t
}

func v_summedArea(v_n int64, v_s int64) int64 {
    v_p := make([]int64, ((v_n + 1) * (v_n + 1)))
    var v_w int64 = (v_n + 1)
    for v_i := int64(1); v_i < v_w; v_i++ {
        var v_row int64 = 0
        for v_j := int64(1); v_j < v_w; v_j++ {
            v_row = v_row + v_val(((v_i * v_w) + v_j), v_s)
            v_p[((v_i * v_w) + v_j)] = (v_row + v_p[(((v_i - 1) * v_w) + v_j)])
        }
    }
    return (v_p[((v_n * v_w) + v_n)] + v_p[(((v_n / 2) * v_w) + (v_n / 3))])
}

func v_lifeOneStep(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_alive int64 = 0
    for v_i := int64(1); v_i < (v_n - 1); v_i++ {
        for v_j := int64(1); v_j < (v_n - 1); v_j++ {
            var v_p int64 = ((v_i * v_n) + v_j)
            var v_count int64 = 0
            for v_y := int64(0); v_y < 3; v_y++ {
                for v_x := int64(0); v_x < 3; v_x++ {
                    if ((v_y != 1) || (v_x != 1)) {
                        v_count = v_count + (v_a[(((v_p + ((v_y - 1) * v_n)) + v_x) - 1)] % 2)
                    }
                }
            }
            if ((v_count == 3) || ((v_count == 2) && ((v_a[v_p] % 2) == 1))) {
                v_alive = v_alive + 1
            }
        }
    }
    return v_alive
}

func v_diagonalEnergy(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_d := int64(0); v_d < v_n; v_d++ {
        var v_v int64 = 0
        for v_i := int64(0); v_i < (v_n - v_d); v_i++ {
            v_v = v_v + v_a[(((v_i * v_n) + v_i) + v_d)]
        }
        v_t = v_t + (v_v * v_v)
    }
    return v_t
}

func v_triangularSolve(v_n int64, v_s int64) int64 {
    v_x := make([]int64, v_n)
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_v int64 = v_val(v_i, v_s)
        for v_j := int64(0); v_j < v_i; v_j++ {
            v_v = v_v + ((v_val((v_i + v_j), v_s) % 5) * v_x[v_j])
        }
        v_x[v_i] = (v_v % 997)
    }
    return v_x[(v_n - 1)]
}

func v_rowNormalize(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_mx int64 = 1
        for v_j := int64(0); v_j < v_n; v_j++ {
            v_mx = v_high(v_mx, v_a[((v_i * v_n) + v_j)])
        }
        for v_k := int64(0); v_k < v_n; v_k++ {
            v_t = v_t + ((v_a[((v_i * v_n) + v_k)] * 255) / v_mx)
        }
    }
    return v_t
}

func v_maxPool(v_n int64, v_s int64) int64 {
    v_a := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_i := int64(0); v_i < (v_n / 2); v_i++ {
        for v_j := int64(0); v_j < (v_n / 2); v_j++ {
            var v_p int64 = (((2 * v_i) * v_n) + (2 * v_j))
            v_t = v_t + v_high(v_high(v_a[v_p], v_a[(v_p + 1)]), v_high(v_a[(v_p + v_n)], v_a[((v_p + v_n) + 1)]))
        }
    }
    return v_t
}

func v_editDistance(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_b[ix] = v_val(ix, (v_s + 1))
    }
    v_d := make([]int64, (v_n + 1))
    for v_j := int64(0); v_j < (v_n + 1); v_j++ {
        v_d[v_j] = v_j
    }
    for v_i := int64(1); v_i < (v_n + 1); v_i++ {
        var v_diag int64 = v_d[0]
        v_d[0] = v_i
        for v_k := int64(1); v_k < (v_n + 1); v_k++ {
            var v_old int64 = v_d[v_k]
            var v_cost int64 = 0
            if ((v_a[(v_i - 1)] % 7) != (v_b[(v_k - 1)] % 7)) {
                v_cost = 1
            }
            v_d[v_k] = v_low((v_low(v_d[(v_k - 1)], v_old) + 1), (v_diag + v_cost))
            v_diag = v_old
        }
    }
    return v_d[v_n]
}

func v_commonSubsequence(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_b := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_b[ix] = v_val(ix, (v_s + 2))
    }
    v_d := make([]int64, (v_n + 1))
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_diag int64 = 0
        for v_j := int64(1); v_j < (v_n + 1); v_j++ {
            var v_old int64 = v_d[v_j]
            if ((v_a[v_i] % 11) == (v_b[(v_j - 1)] % 11)) {
                v_d[v_j] = (v_diag + 1)
            } else {
                v_d[v_j] = v_high(v_d[v_j], v_d[(v_j - 1)])
            }
            v_diag = v_old
        }
    }
    return v_d[v_n]
}

func v_knapsack(v_n int64, v_s int64) int64 {
    v_d := make([]int64, (v_n + 1))
    for v_i := int64(0); v_i < 48; v_i++ {
        var v_w int64 = ((v_val(v_i, v_s) % 37) + 1)
        var v_price int64 = (v_val((v_i + 1), v_s) % 89)
        var v_j int64 = v_n
        for (v_j >= v_w) {
            v_d[v_j] = v_high(v_d[v_j], (v_d[(v_j - v_w)] + v_price))
            v_j = v_j - 1
        }
    }
    return v_d[v_n]
}

func v_coinMinimum(v_n int64, v_s int64) int64 {
    v_d := make([]int64, (v_n + 1))
    for ii := range v_d { v_d[ii] = (v_n + 1) }
    v_d[0] = 0
    for v_i := int64(1); v_i < (v_n + 1); v_i++ {
        v_d[v_i] = (v_d[(v_i - 1)] + 1)
        for v_j := int64(0); v_j < 5; v_j++ {
            var v_c int64 = ((v_val(v_j, v_s) % 33) + 1)
            if (v_i >= v_c) {
                v_d[v_i] = v_low(v_d[v_i], (v_d[(v_i - v_c)] + 1))
            }
        }
    }
    return v_d[v_n]
}

func v_increasingSubseq(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    v_d := make([]int64, v_n)
    for ii := range v_d { v_d[ii] = 1 }
    var v_best int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        for v_j := int64(0); v_j < v_i; v_j++ {
            if (v_a[v_j] < v_a[v_i]) {
                v_d[v_i] = v_high(v_d[v_i], (v_d[v_j] + 1))
            }
        }
        v_best = v_high(v_best, v_d[v_i])
    }
    return v_best
}

func v_gridMinPath(v_n int64, v_s int64) int64 {
    v_d := make([]int64, v_n)
    for v_i := int64(0); v_i < v_n; v_i++ {
        for v_j := int64(0); v_j < v_n; v_j++ {
            var v_v int64 = v_val(((v_i * v_n) + v_j), v_s)
            if (v_j == 0) {
                v_d[v_j] = v_d[v_j] + v_v
            } else {
                if (v_i == 0) {
                    v_d[v_j] = (v_d[(v_j - 1)] + v_v)
                } else {
                    v_d[v_j] = (v_low(v_d[v_j], v_d[(v_j - 1)]) + v_v)
                }
            }
        }
    }
    return v_d[(v_n - 1)]
}

func v_maxNonAdjacent(v_n int64, v_s int64) int64 {
    var v_prev int64 = 0
    var v_best int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_take int64 = (v_prev + v_val(v_i, v_s))
        v_prev = v_best
        v_best = v_high(v_best, v_take)
    }
    return v_best
}

func v_rodCut(v_n int64, v_s int64) int64 {
    v_d := make([]int64, (v_n + 1))
    v_price := make([]int64, (v_n + 1))
    for ix := int64(0); ix < (v_n + 1); ix++ {
        v_price[ix] = v_val(ix, v_s)
    }
    for v_i := int64(1); v_i < (v_n + 1); v_i++ {
        for v_j := int64(1); v_j < (v_i + 1); v_j++ {
            v_d[v_i] = v_high(v_d[v_i], (v_price[v_j] + v_d[(v_i - v_j)]))
        }
    }
    return v_d[v_n]
}

func v_segmentGain(v_n int64, v_s int64) int64 {
    var v_best int64 = 0
    var v_current int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_current = v_high(0, ((v_current + v_val(v_i, v_s)) - 503))
        v_best = v_high(v_best, v_current)
    }
    return v_best
}

func v_subsetReach(v_n int64, v_s int64) int64 {
    v_d := make([]int64, (v_n + 1))
    v_d[0] = 1
    for v_i := int64(0); v_i < 30; v_i++ {
        var v_w int64 = ((v_val(v_i, v_s) % 70) + 1)
        var v_j int64 = v_n
        for (v_j >= v_w) {
            if (v_d[(v_j - v_w)] == 1) {
                v_d[v_j] = 1
            }
            v_j = v_j - 1
        }
    }
    var v_total int64 = 0
    for v_k := int64(0); v_k < (v_n + 1); v_k++ {
        v_total = v_total + v_d[v_k]
    }
    return v_total
}

func v_unionFind(v_n int64, v_s int64) int64 {
    v_p := make([]int64, v_n)
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_p[v_i] = v_i
    }
    var v_joined int64 = 0
    for v_j := int64(0); v_j < v_n; v_j++ {
        var v_a int64 = (((v_j * 37) + v_s) % v_n)
        var v_b int64 = (((v_j * 19) + v_val(v_j, v_s)) % v_n)
        for (v_p[v_a] != v_a) {
            v_p[v_a] = v_p[v_p[v_a]]
            v_a = v_p[v_a]
        }
        for (v_p[v_b] != v_b) {
            v_b = v_p[v_b]
        }
        if (v_a != v_b) {
            v_p[v_a] = v_b
            v_joined = v_joined + 1
        }
    }
    return v_joined
}

func v_fenwickUpdateQuery(v_n int64, v_s int64) int64 {
    v_tree := make([]int64, (v_n + 1))
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_k int64 = (v_i + 1)
        var v_bit int64 = 1
        for ((v_k % (v_bit * 2)) == 0) {
            v_bit = v_bit * 2
        }
        v_tree[v_k] = v_tree[v_k] + v_val(v_i, v_s)
        var v_parent int64 = (v_k + v_bit)
        if (v_parent <= v_n) {
            v_tree[v_parent] = v_tree[v_parent] + v_tree[v_k]
        }
        if ((v_k % 17) == 0) {
            v_t = v_t + v_tree[v_k]
        }
    }
    return (v_t + v_tree[v_n])
}

func v_ringQueue(v_n int64, v_s int64) int64 {
    v_q := make([]int64, 127)
    var v_head int64 = 0
    var v_tail int64 = 0
    var v_count int64 = 0
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = v_val(v_i, v_s)
        if ((v_count == 0) || ((v_count < 127) && ((v_x % 3) != 0))) {
            v_q[v_tail] = v_x
            v_tail = ((v_tail + 1) % 127)
            v_count = v_count + 1
        } else {
            v_t = v_t + v_q[v_head]
            v_head = ((v_head + 1) % 127)
            v_count = v_count - 1
        }
    }
    return (v_t + v_count)
}

func v_monotoneStack(v_n int64, v_s int64) int64 {
    v_st := make([]int64, v_n)
    var v_size int64 = 0
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = v_val(v_i, v_s)
        for ((v_size > 0) && (v_st[(v_size - 1)] <= v_x)) {
            v_size = v_size - 1
        }
        if (v_size > 0) {
            v_t = v_t + v_st[(v_size - 1)]
        }
        v_st[v_size] = v_x
        v_size = v_size + 1
    }
    return v_t
}

func v_openAddress(v_n int64, v_s int64) int64 {
    var v_cap int64 = ((2 * v_n) + 1)
    v_slots := make([]int64, v_cap)
    var v_probes int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_key int64 = (((v_i * 231) + v_val(v_i, v_s)) + 1)
        var v_p int64 = (v_key % v_cap)
        for (v_slots[v_p] != 0) {
            v_probes = v_probes + 1
            v_p = ((v_p + 1) % v_cap)
        }
        v_slots[v_p] = v_key
    }
    return (v_probes + v_slots[(v_s % v_cap)])
}

func v_floydDistances(v_n int64, v_s int64) int64 {
    v_d := make([]int64, (v_n * v_n))
    for ix := int64(0); ix < (v_n * v_n); ix++ {
        v_d[ix] = v_val(ix, v_s)
    }
    for v_k := int64(0); v_k < v_n; v_k++ {
        for v_i := int64(0); v_i < v_n; v_i++ {
            for v_j := int64(0); v_j < v_n; v_j++ {
                var v_p int64 = ((v_i * v_n) + v_j)
                v_d[v_p] = v_low(v_d[v_p], (v_d[((v_i * v_n) + v_k)] + v_d[((v_k * v_n) + v_j)]))
            }
        }
    }
    return (v_d[(v_s % v_n)] + v_d[((v_n * v_n) - 1)])
}

func v_breadthFirst(v_n int64, v_s int64) int64 {
    v_seen := make([]int64, v_n)
    v_q := make([]int64, v_n)
    v_q[0] = (v_s % v_n)
    v_seen[v_q[0]] = 1
    var v_head int64 = 0
    var v_tail int64 = 1
    var v_t int64 = 0
    for (v_head < v_tail) {
        var v_v int64 = v_q[v_head]
        v_head = v_head + 1
        for v_j := int64(0); v_j < 2; v_j++ {
            var v_w int64 = ((((v_v * (v_j + 2)) + v_j) + 1) % v_n)
            if (v_seen[v_w] == 0) {
                v_seen[v_w] = (v_seen[v_v] + 1)
                v_q[v_tail] = v_w
                v_tail = v_tail + 1
                v_t = v_t + v_seen[v_w]
            }
        }
    }
    return v_t
}

func v_treeFold(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_i int64 = (v_n - 1)
    for (v_i > 0) {
        v_a[((v_i - 1) / 2)] = v_a[((v_i - 1) / 2)] + v_a[v_i]
        v_i = v_i - 1
    }
    return (v_a[0] + v_a[(v_n / 7)])
}

func v_sparseEdges(v_n int64, v_s int64) int64 {
    v_target := make([]int64, v_n)
    for v_i := int64(0); v_i < v_n; v_i++ {
        for v_j := int64(0); v_j < 3; v_j++ {
            var v_dst int64 = ((((v_i * 17) + (v_j * 29)) + v_s) % v_n)
            v_target[v_dst] = v_target[v_dst] + (v_val((v_i + v_j), v_s) % 19)
        }
    }
    var v_t int64 = 0
    for v_k := int64(0); v_k < v_n; v_k++ {
        v_t = v_t + (v_target[v_k] * (v_k % 11))
    }
    return v_t
}

func v_intervalSweep(v_n int64, v_s int64) int64 {
    v_hits := make([]int64, (v_n + 1))
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_start int64 = ((v_val(v_i, v_s) + v_i) % v_n)
        var v_end int64 = v_low(v_n, ((v_start + (v_val((v_i + 1), v_s) % 41)) + 1))
        v_hits[v_start] = v_hits[v_start] + 1
        v_hits[v_end] = v_hits[v_end] - 1
    }
    var v_active int64 = 0
    var v_best int64 = 0
    for v_k := int64(0); v_k < v_n; v_k++ {
        v_active = v_active + v_hits[v_k]
        v_best = v_high(v_active, v_best)
    }
    return v_best
}

func v_luhnDigits(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_d int64 = (v_val(v_i, v_s) % 10)
        if ((v_i % 2) == 1) {
            v_d = v_d * 2
            if (v_d > 9) {
                v_d = v_d - 9
            }
        }
        v_total = v_total + v_d
    }
    return (v_total % 10)
}

func v_runLengths(v_n int64, v_s int64) int64 {
    var v_prev int64 = (-1)
    var v_size int64 = 0
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_v int64 = (v_val(v_i, v_s) % 3)
        if (v_v == v_prev) {
            v_size = v_size + 1
        } else {
            v_t = v_t + (v_size * v_size)
            v_size = 1
            v_prev = v_v
        }
    }
    return (v_t + (v_size * v_size))
}

func v_varintLength(v_n int64, v_s int64) int64 {
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = ((v_i + v_val(v_i, v_s)) * (v_s + 1))
        v_t = v_t + 1
        for (v_x >= 128) {
            v_t = v_t + 1
            v_x = (v_x / 128)
        }
    }
    return v_t
}

func v_decimalFields(v_n int64, v_s int64) int64 {
    var v_value int64 = 0
    var v_total int64 = 0
    var v_digits int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_token int64 = (v_val(v_i, v_s) % 13)
        if ((v_token < 10) && (v_digits < 8)) {
            v_value = ((v_value * 10) + v_token)
            v_digits = v_digits + 1
        } else {
            v_total = v_total + v_value
            v_value = 0
            v_digits = 0
        }
    }
    return (v_total + v_value)
}

func v_csvQuoted(v_n int64, v_s int64) int64 {
    var v_quoted int64 = 0
    var v_fields int64 = 1
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_c int64 = (v_val(v_i, v_s) % 17)
        if (v_c == 0) {
            v_quoted = (1 - v_quoted)
        }
        if ((v_c == 1) && (v_quoted == 0)) {
            v_fields = v_fields + 1
        }
    }
    return v_fields
}

func v_bracketDepth(v_n int64, v_s int64) int64 {
    var v_depth int64 = 0
    var v_errors int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_k int64 = (v_val(v_i, v_s) % 5)
        if (v_k == 0) {
            v_depth = v_depth + 1
        }
        if (v_k == 1) {
            if (v_depth == 0) {
                v_errors = v_errors + 1
            } else {
                v_depth = v_depth - 1
            }
        }
    }
    return (v_errors + v_depth)
}

func v_utf8Widths(v_n int64, v_s int64) int64 {
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_cp int64 = (((v_val(v_i, v_s) * 1237) + v_i) % 1114112)
        var v_width int64 = 1
        if (v_cp >= 128) {
            v_width = v_width + 1
        }
        if (v_cp >= 2048) {
            v_width = v_width + 1
        }
        if (v_cp >= 65536) {
            v_width = v_width + 1
        }
        v_total = v_total + v_width
    }
    return v_total
}

func v_patternAutomaton(v_n int64, v_s int64) int64 {
    var v_state int64 = 0
    var v_hits int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = (v_val(v_i, v_s) % 3)
        if (v_x == 0) {
            if (v_state == 2) {
                v_hits = v_hits + 1
            }
            v_state = 1
        } else {
            if ((v_x == 1) && (v_state == 1)) {
                v_state = 2
            } else {
                v_state = 0
            }
        }
    }
    return v_hits
}

func v_zigzagDelta(v_n int64, v_s int64) int64 {
    var v_last int64 = 0
    var v_total int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = v_val(v_i, v_s)
        var v_d int64 = (v_x - v_last)
        if (v_d < 0) {
            v_total = v_total + (((0 - v_d) * 2) - 1)
        } else {
            v_total = v_total + (v_d * 2)
        }
        v_last = v_x
    }
    return v_total
}

func v_packedNibbles(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_i := int64(0); v_i < (v_n / 2); v_i++ {
        var v_byte int64 = (((v_a[(2 * v_i)] % 16) * 16) + (v_a[((2 * v_i) + 1)] % 16))
        v_t = v_t + (v_byte * ((v_i % 7) + 1))
    }
    return v_t
}

func v_tokenBucket(v_n int64, v_s int64) int64 {
    var v_credit int64 = 65
    var v_ok int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        v_credit = v_low(100, (v_credit + 5))
        var v_request int64 = (v_val(v_i, v_s) % 16)
        if (v_credit >= v_request) {
            v_credit = v_credit - v_request
            v_ok = v_ok + 1
        }
    }
    return v_ok
}

func v_orderBookLevel(v_n int64, v_s int64) int64 {
    v_bids := make([]int64, 128)
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = v_val(v_i, v_s)
        var v_index int64 = (v_x % 128)
        if ((v_x % 3) == 0) {
            var v_used int64 = v_low(v_bids[v_index], (v_x % 19))
            v_bids[v_index] = v_bids[v_index] - v_used
            v_t = v_t + v_used
        } else {
            v_bids[v_index] = v_bids[v_index] + (v_x % 23)
        }
    }
    return v_t
}

func v_roundRobin(v_n int64, v_s int64) int64 {
    v_budget := make([]int64, 17)
    for v_i := int64(0); v_i < 17; v_i++ {
        v_budget[v_i] = (v_val(v_i, v_s) + 1)
    }
    var v_served int64 = 0
    var v_p int64 = 0
    for v_j := int64(0); v_j < v_n; v_j++ {
        var v_take int64 = v_low(13, v_budget[v_p])
        v_served = v_served + v_take
        v_budget[v_p] = v_budget[v_p] - v_take
        if (v_budget[v_p] == 0) {
            v_budget[v_p] = (v_val(v_j, v_s) + 1)
        }
        v_p = ((v_p + 1) % 17)
    }
    return v_served
}

func v_inventoryReorder(v_n int64, v_s int64) int64 {
    v_stock := make([]int64, 61)
    for ii := range v_stock { v_stock[ii] = 20 }
    var v_orders int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_k int64 = (v_val(v_i, v_s) % 61)
        v_stock[v_k] = v_stock[v_k] - (v_i % 5)
        if (v_stock[v_k] < 5) {
            v_stock[v_k] = v_stock[v_k] + 24
            v_orders = v_orders + 1
        }
    }
    return v_orders
}

func v_thermostat(v_n int64, v_s int64) int64 {
    var v_temp int64 = 190
    var v_power int64 = 0
    var v_consumed int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        if (v_temp < 184) {
            v_power = 1
        }
        if (v_temp > 211) {
            v_power = 0
        }
        v_temp = v_temp + ((v_power * 5) - (v_val(v_i, v_s) % 6))
        v_consumed = v_consumed + v_power
    }
    return v_consumed
}

func v_resampleLinear(v_n int64, v_s int64) int64 {
    v_a := make([]int64, v_n)
    for ix := int64(0); ix < v_n; ix++ {
        v_a[ix] = v_val(ix, v_s)
    }
    var v_t int64 = 0
    for v_j := int64(0); v_j < ((v_n * 3) - 3); v_j++ {
        var v_p int64 = (v_j / 3)
        var v_fraction int64 = (v_j % 3)
        v_t = v_t + (((v_a[v_p] * (3 - v_fraction)) + (v_a[(v_p + 1)] * v_fraction)) / 3)
    }
    return v_t
}

func v_envelopeFollower(v_n int64, v_s int64) int64 {
    var v_env int64 = 0
    var v_t int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_x int64 = v_val(v_i, v_s)
        if (v_x > v_env) {
            v_env = v_env + (((v_x - v_env) + 1) / 2)
        } else {
            v_env = v_env - ((v_env - v_x) / 8)
        }
        v_t = v_t + v_env
    }
    return v_t
}

func v_telemetryBuckets(v_n int64, v_s int64) int64 {
    v_b := make([]int64, 11)
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_v int64 = (v_val(v_i, v_s) + 1)
        var v_level int64 = 0
        for (v_v > 1) {
            v_v = (v_v / 2)
            v_level = v_level + 1
        }
        v_b[v_level] = v_b[v_level] + 1
    }
    var v_target int64 = ((v_n * 9) / 10)
    var v_k int64 = 0
    for (v_target > v_b[v_k]) {
        v_target = v_target - v_b[v_k]
        v_k = v_k + 1
    }
    return v_k
}

func v_backoffSimulation(v_n int64, v_s int64) int64 {
    var v_delay int64 = 1
    var v_elapsed int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        if ((v_val(v_i, v_s) % 4) != 0) {
            v_delay = 1
        } else {
            v_delay = v_low(128, (v_delay * 2))
        }
        v_elapsed = v_elapsed + v_delay
    }
    return v_elapsed
}

func v_packetJitter(v_n int64, v_s int64) int64 {
    var v_previous int64 = 0
    var v_jitter int64 = 0
    for v_i := int64(0); v_i < v_n; v_i++ {
        var v_transit int64 = (v_val(v_i, v_s) % 127)
        var v_delta int64 = v_dist(v_transit, v_previous)
        v_jitter = (((15 * v_jitter) + (16 * v_delta)) / 16)
        v_previous = v_transit
    }
    return v_jitter
}

func v_group0(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 0) {
        return v_euclidBatch(v_n, v_s)
    }
    if (v_id == 1) {
        return v_primeTrial(v_n, v_s)
    }
    if (v_id == 2) {
        return v_modularPower(v_n, v_s)
    }
    if (v_id == 3) {
        return v_newtonRoot(v_n, v_s)
    }
    if (v_id == 4) {
        return v_digitSum(v_n, v_s)
    }
    if (v_id == 5) {
        return v_binomialRows(v_n, v_s)
    }
    if (v_id == 6) {
        return v_factorMultiplicity(v_n, v_s)
    }
    if (v_id == 7) {
        return v_binaryOnes(v_n, v_s)
    }
    if (v_id == 8) {
        return v_totientBatch(v_n, v_s)
    }
    if (v_id == 9) {
        return v_divisorsPaired(v_n, v_s)
    }
    return 0
}

func v_group1(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 10) {
        return v_affineStream(v_n, v_s)
    }
    if (v_id == 11) {
        return v_fibonacciMod(v_n, v_s)
    }
    if (v_id == 12) {
        return v_adlerStream(v_n, v_s)
    }
    if (v_id == 13) {
        return v_polynomialHash(v_n, v_s)
    }
    if (v_id == 14) {
        return v_exponentialFilter(v_n, v_s)
    }
    if (v_id == 15) {
        return v_hysteresis(v_n, v_s)
    }
    if (v_id == 16) {
        return v_longestStreak(v_n, v_s)
    }
    if (v_id == 17) {
        return v_majorityVote(v_n, v_s)
    }
    if (v_id == 18) {
        return v_crossingCount(v_n, v_s)
    }
    if (v_id == 19) {
        return v_cumulativeDrawdown(v_n, v_s)
    }
    return 0
}

func v_group2(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 20) {
        return v_insertionSort(v_n, v_s)
    }
    if (v_id == 21) {
        return v_selectionSort(v_n, v_s)
    }
    if (v_id == 22) {
        return v_bubbleEarly(v_n, v_s)
    }
    if (v_id == 23) {
        return v_shellSort(v_n, v_s)
    }
    if (v_id == 24) {
        return v_countingRank(v_n, v_s)
    }
    if (v_id == 25) {
        return v_lowerBound(v_n, v_s)
    }
    if (v_id == 26) {
        return v_sentinelFind(v_n, v_s)
    }
    if (v_id == 27) {
        return v_partitionPivot(v_n, v_s)
    }
    if (v_id == 28) {
        return v_mergeRuns(v_n, v_s)
    }
    if (v_id == 29) {
        return v_heapBuild(v_n, v_s)
    }
    return 0
}

func v_group3(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 30) {
        return v_reverseBuffer(v_n, v_s)
    }
    if (v_id == 31) {
        return v_rotateCycles(v_n, v_s)
    }
    if (v_id == 32) {
        return v_strideGather(v_n, v_s)
    }
    if (v_id == 33) {
        return v_permutedScatter(v_n, v_s)
    }
    if (v_id == 34) {
        return v_chainedLoads(v_n, v_s)
    }
    if (v_id == 35) {
        return v_copyIsolation(v_n, v_s)
    }
    if (v_id == 36) {
        return v_scopeChurn(v_n, v_s)
    }
    if (v_id == 37) {
        return v_compactStable(v_n, v_s)
    }
    if (v_id == 38) {
        return v_interleaveBuffers(v_n, v_s)
    }
    if (v_id == 39) {
        return v_sparsePages(v_n, v_s)
    }
    return 0
}

func v_group4(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 40) {
        return v_dotProduct(v_n, v_s)
    }
    if (v_id == 41) {
        return v_integerVariance(v_n, v_s)
    }
    if (v_id == 42) {
        return v_frequencyMode(v_n, v_s)
    }
    if (v_id == 43) {
        return v_slidingWindow(v_n, v_s)
    }
    if (v_id == 44) {
        return v_prefixQueries(v_n, v_s)
    }
    if (v_id == 45) {
        return v_minmaxSpan(v_n, v_s)
    }
    if (v_id == 46) {
        return v_normalizedCov(v_n, v_s)
    }
    if (v_id == 47) {
        return v_lowpassMedian(v_n, v_s)
    }
    if (v_id == 48) {
        return v_lagCorrelation(v_n, v_s)
    }
    if (v_id == 49) {
        return v_trimmedThreshold(v_n, v_s)
    }
    return 0
}

func v_group5(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 50) {
        return v_matrixMultiply(v_n, v_s)
    }
    if (v_id == 51) {
        return v_matrixTranspose(v_n, v_s)
    }
    if (v_id == 52) {
        return v_fivePoint(v_n, v_s)
    }
    if (v_id == 53) {
        return v_sobelHorizontal(v_n, v_s)
    }
    if (v_id == 54) {
        return v_summedArea(v_n, v_s)
    }
    if (v_id == 55) {
        return v_lifeOneStep(v_n, v_s)
    }
    if (v_id == 56) {
        return v_diagonalEnergy(v_n, v_s)
    }
    if (v_id == 57) {
        return v_triangularSolve(v_n, v_s)
    }
    if (v_id == 58) {
        return v_rowNormalize(v_n, v_s)
    }
    if (v_id == 59) {
        return v_maxPool(v_n, v_s)
    }
    return 0
}

func v_group6(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 60) {
        return v_editDistance(v_n, v_s)
    }
    if (v_id == 61) {
        return v_commonSubsequence(v_n, v_s)
    }
    if (v_id == 62) {
        return v_knapsack(v_n, v_s)
    }
    if (v_id == 63) {
        return v_coinMinimum(v_n, v_s)
    }
    if (v_id == 64) {
        return v_increasingSubseq(v_n, v_s)
    }
    if (v_id == 65) {
        return v_gridMinPath(v_n, v_s)
    }
    if (v_id == 66) {
        return v_maxNonAdjacent(v_n, v_s)
    }
    if (v_id == 67) {
        return v_rodCut(v_n, v_s)
    }
    if (v_id == 68) {
        return v_segmentGain(v_n, v_s)
    }
    if (v_id == 69) {
        return v_subsetReach(v_n, v_s)
    }
    return 0
}

func v_group7(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 70) {
        return v_unionFind(v_n, v_s)
    }
    if (v_id == 71) {
        return v_fenwickUpdateQuery(v_n, v_s)
    }
    if (v_id == 72) {
        return v_ringQueue(v_n, v_s)
    }
    if (v_id == 73) {
        return v_monotoneStack(v_n, v_s)
    }
    if (v_id == 74) {
        return v_openAddress(v_n, v_s)
    }
    if (v_id == 75) {
        return v_floydDistances(v_n, v_s)
    }
    if (v_id == 76) {
        return v_breadthFirst(v_n, v_s)
    }
    if (v_id == 77) {
        return v_treeFold(v_n, v_s)
    }
    if (v_id == 78) {
        return v_sparseEdges(v_n, v_s)
    }
    if (v_id == 79) {
        return v_intervalSweep(v_n, v_s)
    }
    return 0
}

func v_group8(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 80) {
        return v_luhnDigits(v_n, v_s)
    }
    if (v_id == 81) {
        return v_runLengths(v_n, v_s)
    }
    if (v_id == 82) {
        return v_varintLength(v_n, v_s)
    }
    if (v_id == 83) {
        return v_decimalFields(v_n, v_s)
    }
    if (v_id == 84) {
        return v_csvQuoted(v_n, v_s)
    }
    if (v_id == 85) {
        return v_bracketDepth(v_n, v_s)
    }
    if (v_id == 86) {
        return v_utf8Widths(v_n, v_s)
    }
    if (v_id == 87) {
        return v_patternAutomaton(v_n, v_s)
    }
    if (v_id == 88) {
        return v_zigzagDelta(v_n, v_s)
    }
    if (v_id == 89) {
        return v_packedNibbles(v_n, v_s)
    }
    return 0
}

func v_group9(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id == 90) {
        return v_tokenBucket(v_n, v_s)
    }
    if (v_id == 91) {
        return v_orderBookLevel(v_n, v_s)
    }
    if (v_id == 92) {
        return v_roundRobin(v_n, v_s)
    }
    if (v_id == 93) {
        return v_inventoryReorder(v_n, v_s)
    }
    if (v_id == 94) {
        return v_thermostat(v_n, v_s)
    }
    if (v_id == 95) {
        return v_resampleLinear(v_n, v_s)
    }
    if (v_id == 96) {
        return v_envelopeFollower(v_n, v_s)
    }
    if (v_id == 97) {
        return v_telemetryBuckets(v_n, v_s)
    }
    if (v_id == 98) {
        return v_backoffSimulation(v_n, v_s)
    }
    if (v_id == 99) {
        return v_packetJitter(v_n, v_s)
    }
    return 0
}

func v_dispatch(v_id int64, v_n int64, v_s int64) int64 {
    if (v_id < 10) {
        return v_group0(v_id, v_n, v_s)
    }
    if (v_id < 20) {
        return v_group1(v_id, v_n, v_s)
    }
    if (v_id < 30) {
        return v_group2(v_id, v_n, v_s)
    }
    if (v_id < 40) {
        return v_group3(v_id, v_n, v_s)
    }
    if (v_id < 50) {
        return v_group4(v_id, v_n, v_s)
    }
    if (v_id < 60) {
        return v_group5(v_id, v_n, v_s)
    }
    if (v_id < 70) {
        return v_group6(v_id, v_n, v_s)
    }
    if (v_id < 80) {
        return v_group7(v_id, v_n, v_s)
    }
    if (v_id < 90) {
        return v_group8(v_id, v_n, v_s)
    }
    if (v_id < 100) {
        return v_group9(v_id, v_n, v_s)
    }
    return 0
}

