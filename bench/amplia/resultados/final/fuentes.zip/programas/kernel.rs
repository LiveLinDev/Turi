#![allow(unused_parens, unused_mut, unused_variables, non_snake_case)]
fn v_val(v_i: i64, v_s: i64) -> i64 {
    let mut v_x: i64 = (((v_i * 73) + (v_s * 101)) % 1009);
    return ((((v_x * v_x) + (17 * v_x)) + 19) % 1009);
}

fn v_low(v_x: i64, v_y: i64) -> i64 {
    if (v_x < v_y) {
        return v_x;
    }
    return v_y;
}

fn v_high(v_x: i64, v_y: i64) -> i64 {
    if (v_x > v_y) {
        return v_x;
    }
    return v_y;
}

fn v_dist(v_x: i64, v_y: i64) -> i64 {
    if (v_x >= v_y) {
        return (v_x - v_y);
    }
    return (v_y - v_x);
}

fn v_euclidBatch(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_a: i64 = (v_val(v_i, v_s) + 1);
        let mut v_b: i64 = (v_i + 19);
        while (v_b > 0) {
            let mut v_r: i64 = (v_a % v_b);
            v_a = v_b;
            v_b = v_r;
        }
        v_total = v_total + v_a;
    }
    return v_total;
}

fn v_primeTrial(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_a: i64 = ((v_i + v_s) + 2);
        let mut v_d: i64 = 2;
        while (((v_d * v_d) <= v_a) && ((v_a % v_d) != 0)) {
            v_d = v_d + 1;
        }
        if ((v_d * v_d) > v_a) {
            v_total = v_total + 1;
        }
    }
    return v_total;
}

fn v_modularPower(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_e: i64 = v_val(v_i, v_s);
        let mut v_b: i64 = (v_i + 3);
        let mut v_v: i64 = 1;
        while (v_e > 0) {
            if ((v_e % 2) == 1) {
                v_v = ((v_v * v_b) % 65521);
            }
            v_b = ((v_b * v_b) % 65521);
            v_e = (v_e / 2);
        }
        v_total = v_total + v_v;
    }
    return v_total;
}

fn v_newtonRoot(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_a: i64 = (((v_i + v_s) * 97) + 1);
        let mut v_x: i64 = v_a;
        let mut v_y: i64 = ((v_x + 1) / 2);
        while (v_y < v_x) {
            v_x = v_y;
            v_y = ((v_x + (v_a / v_x)) / 2);
        }
        v_total = v_total + v_x;
    }
    return v_total;
}

fn v_digitSum(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_a: i64 = ((v_i + 1) * (v_s + 1));
        while (v_a > 0) {
            v_total = v_total + (v_a % 10);
            v_a = (v_a / 10);
        }
    }
    return v_total;
}

fn v_binomialRows(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_a: i64 = (((v_i + v_s) % 27) + 1);
        let mut v_v: i64 = 1;
        for v_j in 1..(v_a + 1) {
            v_v = ((v_v * ((v_a + 1) - v_j)) / v_j);
            v_total = v_total + v_v;
        }
    }
    return v_total;
}

fn v_factorMultiplicity(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = (v_val(v_i, v_s) + 1);
        let mut v_d: i64 = 2;
        while ((v_d * v_d) <= v_x) {
            while ((v_x % v_d) == 0) {
                v_total = v_total + 1;
                v_x = (v_x / v_d);
            }
            v_d = v_d + 1;
        }
        if (v_x > 1) {
            v_total = v_total + 1;
        }
    }
    return v_total;
}

fn v_binaryOnes(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = ((v_val(v_i, v_s) * 177) + v_i);
        while (v_x > 0) {
            v_total = v_total + (v_x % 2);
            v_x = (v_x / 2);
        }
    }
    return v_total;
}

fn v_totientBatch(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = (v_val(v_i, v_s) + 1);
        let mut v_phi: i64 = v_x;
        let mut v_d: i64 = 2;
        while ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_phi = v_phi - (v_phi / v_d);
                while ((v_x % v_d) == 0) {
                    v_x = (v_x / v_d);
                }
            }
            v_d = v_d + 1;
        }
        if (v_x > 1) {
            v_phi = v_phi - (v_phi / v_x);
        }
        v_total = v_total + v_phi;
    }
    return v_total;
}

fn v_divisorsPaired(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = (v_val(v_i, v_s) + 1);
        let mut v_d: i64 = 1;
        while ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_total = v_total + v_d;
                if ((v_d * v_d) != v_x) {
                    v_total = v_total + (v_x / v_d);
                }
            }
            v_d = v_d + 1;
        }
    }
    return v_total;
}

fn v_affineStream(v_n: i64, v_s: i64) -> i64 {
    let mut v_x: i64 = v_s;
    for v_i in 0..v_n {
        v_x = (((v_x * 48271) + 1) % 2147483647);
    }
    return v_x;
}

fn v_fibonacciMod(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: i64 = 0;
    let mut v_b: i64 = v_s;
    for v_i in 0..v_n {
        let mut v_c: i64 = ((v_a + v_b) % 65521);
        v_a = v_b;
        v_b = v_c;
    }
    return v_b;
}

fn v_adlerStream(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: i64 = 1;
    let mut v_b: i64 = 0;
    for v_i in 0..v_n {
        v_a = ((v_a + (v_val(v_i, v_s) % 256)) % 65521);
        v_b = ((v_b + v_a) % 65521);
    }
    return ((v_b * 65536) + v_a);
}

fn v_polynomialHash(v_n: i64, v_s: i64) -> i64 {
    let mut v_h: i64 = 0;
    for v_i in 0..v_n {
        v_h = (((v_h * 257) + v_val(v_i, v_s)) % 1000003);
    }
    return v_h;
}

fn v_exponentialFilter(v_n: i64, v_s: i64) -> i64 {
    let mut v_state: i64 = 0;
    for v_i in 0..v_n {
        v_state = (((v_state * 7) + (v_val(v_i, v_s) * 8)) / 8);
    }
    return v_state;
}

fn v_hysteresis(v_n: i64, v_s: i64) -> i64 {
    let mut v_state: i64 = 0;
    let mut v_transitions: i64 = 0;
    for v_i in 0..v_n {
        let mut v_v: i64 = v_val(v_i, v_s);
        if ((v_state == 0) && (v_v > 765)) {
            v_state = 1;
            v_transitions = v_transitions + 1;
        }
        if ((v_state == 1) && (v_v < 201)) {
            v_state = 0;
        }
    }
    return v_transitions;
}

fn v_longestStreak(v_n: i64, v_s: i64) -> i64 {
    let mut v_streak: i64 = 0;
    let mut v_best: i64 = 0;
    for v_i in 0..v_n {
        if ((v_val(v_i, v_s) % 3) != 0) {
            v_streak = v_streak + 1;
            v_best = v_high(v_best, v_streak);
        } else {
            v_streak = 0;
        }
    }
    return v_best;
}

fn v_majorityVote(v_n: i64, v_s: i64) -> i64 {
    let mut v_balance: i64 = 0;
    let mut v_candidate: i64 = 0;
    for v_i in 0..v_n {
        let mut v_v: i64 = (v_val(v_i, v_s) % 7);
        if (v_balance == 0) {
            v_candidate = v_v;
        }
        if (v_candidate == v_v) {
            v_balance = v_balance + 1;
        } else {
            v_balance = v_balance - 1;
        }
    }
    return ((v_candidate * 100) + v_balance);
}

fn v_crossingCount(v_n: i64, v_s: i64) -> i64 {
    let mut v_prev: i64 = (v_s % 1009);
    let mut v_count: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = v_val(v_i, v_s);
        if ((v_prev <= 500) && (v_x > 500)) {
            v_count = v_count + 1;
        }
        v_prev = v_x;
    }
    return v_count;
}

fn v_cumulativeDrawdown(v_n: i64, v_s: i64) -> i64 {
    let mut v_price: i64 = 1000;
    let mut v_peak: i64 = v_price;
    let mut v_draw: i64 = 0;
    for v_i in 0..v_n {
        v_price = v_price + ((v_val(v_i, v_s) % 31) - 15);
        v_peak = v_high(v_peak, v_price);
        v_draw = v_high(v_draw, (v_peak - v_price));
    }
    return v_draw;
}

fn v_insertionSort(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    for v_i in 1..v_n {
        let mut v_v: i64 = v_a[(v_i) as usize];
        let mut v_j: i64 = v_i;
        while ((v_j > 0) && (v_a[((v_j - 1)) as usize] > v_v)) {
            v_a[(v_j) as usize] = v_a[((v_j - 1)) as usize];
            v_j = v_j - 1;
        }
        v_a[(v_j) as usize] = v_v;
    }
    return (v_a[((v_n / 3)) as usize] + v_a[((v_n - 1)) as usize]);
}

fn v_selectionSort(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    for v_i in 0..v_n {
        let mut v_k: i64 = v_i;
        for v_j in (v_i + 1)..v_n {
            if (v_a[(v_j) as usize] < v_a[(v_k) as usize]) {
                v_k = v_j;
            }
        }
        let mut v_v: i64 = v_a[(v_k) as usize];
        v_a[(v_k) as usize] = v_a[(v_i) as usize];
        v_a[(v_i) as usize] = v_v;
    }
    return (v_a[((v_n / 2)) as usize] + v_a[(0) as usize]);
}

fn v_bubbleEarly(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_edge: i64 = v_n;
    while (v_edge > 1) {
        let mut v_last: i64 = 0;
        for v_j in 1..v_edge {
            if (v_a[((v_j - 1)) as usize] > v_a[(v_j) as usize]) {
                let mut v_v: i64 = v_a[(v_j) as usize];
                v_a[(v_j) as usize] = v_a[((v_j - 1)) as usize];
                v_a[((v_j - 1)) as usize] = v_v;
                v_last = v_j;
            }
        }
        v_edge = v_last;
    }
    return (v_a[((v_n / 4)) as usize] + v_a[((v_n - 1)) as usize]);
}

fn v_shellSort(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_gap: i64 = (v_n / 2);
    while (v_gap > 0) {
        for v_i in v_gap..v_n {
            let mut v_v: i64 = v_a[(v_i) as usize];
            let mut v_j: i64 = v_i;
            while ((v_j >= v_gap) && (v_a[((v_j - v_gap)) as usize] > v_v)) {
                v_a[(v_j) as usize] = v_a[((v_j - v_gap)) as usize];
                v_j = v_j - v_gap;
            }
            v_a[(v_j) as usize] = v_v;
        }
        v_gap = (v_gap / 2);
    }
    return v_a[((v_n / 2)) as usize];
}

fn v_countingRank(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_h: Vec<i64> = vec![0; (1009) as usize];
    for v_i in 0..v_n {
        v_h[(v_a[(v_i) as usize]) as usize] = v_h[(v_a[(v_i) as usize]) as usize] + 1;
    }
    let mut v_rank: i64 = (v_n / 2);
    let mut v_v: i64 = 0;
    while (v_rank >= v_h[(v_v) as usize]) {
        v_rank = v_rank - v_h[(v_v) as usize];
        v_v = v_v + 1;
    }
    return v_v;
}

fn v_lowerBound(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for v_i in 0..v_n {
        v_a[(v_i) as usize] = ((v_i * 3) + (v_i / 5));
    }
    let mut v_t: i64 = 0;
    for v_j in 0..(v_n / 4) {
        let mut v_x: i64 = ((v_val(v_j, v_s) * 31) % (v_n * 4));
        let mut v_lo: i64 = 0;
        let mut v_hi: i64 = v_n;
        while (v_lo < v_hi) {
            let mut v_mid: i64 = ((v_lo + v_hi) / 2);
            if (v_a[(v_mid) as usize] < v_x) {
                v_lo = (v_mid + 1);
            } else {
                v_hi = v_mid;
            }
        }
        v_t = v_t + v_lo;
    }
    return v_t;
}

fn v_sentinelFind(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for ix in 0..(v_n + 1) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_q in 0..40 {
        let mut v_x: i64 = v_val((v_q + v_n), v_s);
        v_a[(v_n) as usize] = v_x;
        let mut v_j: i64 = 0;
        while (v_a[(v_j) as usize] != v_x) {
            v_j = v_j + 1;
        }
        v_t = v_t + v_j;
    }
    return v_t;
}

fn v_partitionPivot(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_pivot: i64 = v_a[((v_n / 2)) as usize];
    let mut v_left: i64 = 0;
    for v_i in 0..v_n {
        if (v_a[(v_i) as usize] < v_pivot) {
            let mut v_v: i64 = v_a[(v_left) as usize];
            v_a[(v_left) as usize] = v_a[(v_i) as usize];
            v_a[(v_i) as usize] = v_v;
            v_left = v_left + 1;
        }
    }
    return (v_left + v_a[((v_n / 2)) as usize]);
}

fn v_mergeRuns(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    let mut v_b: Vec<i64> = vec![0; (v_n) as usize];
    let mut v_x: i64 = 0;
    let mut v_y: i64 = 0;
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        v_x = v_x + (v_val(v_i, v_s) % 7);
        v_y = v_y + (v_val((v_i + 3), v_s) % 11);
        v_a[(v_i) as usize] = v_x;
        v_b[(v_i) as usize] = v_y;
    }
    let mut v_l: i64 = 0;
    let mut v_r: i64 = 0;
    for v_k in 0..(v_n * 2) {
        if ((v_r == v_n) || ((v_l < v_n) && (v_a[(v_l) as usize] <= v_b[(v_r) as usize]))) {
            v_t = v_t + (v_a[(v_l) as usize] * (v_k % 7));
            v_l = v_l + 1;
        } else {
            v_t = v_t + (v_b[(v_r) as usize] * (v_k % 7));
            v_r = v_r + 1;
        }
    }
    return v_t;
}

fn v_heapBuild(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_i: i64 = (v_n / 2);
    while (v_i > 0) {
        v_i = v_i - 1;
        let mut v_root: i64 = v_i;
        let mut v_child: i64 = ((2 * v_root) + 1);
        while (v_child < v_n) {
            if (((v_child + 1) < v_n) && (v_a[((v_child + 1)) as usize] > v_a[(v_child) as usize])) {
                v_child = v_child + 1;
            }
            if (v_a[(v_root) as usize] >= v_a[(v_child) as usize]) {
                v_child = v_n;
            } else {
                let mut v_v: i64 = v_a[(v_root) as usize];
                v_a[(v_root) as usize] = v_a[(v_child) as usize];
                v_a[(v_child) as usize] = v_v;
                v_root = v_child;
                v_child = ((2 * v_root) + 1);
            }
        }
    }
    return (v_a[(0) as usize] + v_a[((v_n / 3)) as usize]);
}

fn v_reverseBuffer(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    for v_i in 0..(v_n / 2) {
        let mut v_j: i64 = ((v_n - 1) - v_i);
        let mut v_t: i64 = v_a[(v_i) as usize];
        v_a[(v_i) as usize] = v_a[(v_j) as usize];
        v_a[(v_j) as usize] = v_t;
    }
    let mut v_total: i64 = 0;
    for v_k in 0..v_n {
        v_total = v_total + (v_a[(v_k) as usize] * (v_k % 11));
    }
    return v_total;
}

fn v_rotateCycles(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = v_a[((v_n - 1)) as usize];
    for v_i in 1..v_n {
        v_a[((v_n - v_i)) as usize] = v_a[(((v_n - v_i) - 1)) as usize];
    }
    v_a[(0) as usize] = v_t;
    let mut v_total: i64 = 0;
    for v_j in 0..v_n {
        v_total = v_total + (v_a[(v_j) as usize] * (v_j % 17));
    }
    return v_total;
}

fn v_strideGather(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    let mut v_pos: i64 = 0;
    for v_i in 0..v_n {
        v_t = v_t + v_a[(v_pos) as usize];
        v_pos = ((v_pos + 61) % v_n);
    }
    return v_t;
}

fn v_permutedScatter(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    let mut v_j: i64 = (v_s % v_n);
    for v_i in 0..v_n {
        v_a[(v_j) as usize] = (v_i + 1);
        v_j = ((v_j + 31) % v_n);
    }
    let mut v_t: i64 = 0;
    for v_k in 0..v_n {
        v_t = v_t + (v_a[(v_k) as usize] * (v_k % 5));
    }
    return v_t;
}

fn v_chainedLoads(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    for v_i in 0..v_n {
        v_a[(v_i) as usize] = ((v_a[(v_i) as usize] + (v_i * 59)) % v_n);
    }
    let mut v_p: i64 = (v_s % v_n);
    let mut v_t: i64 = 0;
    for v_j in 0..v_n {
        v_p = v_a[(v_p) as usize];
        v_t = v_t + v_p;
    }
    return v_t;
}

fn v_copyIsolation(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = v_a.clone();
    for v_i in 0..v_n {
        if ((v_i % 3) == 0) {
            v_b[(v_i) as usize] = (v_a[(v_i) as usize] + v_i);
        }
    }
    let mut v_t: i64 = 0;
    for v_j in 0..v_n {
        v_t = v_t + ((v_b[(v_j) as usize] * 3) - v_a[(v_j) as usize]);
    }
    return v_t;
}

fn v_scopeChurn(v_n: i64, v_s: i64) -> i64 {
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_width: i64 = ((v_val(v_i, v_s) % 377) + 4);
        let mut v_a: Vec<i64> = vec![v_i; (v_width) as usize];
        for v_j in 0..v_width {
            v_a[(v_j) as usize] = ((v_a[(v_j) as usize] + (v_j * 17)) % 173);
        }
        v_t = v_t + v_a[(((v_i + v_s) % v_width)) as usize];
    }
    return v_t;
}

fn v_compactStable(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_write: i64 = 0;
    for v_i in 0..v_n {
        if ((v_a[(v_i) as usize] % 3) == 0) {
            v_a[(v_write) as usize] = v_a[(v_i) as usize];
            v_write = v_write + 1;
        }
    }
    let mut v_t: i64 = 0;
    for v_j in 0..v_write {
        v_t = v_t + (v_a[(v_j) as usize] * (v_j % 5));
    }
    return v_t;
}

fn v_interleaveBuffers(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_b[ix as usize] = v_val(ix, (v_s + 1));
    }
    let mut v_c: Vec<i64> = vec![0; ((v_n * 2)) as usize];
    for v_i in 0..v_n {
        v_c[((2 * v_i)) as usize] = v_a[(v_i) as usize];
        v_c[(((2 * v_i) + 1)) as usize] = v_b[(v_i) as usize];
    }
    let mut v_t: i64 = 0;
    for v_j in 1..(v_n * 2) {
        v_t = v_t + v_dist(v_c[(v_j) as usize], v_c[((v_j - 1)) as usize]);
    }
    return v_t;
}

fn v_sparsePages(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![v_s; (v_n) as usize];
    for v_i in 0..((v_n + 511) / 512) {
        v_a[((v_i * 512)) as usize] = v_val(v_i, v_s);
    }
    let mut v_t: i64 = 0;
    for v_k in 0..v_n {
        v_t = v_t + v_a[(v_k) as usize];
    }
    return v_t;
}

fn v_dotProduct(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_b[ix as usize] = v_val(ix, (v_s + 1));
    }
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        v_t = v_t + (v_a[(v_i) as usize] * v_b[(v_i) as usize]);
    }
    return v_t;
}

fn v_integerVariance(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        v_t = v_t + v_a[(v_i) as usize];
    }
    let mut v_mean: i64 = (v_t / v_n);
    let mut v_v: i64 = 0;
    for v_j in 0..v_n {
        let mut v_d: i64 = (v_a[(v_j) as usize] - v_mean);
        v_v = v_v + (v_d * v_d);
    }
    return v_v;
}

fn v_frequencyMode(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (257) as usize];
    for v_i in 0..v_n {
        v_a[((v_val(v_i, v_s) % 257)) as usize] = v_a[((v_val(v_i, v_s) % 257)) as usize] + 1;
    }
    let mut v_best: i64 = 0;
    for v_k in 1..257 {
        if (v_a[(v_k) as usize] > v_a[(v_best) as usize]) {
            v_best = v_k;
        }
    }
    return v_best;
}

fn v_slidingWindow(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_window: i64 = 0;
    let mut v_best: i64 = 0;
    for v_i in 0..v_n {
        v_window = v_window + v_a[(v_i) as usize];
        if (v_i >= 23) {
            v_window = v_window - v_a[((v_i - 23)) as usize];
        }
        v_best = v_high(v_best, v_window);
    }
    return v_best;
}

fn v_prefixQueries(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for v_i in 0..v_n {
        v_a[((v_i + 1)) as usize] = (v_a[(v_i) as usize] + v_val(v_i, v_s));
    }
    let mut v_t: i64 = 0;
    for v_j in 0..(v_n / 4) {
        let mut v_lo: i64 = (v_val(v_j, v_s) % v_n);
        let mut v_hi: i64 = (v_lo + (v_val((v_j + 1), v_s) % (v_n - v_lo)));
        v_t = v_t + (v_a[((v_hi + 1)) as usize] - v_a[(v_lo) as usize]);
    }
    return v_t;
}

fn v_minmaxSpan(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_mn: i64 = v_a[(0) as usize];
    let mut v_mx: i64 = v_a[(0) as usize];
    for v_i in 1..v_n {
        v_mn = v_low(v_mn, v_a[(v_i) as usize]);
        v_mx = v_high(v_mx, v_a[(v_i) as usize]);
    }
    return (v_mx - v_mn);
}

fn v_normalizedCov(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_b[ix as usize] = v_val(ix, (v_s + 2));
    }
    let mut v_x: i64 = 0;
    let mut v_y: i64 = 0;
    let mut v_xy: i64 = 0;
    for v_i in 0..v_n {
        v_x = v_x + v_a[(v_i) as usize];
        v_y = v_y + v_b[(v_i) as usize];
        v_xy = v_xy + (v_a[(v_i) as usize] * v_b[(v_i) as usize]);
    }
    return ((v_n * v_xy) - (v_x * v_y));
}

fn v_lowpassMedian(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_total: i64 = 0;
    for v_i in 2..v_n {
        let mut v_x: i64 = v_low(v_a[(v_i) as usize], v_a[((v_i - 1)) as usize]);
        let mut v_y: i64 = v_high(v_a[(v_i) as usize], v_a[((v_i - 1)) as usize]);
        v_total = v_total + v_high(v_x, v_low(v_a[((v_i - 2)) as usize], v_y));
    }
    return v_total;
}

fn v_lagCorrelation(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    let mut v_lag: i64 = ((v_s % 23) + 1);
    for v_i in v_lag..v_n {
        v_t = v_t + ((v_a[(v_i) as usize] - 500) * (v_a[((v_i - v_lag)) as usize] - 500));
    }
    return v_t;
}

fn v_trimmedThreshold(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    let mut v_count: i64 = 0;
    for v_i in 0..v_n {
        if ((v_a[(v_i) as usize] >= 100) && (v_a[(v_i) as usize] < 900)) {
            v_t = v_t + v_a[(v_i) as usize];
            v_count = v_count + 1;
        }
    }
    return (v_t / (v_count + 1));
}

fn v_matrixMultiply(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_b[ix as usize] = v_val(ix, (v_s + 1));
    }
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        for v_j in 0..v_n {
            let mut v_v: i64 = 0;
            for v_k in 0..v_n {
                v_v = v_v + (v_a[(((v_i * v_n) + v_k)) as usize] * v_b[(((v_k * v_n) + v_j)) as usize]);
            }
            v_t = v_t + (v_v % 101);
        }
    }
    return v_t;
}

fn v_matrixTranspose(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for v_i in 0..v_n {
        for v_j in 0..v_n {
            v_b[(((v_j * v_n) + v_i)) as usize] = v_a[(((v_i * v_n) + v_j)) as usize];
        }
    }
    let mut v_t: i64 = 0;
    for v_k in 0..(v_n * v_n) {
        v_t = v_t + (v_b[(v_k) as usize] * (v_k % 13));
    }
    return v_t;
}

fn v_fivePoint(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_i in 1..(v_n - 1) {
        for v_j in 1..(v_n - 1) {
            let mut v_p: i64 = ((v_i * v_n) + v_j);
            v_t = v_t + (((((v_a[(v_p) as usize] + v_a[((v_p - 1)) as usize]) + v_a[((v_p + 1)) as usize]) + v_a[((v_p - v_n)) as usize]) + v_a[((v_p + v_n)) as usize]) / 5);
        }
    }
    return v_t;
}

fn v_sobelHorizontal(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_i in 1..(v_n - 1) {
        for v_j in 1..(v_n - 1) {
            let mut v_p: i64 = ((v_i * v_n) + v_j);
            let mut v_l: i64 = ((v_a[(((v_p - v_n) - 1)) as usize] + (v_a[((v_p - 1)) as usize] * 2)) + v_a[(((v_p + v_n) - 1)) as usize]);
            let mut v_r: i64 = ((v_a[(((v_p - v_n) + 1)) as usize] + (v_a[((v_p + 1)) as usize] * 2)) + v_a[(((v_p + v_n) + 1)) as usize]);
            v_t = v_t + v_dist(v_l, v_r);
        }
    }
    return v_t;
}

fn v_summedArea(v_n: i64, v_s: i64) -> i64 {
    let mut v_p: Vec<i64> = vec![0; (((v_n + 1) * (v_n + 1))) as usize];
    let mut v_w: i64 = (v_n + 1);
    for v_i in 1..v_w {
        let mut v_row: i64 = 0;
        for v_j in 1..v_w {
            v_row = v_row + v_val(((v_i * v_w) + v_j), v_s);
            v_p[(((v_i * v_w) + v_j)) as usize] = (v_row + v_p[((((v_i - 1) * v_w) + v_j)) as usize]);
        }
    }
    return (v_p[(((v_n * v_w) + v_n)) as usize] + v_p[((((v_n / 2) * v_w) + (v_n / 3))) as usize]);
}

fn v_lifeOneStep(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_alive: i64 = 0;
    for v_i in 1..(v_n - 1) {
        for v_j in 1..(v_n - 1) {
            let mut v_p: i64 = ((v_i * v_n) + v_j);
            let mut v_count: i64 = 0;
            for v_y in 0..3 {
                for v_x in 0..3 {
                    if ((v_y != 1) || (v_x != 1)) {
                        v_count = v_count + (v_a[((((v_p + ((v_y - 1) * v_n)) + v_x) - 1)) as usize] % 2);
                    }
                }
            }
            if ((v_count == 3) || ((v_count == 2) && ((v_a[(v_p) as usize] % 2) == 1))) {
                v_alive = v_alive + 1;
            }
        }
    }
    return v_alive;
}

fn v_diagonalEnergy(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_d in 0..v_n {
        let mut v_v: i64 = 0;
        for v_i in 0..(v_n - v_d) {
            v_v = v_v + v_a[((((v_i * v_n) + v_i) + v_d)) as usize];
        }
        v_t = v_t + (v_v * v_v);
    }
    return v_t;
}

fn v_triangularSolve(v_n: i64, v_s: i64) -> i64 {
    let mut v_x: Vec<i64> = vec![0; (v_n) as usize];
    for v_i in 0..v_n {
        let mut v_v: i64 = v_val(v_i, v_s);
        for v_j in 0..v_i {
            v_v = v_v + ((v_val((v_i + v_j), v_s) % 5) * v_x[(v_j) as usize]);
        }
        v_x[(v_i) as usize] = (v_v % 997);
    }
    return v_x[((v_n - 1)) as usize];
}

fn v_rowNormalize(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_mx: i64 = 1;
        for v_j in 0..v_n {
            v_mx = v_high(v_mx, v_a[(((v_i * v_n) + v_j)) as usize]);
        }
        for v_k in 0..v_n {
            v_t = v_t + ((v_a[(((v_i * v_n) + v_k)) as usize] * 255) / v_mx);
        }
    }
    return v_t;
}

fn v_maxPool(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_i in 0..(v_n / 2) {
        for v_j in 0..(v_n / 2) {
            let mut v_p: i64 = (((2 * v_i) * v_n) + (2 * v_j));
            v_t = v_t + v_high(v_high(v_a[(v_p) as usize], v_a[((v_p + 1)) as usize]), v_high(v_a[((v_p + v_n)) as usize], v_a[(((v_p + v_n) + 1)) as usize]));
        }
    }
    return v_t;
}

fn v_editDistance(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_b[ix as usize] = v_val(ix, (v_s + 1));
    }
    let mut v_d: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for v_j in 0..(v_n + 1) {
        v_d[(v_j) as usize] = v_j;
    }
    for v_i in 1..(v_n + 1) {
        let mut v_diag: i64 = v_d[(0) as usize];
        v_d[(0) as usize] = v_i;
        for v_k in 1..(v_n + 1) {
            let mut v_old: i64 = v_d[(v_k) as usize];
            let mut v_cost: i64 = 0;
            if ((v_a[((v_i - 1)) as usize] % 7) != (v_b[((v_k - 1)) as usize] % 7)) {
                v_cost = 1;
            }
            v_d[(v_k) as usize] = v_low((v_low(v_d[((v_k - 1)) as usize], v_old) + 1), (v_diag + v_cost));
            v_diag = v_old;
        }
    }
    return v_d[(v_n) as usize];
}

fn v_commonSubsequence(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_b: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_b[ix as usize] = v_val(ix, (v_s + 2));
    }
    let mut v_d: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for v_i in 0..v_n {
        let mut v_diag: i64 = 0;
        for v_j in 1..(v_n + 1) {
            let mut v_old: i64 = v_d[(v_j) as usize];
            if ((v_a[(v_i) as usize] % 11) == (v_b[((v_j - 1)) as usize] % 11)) {
                v_d[(v_j) as usize] = (v_diag + 1);
            } else {
                v_d[(v_j) as usize] = v_high(v_d[(v_j) as usize], v_d[((v_j - 1)) as usize]);
            }
            v_diag = v_old;
        }
    }
    return v_d[(v_n) as usize];
}

fn v_knapsack(v_n: i64, v_s: i64) -> i64 {
    let mut v_d: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for v_i in 0..48 {
        let mut v_w: i64 = ((v_val(v_i, v_s) % 37) + 1);
        let mut v_price: i64 = (v_val((v_i + 1), v_s) % 89);
        let mut v_j: i64 = v_n;
        while (v_j >= v_w) {
            v_d[(v_j) as usize] = v_high(v_d[(v_j) as usize], (v_d[((v_j - v_w)) as usize] + v_price));
            v_j = v_j - 1;
        }
    }
    return v_d[(v_n) as usize];
}

fn v_coinMinimum(v_n: i64, v_s: i64) -> i64 {
    let mut v_d: Vec<i64> = vec![(v_n + 1); ((v_n + 1)) as usize];
    v_d[(0) as usize] = 0;
    for v_i in 1..(v_n + 1) {
        v_d[(v_i) as usize] = (v_d[((v_i - 1)) as usize] + 1);
        for v_j in 0..5 {
            let mut v_c: i64 = ((v_val(v_j, v_s) % 33) + 1);
            if (v_i >= v_c) {
                v_d[(v_i) as usize] = v_low(v_d[(v_i) as usize], (v_d[((v_i - v_c)) as usize] + 1));
            }
        }
    }
    return v_d[(v_n) as usize];
}

fn v_increasingSubseq(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_d: Vec<i64> = vec![1; (v_n) as usize];
    let mut v_best: i64 = 0;
    for v_i in 0..v_n {
        for v_j in 0..v_i {
            if (v_a[(v_j) as usize] < v_a[(v_i) as usize]) {
                v_d[(v_i) as usize] = v_high(v_d[(v_i) as usize], (v_d[(v_j) as usize] + 1));
            }
        }
        v_best = v_high(v_best, v_d[(v_i) as usize]);
    }
    return v_best;
}

fn v_gridMinPath(v_n: i64, v_s: i64) -> i64 {
    let mut v_d: Vec<i64> = vec![0; (v_n) as usize];
    for v_i in 0..v_n {
        for v_j in 0..v_n {
            let mut v_v: i64 = v_val(((v_i * v_n) + v_j), v_s);
            if (v_j == 0) {
                v_d[(v_j) as usize] = v_d[(v_j) as usize] + v_v;
            } else {
                if (v_i == 0) {
                    v_d[(v_j) as usize] = (v_d[((v_j - 1)) as usize] + v_v);
                } else {
                    v_d[(v_j) as usize] = (v_low(v_d[(v_j) as usize], v_d[((v_j - 1)) as usize]) + v_v);
                }
            }
        }
    }
    return v_d[((v_n - 1)) as usize];
}

fn v_maxNonAdjacent(v_n: i64, v_s: i64) -> i64 {
    let mut v_prev: i64 = 0;
    let mut v_best: i64 = 0;
    for v_i in 0..v_n {
        let mut v_take: i64 = (v_prev + v_val(v_i, v_s));
        v_prev = v_best;
        v_best = v_high(v_best, v_take);
    }
    return v_best;
}

fn v_rodCut(v_n: i64, v_s: i64) -> i64 {
    let mut v_d: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    let mut v_price: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for ix in 0..(v_n + 1) {
        v_price[ix as usize] = v_val(ix, v_s);
    }
    for v_i in 1..(v_n + 1) {
        for v_j in 1..(v_i + 1) {
            v_d[(v_i) as usize] = v_high(v_d[(v_i) as usize], (v_price[(v_j) as usize] + v_d[((v_i - v_j)) as usize]));
        }
    }
    return v_d[(v_n) as usize];
}

fn v_segmentGain(v_n: i64, v_s: i64) -> i64 {
    let mut v_best: i64 = 0;
    let mut v_current: i64 = 0;
    for v_i in 0..v_n {
        v_current = v_high(0, ((v_current + v_val(v_i, v_s)) - 503));
        v_best = v_high(v_best, v_current);
    }
    return v_best;
}

fn v_subsetReach(v_n: i64, v_s: i64) -> i64 {
    let mut v_d: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    v_d[(0) as usize] = 1;
    for v_i in 0..30 {
        let mut v_w: i64 = ((v_val(v_i, v_s) % 70) + 1);
        let mut v_j: i64 = v_n;
        while (v_j >= v_w) {
            if (v_d[((v_j - v_w)) as usize] == 1) {
                v_d[(v_j) as usize] = 1;
            }
            v_j = v_j - 1;
        }
    }
    let mut v_total: i64 = 0;
    for v_k in 0..(v_n + 1) {
        v_total = v_total + v_d[(v_k) as usize];
    }
    return v_total;
}

fn v_unionFind(v_n: i64, v_s: i64) -> i64 {
    let mut v_p: Vec<i64> = vec![0; (v_n) as usize];
    for v_i in 0..v_n {
        v_p[(v_i) as usize] = v_i;
    }
    let mut v_joined: i64 = 0;
    for v_j in 0..v_n {
        let mut v_a: i64 = (((v_j * 37) + v_s) % v_n);
        let mut v_b: i64 = (((v_j * 19) + v_val(v_j, v_s)) % v_n);
        while (v_p[(v_a) as usize] != v_a) {
            v_p[(v_a) as usize] = v_p[(v_p[(v_a) as usize]) as usize];
            v_a = v_p[(v_a) as usize];
        }
        while (v_p[(v_b) as usize] != v_b) {
            v_b = v_p[(v_b) as usize];
        }
        if (v_a != v_b) {
            v_p[(v_a) as usize] = v_b;
            v_joined = v_joined + 1;
        }
    }
    return v_joined;
}

fn v_fenwickUpdateQuery(v_n: i64, v_s: i64) -> i64 {
    let mut v_tree: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_k: i64 = (v_i + 1);
        let mut v_bit: i64 = 1;
        while ((v_k % (v_bit * 2)) == 0) {
            v_bit = v_bit * 2;
        }
        v_tree[(v_k) as usize] = v_tree[(v_k) as usize] + v_val(v_i, v_s);
        let mut v_parent: i64 = (v_k + v_bit);
        if (v_parent <= v_n) {
            v_tree[(v_parent) as usize] = v_tree[(v_parent) as usize] + v_tree[(v_k) as usize];
        }
        if ((v_k % 17) == 0) {
            v_t = v_t + v_tree[(v_k) as usize];
        }
    }
    return (v_t + v_tree[(v_n) as usize]);
}

fn v_ringQueue(v_n: i64, v_s: i64) -> i64 {
    let mut v_q: Vec<i64> = vec![0; (127) as usize];
    let mut v_head: i64 = 0;
    let mut v_tail: i64 = 0;
    let mut v_count: i64 = 0;
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = v_val(v_i, v_s);
        if ((v_count == 0) || ((v_count < 127) && ((v_x % 3) != 0))) {
            v_q[(v_tail) as usize] = v_x;
            v_tail = ((v_tail + 1) % 127);
            v_count = v_count + 1;
        } else {
            v_t = v_t + v_q[(v_head) as usize];
            v_head = ((v_head + 1) % 127);
            v_count = v_count - 1;
        }
    }
    return (v_t + v_count);
}

fn v_monotoneStack(v_n: i64, v_s: i64) -> i64 {
    let mut v_st: Vec<i64> = vec![0; (v_n) as usize];
    let mut v_size: i64 = 0;
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = v_val(v_i, v_s);
        while ((v_size > 0) && (v_st[((v_size - 1)) as usize] <= v_x)) {
            v_size = v_size - 1;
        }
        if (v_size > 0) {
            v_t = v_t + v_st[((v_size - 1)) as usize];
        }
        v_st[(v_size) as usize] = v_x;
        v_size = v_size + 1;
    }
    return v_t;
}

fn v_openAddress(v_n: i64, v_s: i64) -> i64 {
    let mut v_cap: i64 = ((2 * v_n) + 1);
    let mut v_slots: Vec<i64> = vec![0; (v_cap) as usize];
    let mut v_probes: i64 = 0;
    for v_i in 0..v_n {
        let mut v_key: i64 = (((v_i * 231) + v_val(v_i, v_s)) + 1);
        let mut v_p: i64 = (v_key % v_cap);
        while (v_slots[(v_p) as usize] != 0) {
            v_probes = v_probes + 1;
            v_p = ((v_p + 1) % v_cap);
        }
        v_slots[(v_p) as usize] = v_key;
    }
    return (v_probes + v_slots[((v_s % v_cap)) as usize]);
}

fn v_floydDistances(v_n: i64, v_s: i64) -> i64 {
    let mut v_d: Vec<i64> = vec![0; ((v_n * v_n)) as usize];
    for ix in 0..(v_n * v_n) {
        v_d[ix as usize] = v_val(ix, v_s);
    }
    for v_k in 0..v_n {
        for v_i in 0..v_n {
            for v_j in 0..v_n {
                let mut v_p: i64 = ((v_i * v_n) + v_j);
                v_d[(v_p) as usize] = v_low(v_d[(v_p) as usize], (v_d[(((v_i * v_n) + v_k)) as usize] + v_d[(((v_k * v_n) + v_j)) as usize]));
            }
        }
    }
    return (v_d[((v_s % v_n)) as usize] + v_d[(((v_n * v_n) - 1)) as usize]);
}

fn v_breadthFirst(v_n: i64, v_s: i64) -> i64 {
    let mut v_seen: Vec<i64> = vec![0; (v_n) as usize];
    let mut v_q: Vec<i64> = vec![0; (v_n) as usize];
    v_q[(0) as usize] = (v_s % v_n);
    v_seen[(v_q[(0) as usize]) as usize] = 1;
    let mut v_head: i64 = 0;
    let mut v_tail: i64 = 1;
    let mut v_t: i64 = 0;
    while (v_head < v_tail) {
        let mut v_v: i64 = v_q[(v_head) as usize];
        v_head = v_head + 1;
        for v_j in 0..2 {
            let mut v_w: i64 = ((((v_v * (v_j + 2)) + v_j) + 1) % v_n);
            if (v_seen[(v_w) as usize] == 0) {
                v_seen[(v_w) as usize] = (v_seen[(v_v) as usize] + 1);
                v_q[(v_tail) as usize] = v_w;
                v_tail = v_tail + 1;
                v_t = v_t + v_seen[(v_w) as usize];
            }
        }
    }
    return v_t;
}

fn v_treeFold(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_i: i64 = (v_n - 1);
    while (v_i > 0) {
        v_a[(((v_i - 1) / 2)) as usize] = v_a[(((v_i - 1) / 2)) as usize] + v_a[(v_i) as usize];
        v_i = v_i - 1;
    }
    return (v_a[(0) as usize] + v_a[((v_n / 7)) as usize]);
}

fn v_sparseEdges(v_n: i64, v_s: i64) -> i64 {
    let mut v_target: Vec<i64> = vec![0; (v_n) as usize];
    for v_i in 0..v_n {
        for v_j in 0..3 {
            let mut v_dst: i64 = ((((v_i * 17) + (v_j * 29)) + v_s) % v_n);
            v_target[(v_dst) as usize] = v_target[(v_dst) as usize] + (v_val((v_i + v_j), v_s) % 19);
        }
    }
    let mut v_t: i64 = 0;
    for v_k in 0..v_n {
        v_t = v_t + (v_target[(v_k) as usize] * (v_k % 11));
    }
    return v_t;
}

fn v_intervalSweep(v_n: i64, v_s: i64) -> i64 {
    let mut v_hits: Vec<i64> = vec![0; ((v_n + 1)) as usize];
    for v_i in 0..v_n {
        let mut v_start: i64 = ((v_val(v_i, v_s) + v_i) % v_n);
        let mut v_end: i64 = v_low(v_n, ((v_start + (v_val((v_i + 1), v_s) % 41)) + 1));
        v_hits[(v_start) as usize] = v_hits[(v_start) as usize] + 1;
        v_hits[(v_end) as usize] = v_hits[(v_end) as usize] - 1;
    }
    let mut v_active: i64 = 0;
    let mut v_best: i64 = 0;
    for v_k in 0..v_n {
        v_active = v_active + v_hits[(v_k) as usize];
        v_best = v_high(v_active, v_best);
    }
    return v_best;
}

fn v_luhnDigits(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_d: i64 = (v_val(v_i, v_s) % 10);
        if ((v_i % 2) == 1) {
            v_d = v_d * 2;
            if (v_d > 9) {
                v_d = v_d - 9;
            }
        }
        v_total = v_total + v_d;
    }
    return (v_total % 10);
}

fn v_runLengths(v_n: i64, v_s: i64) -> i64 {
    let mut v_prev: i64 = (-1);
    let mut v_size: i64 = 0;
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_v: i64 = (v_val(v_i, v_s) % 3);
        if (v_v == v_prev) {
            v_size = v_size + 1;
        } else {
            v_t = v_t + (v_size * v_size);
            v_size = 1;
            v_prev = v_v;
        }
    }
    return (v_t + (v_size * v_size));
}

fn v_varintLength(v_n: i64, v_s: i64) -> i64 {
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = ((v_i + v_val(v_i, v_s)) * (v_s + 1));
        v_t = v_t + 1;
        while (v_x >= 128) {
            v_t = v_t + 1;
            v_x = (v_x / 128);
        }
    }
    return v_t;
}

fn v_decimalFields(v_n: i64, v_s: i64) -> i64 {
    let mut v_value: i64 = 0;
    let mut v_total: i64 = 0;
    let mut v_digits: i64 = 0;
    for v_i in 0..v_n {
        let mut v_token: i64 = (v_val(v_i, v_s) % 13);
        if ((v_token < 10) && (v_digits < 8)) {
            v_value = ((v_value * 10) + v_token);
            v_digits = v_digits + 1;
        } else {
            v_total = v_total + v_value;
            v_value = 0;
            v_digits = 0;
        }
    }
    return (v_total + v_value);
}

fn v_csvQuoted(v_n: i64, v_s: i64) -> i64 {
    let mut v_quoted: i64 = 0;
    let mut v_fields: i64 = 1;
    for v_i in 0..v_n {
        let mut v_c: i64 = (v_val(v_i, v_s) % 17);
        if (v_c == 0) {
            v_quoted = (1 - v_quoted);
        }
        if ((v_c == 1) && (v_quoted == 0)) {
            v_fields = v_fields + 1;
        }
    }
    return v_fields;
}

fn v_bracketDepth(v_n: i64, v_s: i64) -> i64 {
    let mut v_depth: i64 = 0;
    let mut v_errors: i64 = 0;
    for v_i in 0..v_n {
        let mut v_k: i64 = (v_val(v_i, v_s) % 5);
        if (v_k == 0) {
            v_depth = v_depth + 1;
        }
        if (v_k == 1) {
            if (v_depth == 0) {
                v_errors = v_errors + 1;
            } else {
                v_depth = v_depth - 1;
            }
        }
    }
    return (v_errors + v_depth);
}

fn v_utf8Widths(v_n: i64, v_s: i64) -> i64 {
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_cp: i64 = (((v_val(v_i, v_s) * 1237) + v_i) % 1114112);
        let mut v_width: i64 = 1;
        if (v_cp >= 128) {
            v_width = v_width + 1;
        }
        if (v_cp >= 2048) {
            v_width = v_width + 1;
        }
        if (v_cp >= 65536) {
            v_width = v_width + 1;
        }
        v_total = v_total + v_width;
    }
    return v_total;
}

fn v_patternAutomaton(v_n: i64, v_s: i64) -> i64 {
    let mut v_state: i64 = 0;
    let mut v_hits: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = (v_val(v_i, v_s) % 3);
        if (v_x == 0) {
            if (v_state == 2) {
                v_hits = v_hits + 1;
            }
            v_state = 1;
        } else {
            if ((v_x == 1) && (v_state == 1)) {
                v_state = 2;
            } else {
                v_state = 0;
            }
        }
    }
    return v_hits;
}

fn v_zigzagDelta(v_n: i64, v_s: i64) -> i64 {
    let mut v_last: i64 = 0;
    let mut v_total: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = v_val(v_i, v_s);
        let mut v_d: i64 = (v_x - v_last);
        if (v_d < 0) {
            v_total = v_total + (((0 - v_d) * 2) - 1);
        } else {
            v_total = v_total + (v_d * 2);
        }
        v_last = v_x;
    }
    return v_total;
}

fn v_packedNibbles(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_i in 0..(v_n / 2) {
        let mut v_byte: i64 = (((v_a[((2 * v_i)) as usize] % 16) * 16) + (v_a[(((2 * v_i) + 1)) as usize] % 16));
        v_t = v_t + (v_byte * ((v_i % 7) + 1));
    }
    return v_t;
}

fn v_tokenBucket(v_n: i64, v_s: i64) -> i64 {
    let mut v_credit: i64 = 65;
    let mut v_ok: i64 = 0;
    for v_i in 0..v_n {
        v_credit = v_low(100, (v_credit + 5));
        let mut v_request: i64 = (v_val(v_i, v_s) % 16);
        if (v_credit >= v_request) {
            v_credit = v_credit - v_request;
            v_ok = v_ok + 1;
        }
    }
    return v_ok;
}

fn v_orderBookLevel(v_n: i64, v_s: i64) -> i64 {
    let mut v_bids: Vec<i64> = vec![0; (128) as usize];
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = v_val(v_i, v_s);
        let mut v_index: i64 = (v_x % 128);
        if ((v_x % 3) == 0) {
            let mut v_used: i64 = v_low(v_bids[(v_index) as usize], (v_x % 19));
            v_bids[(v_index) as usize] = v_bids[(v_index) as usize] - v_used;
            v_t = v_t + v_used;
        } else {
            v_bids[(v_index) as usize] = v_bids[(v_index) as usize] + (v_x % 23);
        }
    }
    return v_t;
}

fn v_roundRobin(v_n: i64, v_s: i64) -> i64 {
    let mut v_budget: Vec<i64> = vec![0; (17) as usize];
    for v_i in 0..17 {
        v_budget[(v_i) as usize] = (v_val(v_i, v_s) + 1);
    }
    let mut v_served: i64 = 0;
    let mut v_p: i64 = 0;
    for v_j in 0..v_n {
        let mut v_take: i64 = v_low(13, v_budget[(v_p) as usize]);
        v_served = v_served + v_take;
        v_budget[(v_p) as usize] = v_budget[(v_p) as usize] - v_take;
        if (v_budget[(v_p) as usize] == 0) {
            v_budget[(v_p) as usize] = (v_val(v_j, v_s) + 1);
        }
        v_p = ((v_p + 1) % 17);
    }
    return v_served;
}

fn v_inventoryReorder(v_n: i64, v_s: i64) -> i64 {
    let mut v_stock: Vec<i64> = vec![20; (61) as usize];
    let mut v_orders: i64 = 0;
    for v_i in 0..v_n {
        let mut v_k: i64 = (v_val(v_i, v_s) % 61);
        v_stock[(v_k) as usize] = v_stock[(v_k) as usize] - (v_i % 5);
        if (v_stock[(v_k) as usize] < 5) {
            v_stock[(v_k) as usize] = v_stock[(v_k) as usize] + 24;
            v_orders = v_orders + 1;
        }
    }
    return v_orders;
}

fn v_thermostat(v_n: i64, v_s: i64) -> i64 {
    let mut v_temp: i64 = 190;
    let mut v_power: i64 = 0;
    let mut v_consumed: i64 = 0;
    for v_i in 0..v_n {
        if (v_temp < 184) {
            v_power = 1;
        }
        if (v_temp > 211) {
            v_power = 0;
        }
        v_temp = v_temp + ((v_power * 5) - (v_val(v_i, v_s) % 6));
        v_consumed = v_consumed + v_power;
    }
    return v_consumed;
}

fn v_resampleLinear(v_n: i64, v_s: i64) -> i64 {
    let mut v_a: Vec<i64> = vec![0; (v_n) as usize];
    for ix in 0..v_n {
        v_a[ix as usize] = v_val(ix, v_s);
    }
    let mut v_t: i64 = 0;
    for v_j in 0..((v_n * 3) - 3) {
        let mut v_p: i64 = (v_j / 3);
        let mut v_fraction: i64 = (v_j % 3);
        v_t = v_t + (((v_a[(v_p) as usize] * (3 - v_fraction)) + (v_a[((v_p + 1)) as usize] * v_fraction)) / 3);
    }
    return v_t;
}

fn v_envelopeFollower(v_n: i64, v_s: i64) -> i64 {
    let mut v_env: i64 = 0;
    let mut v_t: i64 = 0;
    for v_i in 0..v_n {
        let mut v_x: i64 = v_val(v_i, v_s);
        if (v_x > v_env) {
            v_env = v_env + (((v_x - v_env) + 1) / 2);
        } else {
            v_env = v_env - ((v_env - v_x) / 8);
        }
        v_t = v_t + v_env;
    }
    return v_t;
}

fn v_telemetryBuckets(v_n: i64, v_s: i64) -> i64 {
    let mut v_b: Vec<i64> = vec![0; (11) as usize];
    for v_i in 0..v_n {
        let mut v_v: i64 = (v_val(v_i, v_s) + 1);
        let mut v_level: i64 = 0;
        while (v_v > 1) {
            v_v = (v_v / 2);
            v_level = v_level + 1;
        }
        v_b[(v_level) as usize] = v_b[(v_level) as usize] + 1;
    }
    let mut v_target: i64 = ((v_n * 9) / 10);
    let mut v_k: i64 = 0;
    while (v_target > v_b[(v_k) as usize]) {
        v_target = v_target - v_b[(v_k) as usize];
        v_k = v_k + 1;
    }
    return v_k;
}

fn v_backoffSimulation(v_n: i64, v_s: i64) -> i64 {
    let mut v_delay: i64 = 1;
    let mut v_elapsed: i64 = 0;
    for v_i in 0..v_n {
        if ((v_val(v_i, v_s) % 4) != 0) {
            v_delay = 1;
        } else {
            v_delay = v_low(128, (v_delay * 2));
        }
        v_elapsed = v_elapsed + v_delay;
    }
    return v_elapsed;
}

fn v_packetJitter(v_n: i64, v_s: i64) -> i64 {
    let mut v_previous: i64 = 0;
    let mut v_jitter: i64 = 0;
    for v_i in 0..v_n {
        let mut v_transit: i64 = (v_val(v_i, v_s) % 127);
        let mut v_delta: i64 = v_dist(v_transit, v_previous);
        v_jitter = (((15 * v_jitter) + (16 * v_delta)) / 16);
        v_previous = v_transit;
    }
    return v_jitter;
}

fn v_group0(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 0) {
        return v_euclidBatch(v_n, v_s);
    }
    if (v_id == 1) {
        return v_primeTrial(v_n, v_s);
    }
    if (v_id == 2) {
        return v_modularPower(v_n, v_s);
    }
    if (v_id == 3) {
        return v_newtonRoot(v_n, v_s);
    }
    if (v_id == 4) {
        return v_digitSum(v_n, v_s);
    }
    if (v_id == 5) {
        return v_binomialRows(v_n, v_s);
    }
    if (v_id == 6) {
        return v_factorMultiplicity(v_n, v_s);
    }
    if (v_id == 7) {
        return v_binaryOnes(v_n, v_s);
    }
    if (v_id == 8) {
        return v_totientBatch(v_n, v_s);
    }
    if (v_id == 9) {
        return v_divisorsPaired(v_n, v_s);
    }
    return 0;
}

fn v_group1(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 10) {
        return v_affineStream(v_n, v_s);
    }
    if (v_id == 11) {
        return v_fibonacciMod(v_n, v_s);
    }
    if (v_id == 12) {
        return v_adlerStream(v_n, v_s);
    }
    if (v_id == 13) {
        return v_polynomialHash(v_n, v_s);
    }
    if (v_id == 14) {
        return v_exponentialFilter(v_n, v_s);
    }
    if (v_id == 15) {
        return v_hysteresis(v_n, v_s);
    }
    if (v_id == 16) {
        return v_longestStreak(v_n, v_s);
    }
    if (v_id == 17) {
        return v_majorityVote(v_n, v_s);
    }
    if (v_id == 18) {
        return v_crossingCount(v_n, v_s);
    }
    if (v_id == 19) {
        return v_cumulativeDrawdown(v_n, v_s);
    }
    return 0;
}

fn v_group2(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 20) {
        return v_insertionSort(v_n, v_s);
    }
    if (v_id == 21) {
        return v_selectionSort(v_n, v_s);
    }
    if (v_id == 22) {
        return v_bubbleEarly(v_n, v_s);
    }
    if (v_id == 23) {
        return v_shellSort(v_n, v_s);
    }
    if (v_id == 24) {
        return v_countingRank(v_n, v_s);
    }
    if (v_id == 25) {
        return v_lowerBound(v_n, v_s);
    }
    if (v_id == 26) {
        return v_sentinelFind(v_n, v_s);
    }
    if (v_id == 27) {
        return v_partitionPivot(v_n, v_s);
    }
    if (v_id == 28) {
        return v_mergeRuns(v_n, v_s);
    }
    if (v_id == 29) {
        return v_heapBuild(v_n, v_s);
    }
    return 0;
}

fn v_group3(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 30) {
        return v_reverseBuffer(v_n, v_s);
    }
    if (v_id == 31) {
        return v_rotateCycles(v_n, v_s);
    }
    if (v_id == 32) {
        return v_strideGather(v_n, v_s);
    }
    if (v_id == 33) {
        return v_permutedScatter(v_n, v_s);
    }
    if (v_id == 34) {
        return v_chainedLoads(v_n, v_s);
    }
    if (v_id == 35) {
        return v_copyIsolation(v_n, v_s);
    }
    if (v_id == 36) {
        return v_scopeChurn(v_n, v_s);
    }
    if (v_id == 37) {
        return v_compactStable(v_n, v_s);
    }
    if (v_id == 38) {
        return v_interleaveBuffers(v_n, v_s);
    }
    if (v_id == 39) {
        return v_sparsePages(v_n, v_s);
    }
    return 0;
}

fn v_group4(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 40) {
        return v_dotProduct(v_n, v_s);
    }
    if (v_id == 41) {
        return v_integerVariance(v_n, v_s);
    }
    if (v_id == 42) {
        return v_frequencyMode(v_n, v_s);
    }
    if (v_id == 43) {
        return v_slidingWindow(v_n, v_s);
    }
    if (v_id == 44) {
        return v_prefixQueries(v_n, v_s);
    }
    if (v_id == 45) {
        return v_minmaxSpan(v_n, v_s);
    }
    if (v_id == 46) {
        return v_normalizedCov(v_n, v_s);
    }
    if (v_id == 47) {
        return v_lowpassMedian(v_n, v_s);
    }
    if (v_id == 48) {
        return v_lagCorrelation(v_n, v_s);
    }
    if (v_id == 49) {
        return v_trimmedThreshold(v_n, v_s);
    }
    return 0;
}

fn v_group5(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 50) {
        return v_matrixMultiply(v_n, v_s);
    }
    if (v_id == 51) {
        return v_matrixTranspose(v_n, v_s);
    }
    if (v_id == 52) {
        return v_fivePoint(v_n, v_s);
    }
    if (v_id == 53) {
        return v_sobelHorizontal(v_n, v_s);
    }
    if (v_id == 54) {
        return v_summedArea(v_n, v_s);
    }
    if (v_id == 55) {
        return v_lifeOneStep(v_n, v_s);
    }
    if (v_id == 56) {
        return v_diagonalEnergy(v_n, v_s);
    }
    if (v_id == 57) {
        return v_triangularSolve(v_n, v_s);
    }
    if (v_id == 58) {
        return v_rowNormalize(v_n, v_s);
    }
    if (v_id == 59) {
        return v_maxPool(v_n, v_s);
    }
    return 0;
}

fn v_group6(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 60) {
        return v_editDistance(v_n, v_s);
    }
    if (v_id == 61) {
        return v_commonSubsequence(v_n, v_s);
    }
    if (v_id == 62) {
        return v_knapsack(v_n, v_s);
    }
    if (v_id == 63) {
        return v_coinMinimum(v_n, v_s);
    }
    if (v_id == 64) {
        return v_increasingSubseq(v_n, v_s);
    }
    if (v_id == 65) {
        return v_gridMinPath(v_n, v_s);
    }
    if (v_id == 66) {
        return v_maxNonAdjacent(v_n, v_s);
    }
    if (v_id == 67) {
        return v_rodCut(v_n, v_s);
    }
    if (v_id == 68) {
        return v_segmentGain(v_n, v_s);
    }
    if (v_id == 69) {
        return v_subsetReach(v_n, v_s);
    }
    return 0;
}

fn v_group7(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 70) {
        return v_unionFind(v_n, v_s);
    }
    if (v_id == 71) {
        return v_fenwickUpdateQuery(v_n, v_s);
    }
    if (v_id == 72) {
        return v_ringQueue(v_n, v_s);
    }
    if (v_id == 73) {
        return v_monotoneStack(v_n, v_s);
    }
    if (v_id == 74) {
        return v_openAddress(v_n, v_s);
    }
    if (v_id == 75) {
        return v_floydDistances(v_n, v_s);
    }
    if (v_id == 76) {
        return v_breadthFirst(v_n, v_s);
    }
    if (v_id == 77) {
        return v_treeFold(v_n, v_s);
    }
    if (v_id == 78) {
        return v_sparseEdges(v_n, v_s);
    }
    if (v_id == 79) {
        return v_intervalSweep(v_n, v_s);
    }
    return 0;
}

fn v_group8(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 80) {
        return v_luhnDigits(v_n, v_s);
    }
    if (v_id == 81) {
        return v_runLengths(v_n, v_s);
    }
    if (v_id == 82) {
        return v_varintLength(v_n, v_s);
    }
    if (v_id == 83) {
        return v_decimalFields(v_n, v_s);
    }
    if (v_id == 84) {
        return v_csvQuoted(v_n, v_s);
    }
    if (v_id == 85) {
        return v_bracketDepth(v_n, v_s);
    }
    if (v_id == 86) {
        return v_utf8Widths(v_n, v_s);
    }
    if (v_id == 87) {
        return v_patternAutomaton(v_n, v_s);
    }
    if (v_id == 88) {
        return v_zigzagDelta(v_n, v_s);
    }
    if (v_id == 89) {
        return v_packedNibbles(v_n, v_s);
    }
    return 0;
}

fn v_group9(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 90) {
        return v_tokenBucket(v_n, v_s);
    }
    if (v_id == 91) {
        return v_orderBookLevel(v_n, v_s);
    }
    if (v_id == 92) {
        return v_roundRobin(v_n, v_s);
    }
    if (v_id == 93) {
        return v_inventoryReorder(v_n, v_s);
    }
    if (v_id == 94) {
        return v_thermostat(v_n, v_s);
    }
    if (v_id == 95) {
        return v_resampleLinear(v_n, v_s);
    }
    if (v_id == 96) {
        return v_envelopeFollower(v_n, v_s);
    }
    if (v_id == 97) {
        return v_telemetryBuckets(v_n, v_s);
    }
    if (v_id == 98) {
        return v_backoffSimulation(v_n, v_s);
    }
    if (v_id == 99) {
        return v_packetJitter(v_n, v_s);
    }
    return 0;
}

fn v_dispatch(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id < 10) {
        return v_group0(v_id, v_n, v_s);
    }
    if (v_id < 20) {
        return v_group1(v_id, v_n, v_s);
    }
    if (v_id < 30) {
        return v_group2(v_id, v_n, v_s);
    }
    if (v_id < 40) {
        return v_group3(v_id, v_n, v_s);
    }
    if (v_id < 50) {
        return v_group4(v_id, v_n, v_s);
    }
    if (v_id < 60) {
        return v_group5(v_id, v_n, v_s);
    }
    if (v_id < 70) {
        return v_group6(v_id, v_n, v_s);
    }
    if (v_id < 80) {
        return v_group7(v_id, v_n, v_s);
    }
    if (v_id < 90) {
        return v_group8(v_id, v_n, v_s);
    }
    if (v_id < 100) {
        return v_group9(v_id, v_n, v_s);
    }
    return 0;
}

#[cfg(windows)]
fn rss() -> u64 {
    #[link(name = "kernel32")]
    extern "system" { fn GetCurrentProcess() -> isize; }
    #[link(name = "psapi")]
    extern "system" { fn GetProcessMemoryInfo(h: isize, m: *mut u8, cb: u32) -> i32; }
    #[repr(C)] struct Mem { cb: u32, faults: u32, peak: usize, other: [usize;7] }
    let mut m = Mem { cb: std::mem::size_of::<Mem>() as u32, faults: 0, peak: 0, other: [0;7] };
    unsafe { assert_ne!(GetProcessMemoryInfo(GetCurrentProcess(), &mut m as *mut _ as *mut u8, m.cb), 0); }
    m.peak as u64
}
#[cfg(target_os = "linux")]
fn rss() -> u64 {
    let status = std::fs::read_to_string("/proc/self/status").unwrap();
    status.lines().find(|l| l.starts_with("VmHWM:")).unwrap().split_whitespace().nth(1).unwrap().parse::<u64>().unwrap()*1024
}
fn main() {
    let args: Vec<i64> = std::env::args().skip(1).map(|x| x.parse().unwrap()).collect();
    let start = std::time::Instant::now();
    let mut sum = 0i64;
    for i in 0..args[3] { sum += std::hint::black_box(v_dispatch(args[0],args[1],args[2]+(i%4)*7)); }
    let ns = start.elapsed().as_nanos();
    println!("{} {} {} 0 0 0 0", sum, ns, rss());
}

