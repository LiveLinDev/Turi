
fn v_val(v_i: i64, v_s: i64) -> i64 {
    var v_x: i64 = (((v_i * 73) + (v_s * 101)) % 1009);
    return ((((v_x * v_x) + (17 * v_x)) + 19) % 1009);
}

fn v_low(v_x: i64, v_y: i64) -> i64 {
    if (v_x < v_y) {
        return v_x;
    }
    return v_y;
}

fn v_high(v_x: i64, v_y: i64) -> i64 {
    if (v_x > v_y) {
        return v_x;
    }
    return v_y;
}

fn v_dist(v_x: i64, v_y: i64) -> i64 {
    if (v_x >= v_y) {
        return (v_x - v_y);
    }
    return (v_y - v_x);
}

fn v_euclidBatch(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_a: i64 = (v_val(v_i, v_s) + 1);
        var v_b: i64 = (v_i + 19);
        while (v_b > 0) {
            var v_r: i64 = (v_a % v_b);
            v_a = v_b;
            v_b = v_r;
        }
        v_total = v_total + v_a;
    }
    return v_total;
}

fn v_primeTrial(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_a: i64 = ((v_i + v_s) + 2);
        var v_d: i64 = 2;
        while (((v_d * v_d) <= v_a) && ((v_a % v_d) != 0)) {
            v_d = v_d + 1;
        }
        if ((v_d * v_d) > v_a) {
            v_total = v_total + 1;
        }
    }
    return v_total;
}

fn v_modularPower(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_e: i64 = v_val(v_i, v_s);
        var v_b: i64 = (v_i + 3);
        var v_v: i64 = 1;
        while (v_e > 0) {
            if ((v_e % 2) == 1) {
                v_v = ((v_v * v_b) % 65521);
            }
            v_b = ((v_b * v_b) % 65521);
            v_e = (v_e / 2);
        }
        v_total = v_total + v_v;
    }
    return v_total;
}

fn v_newtonRoot(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_a: i64 = (((v_i + v_s) * 97) + 1);
        var v_x: i64 = v_a;
        var v_y: i64 = ((v_x + 1) / 2);
        while (v_y < v_x) {
            v_x = v_y;
            v_y = ((v_x + (v_a / v_x)) / 2);
        }
        v_total = v_total + v_x;
    }
    return v_total;
}

fn v_digitSum(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_a: i64 = ((v_i + 1) * (v_s + 1));
        while (v_a > 0) {
            v_total = v_total + (v_a % 10);
            v_a = (v_a / 10);
        }
    }
    return v_total;
}

fn v_binomialRows(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_a: i64 = (((v_i + v_s) % 27) + 1);
        var v_v: i64 = 1;
        for v_j in 1..(v_a + 1) {
            v_v = ((v_v * ((v_a + 1) - v_j)) / v_j);
            v_total = v_total + v_v;
        }
    }
    return v_total;
}

fn v_factorMultiplicity(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = (v_val(v_i, v_s) + 1);
        var v_d: i64 = 2;
        while ((v_d * v_d) <= v_x) {
            while ((v_x % v_d) == 0) {
                v_total = v_total + 1;
                v_x = (v_x / v_d);
            }
            v_d = v_d + 1;
        }
        if (v_x > 1) {
            v_total = v_total + 1;
        }
    }
    return v_total;
}

fn v_binaryOnes(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = ((v_val(v_i, v_s) * 177) + v_i);
        while (v_x > 0) {
            v_total = v_total + (v_x % 2);
            v_x = (v_x / 2);
        }
    }
    return v_total;
}

fn v_totientBatch(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = (v_val(v_i, v_s) + 1);
        var v_phi: i64 = v_x;
        var v_d: i64 = 2;
        while ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_phi = v_phi - (v_phi / v_d);
                while ((v_x % v_d) == 0) {
                    v_x = (v_x / v_d);
                }
            }
            v_d = v_d + 1;
        }
        if (v_x > 1) {
            v_phi = v_phi - (v_phi / v_x);
        }
        v_total = v_total + v_phi;
    }
    return v_total;
}

fn v_divisorsPaired(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = (v_val(v_i, v_s) + 1);
        var v_d: i64 = 1;
        while ((v_d * v_d) <= v_x) {
            if ((v_x % v_d) == 0) {
                v_total = v_total + v_d;
                if ((v_d * v_d) != v_x) {
                    v_total = v_total + (v_x / v_d);
                }
            }
            v_d = v_d + 1;
        }
    }
    return v_total;
}

fn v_affineStream(v_n: i64, v_s: i64) -> i64 {
    var v_x: i64 = v_s;
    for v_i in 0..v_n {
        v_x = (((v_x * 48271) + 1) % 2147483647);
    }
    return v_x;
}

fn v_fibonacciMod(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64 = 0;
    var v_b: i64 = v_s;
    for v_i in 0..v_n {
        var v_c: i64 = ((v_a + v_b) % 65521);
        v_a = v_b;
        v_b = v_c;
    }
    return v_b;
}

fn v_adlerStream(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64 = 1;
    var v_b: i64 = 0;
    for v_i in 0..v_n {
        v_a = ((v_a + (v_val(v_i, v_s) % 256)) % 65521);
        v_b = ((v_b + v_a) % 65521);
    }
    return ((v_b * 65536) + v_a);
}

fn v_polynomialHash(v_n: i64, v_s: i64) -> i64 {
    var v_h: i64 = 0;
    for v_i in 0..v_n {
        v_h = (((v_h * 257) + v_val(v_i, v_s)) % 1000003);
    }
    return v_h;
}

fn v_exponentialFilter(v_n: i64, v_s: i64) -> i64 {
    var v_state: i64 = 0;
    for v_i in 0..v_n {
        v_state = (((v_state * 7) + (v_val(v_i, v_s) * 8)) / 8);
    }
    return v_state;
}

fn v_hysteresis(v_n: i64, v_s: i64) -> i64 {
    var v_state: i64 = 0;
    var v_transitions: i64 = 0;
    for v_i in 0..v_n {
        var v_v: i64 = v_val(v_i, v_s);
        if ((v_state == 0) && (v_v > 765)) {
            v_state = 1;
            v_transitions = v_transitions + 1;
        }
        if ((v_state == 1) && (v_v < 201)) {
            v_state = 0;
        }
    }
    return v_transitions;
}

fn v_longestStreak(v_n: i64, v_s: i64) -> i64 {
    var v_streak: i64 = 0;
    var v_best: i64 = 0;
    for v_i in 0..v_n {
        if ((v_val(v_i, v_s) % 3) != 0) {
            v_streak = v_streak + 1;
            v_best = v_high(v_best, v_streak);
        } else {
            v_streak = 0;
        }
    }
    return v_best;
}

fn v_majorityVote(v_n: i64, v_s: i64) -> i64 {
    var v_balance: i64 = 0;
    var v_candidate: i64 = 0;
    for v_i in 0..v_n {
        var v_v: i64 = (v_val(v_i, v_s) % 7);
        if (v_balance == 0) {
            v_candidate = v_v;
        }
        if (v_candidate == v_v) {
            v_balance = v_balance + 1;
        } else {
            v_balance = v_balance - 1;
        }
    }
    return ((v_candidate * 100) + v_balance);
}

fn v_crossingCount(v_n: i64, v_s: i64) -> i64 {
    var v_prev: i64 = (v_s % 1009);
    var v_count: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = v_val(v_i, v_s);
        if ((v_prev <= 500) && (v_x > 500)) {
            v_count = v_count + 1;
        }
        v_prev = v_x;
    }
    return v_count;
}

fn v_cumulativeDrawdown(v_n: i64, v_s: i64) -> i64 {
    var v_price: i64 = 1000;
    var v_peak: i64 = v_price;
    var v_draw: i64 = 0;
    for v_i in 0..v_n {
        v_price = v_price + ((v_val(v_i, v_s) % 31) - 15);
        v_peak = v_high(v_peak, v_price);
        v_draw = v_high(v_draw, (v_peak - v_price));
    }
    return v_draw;
}

fn v_insertionSort(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    for v_i in 1..v_n {
        var v_v: i64 = v_a[v_i];
        var v_j: i64 = v_i;
        while ((v_j > 0) && (v_a[(v_j - 1)] > v_v)) {
            v_a[v_j] = v_a[(v_j - 1)];
            v_j = v_j - 1;
        }
        v_a[v_j] = v_v;
    }
    return (v_a[(v_n / 3)] + v_a[(v_n - 1)]);
}

fn v_selectionSort(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    for v_i in 0..v_n {
        var v_k: i64 = v_i;
        for v_j in (v_i + 1)..v_n {
            if (v_a[v_j] < v_a[v_k]) {
                v_k = v_j;
            }
        }
        var v_v: i64 = v_a[v_k];
        v_a[v_k] = v_a[v_i];
        v_a[v_i] = v_v;
    }
    return (v_a[(v_n / 2)] + v_a[0]);
}

fn v_bubbleEarly(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_edge: i64 = v_n;
    while (v_edge > 1) {
        var v_last: i64 = 0;
        for v_j in 1..v_edge {
            if (v_a[(v_j - 1)] > v_a[v_j]) {
                var v_v: i64 = v_a[v_j];
                v_a[v_j] = v_a[(v_j - 1)];
                v_a[(v_j - 1)] = v_v;
                v_last = v_j;
            }
        }
        v_edge = v_last;
    }
    return (v_a[(v_n / 4)] + v_a[(v_n - 1)]);
}

fn v_shellSort(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_gap: i64 = (v_n / 2);
    while (v_gap > 0) {
        for v_i in v_gap..v_n {
            var v_v: i64 = v_a[v_i];
            var v_j: i64 = v_i;
            while ((v_j >= v_gap) && (v_a[(v_j - v_gap)] > v_v)) {
                v_a[v_j] = v_a[(v_j - v_gap)];
                v_j = v_j - v_gap;
            }
            v_a[v_j] = v_v;
        }
        v_gap = (v_gap / 2);
    }
    return v_a[(v_n / 2)];
}

fn v_countingRank(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_h: i64[>..] = [];
    v_h.resize(1009, 0);
    for v_i in 0..v_n {
        v_h[v_a[v_i]] = v_h[v_a[v_i]] + 1;
    }
    var v_rank: i64 = (v_n / 2);
    var v_v: i64 = 0;
    while (v_rank >= v_h[v_v]) {
        v_rank = v_rank - v_h[v_v];
        v_v = v_v + 1;
    }
    return v_v;
}

fn v_lowerBound(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for v_i in 0..v_n {
        v_a[v_i] = ((v_i * 3) + (v_i / 5));
    }
    var v_t: i64 = 0;
    for v_j in 0..(v_n / 4) {
        var v_x: i64 = ((v_val(v_j, v_s) * 31) % (v_n * 4));
        var v_lo: i64 = 0;
        var v_hi: i64 = v_n;
        while (v_lo < v_hi) {
            var v_mid: i64 = ((v_lo + v_hi) / 2);
            if (v_a[v_mid] < v_x) {
                v_lo = (v_mid + 1);
            } else {
                v_hi = v_mid;
            }
        }
        v_t = v_t + v_lo;
    }
    return v_t;
}

fn v_sentinelFind(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n + 1), 0);
    for ix in 0..(v_n + 1) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_q in 0..40 {
        var v_x: i64 = v_val((v_q + v_n), v_s);
        v_a[v_n] = v_x;
        var v_j: i64 = 0;
        while (v_a[v_j] != v_x) {
            v_j = v_j + 1;
        }
        v_t = v_t + v_j;
    }
    return v_t;
}

fn v_partitionPivot(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_pivot: i64 = v_a[(v_n / 2)];
    var v_left: i64 = 0;
    for v_i in 0..v_n {
        if (v_a[v_i] < v_pivot) {
            var v_v: i64 = v_a[v_left];
            v_a[v_left] = v_a[v_i];
            v_a[v_i] = v_v;
            v_left = v_left + 1;
        }
    }
    return (v_left + v_a[(v_n / 2)]);
}

fn v_mergeRuns(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    var v_x: i64 = 0;
    var v_y: i64 = 0;
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        v_x = v_x + (v_val(v_i, v_s) % 7);
        v_y = v_y + (v_val((v_i + 3), v_s) % 11);
        v_a[v_i] = v_x;
        v_b[v_i] = v_y;
    }
    var v_l: i64 = 0;
    var v_r: i64 = 0;
    for v_k in 0..(v_n * 2) {
        if ((v_r == v_n) || ((v_l < v_n) && (v_a[v_l] <= v_b[v_r]))) {
            v_t = v_t + (v_a[v_l] * (v_k % 7));
            v_l = v_l + 1;
        } else {
            v_t = v_t + (v_b[v_r] * (v_k % 7));
            v_r = v_r + 1;
        }
    }
    return v_t;
}

fn v_heapBuild(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_i: i64 = (v_n / 2);
    while (v_i > 0) {
        v_i = v_i - 1;
        var v_root: i64 = v_i;
        var v_child: i64 = ((2 * v_root) + 1);
        while (v_child < v_n) {
            if (((v_child + 1) < v_n) && (v_a[(v_child + 1)] > v_a[v_child])) {
                v_child = v_child + 1;
            }
            if (v_a[v_root] >= v_a[v_child]) {
                v_child = v_n;
            } else {
                var v_v: i64 = v_a[v_root];
                v_a[v_root] = v_a[v_child];
                v_a[v_child] = v_v;
                v_root = v_child;
                v_child = ((2 * v_root) + 1);
            }
        }
    }
    return (v_a[0] + v_a[(v_n / 3)]);
}

fn v_reverseBuffer(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    for v_i in 0..(v_n / 2) {
        var v_j: i64 = ((v_n - 1) - v_i);
        var v_t: i64 = v_a[v_i];
        v_a[v_i] = v_a[v_j];
        v_a[v_j] = v_t;
    }
    var v_total: i64 = 0;
    for v_k in 0..v_n {
        v_total = v_total + (v_a[v_k] * (v_k % 11));
    }
    return v_total;
}

fn v_rotateCycles(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = v_a[(v_n - 1)];
    for v_i in 1..v_n {
        v_a[(v_n - v_i)] = v_a[((v_n - v_i) - 1)];
    }
    v_a[0] = v_t;
    var v_total: i64 = 0;
    for v_j in 0..v_n {
        v_total = v_total + (v_a[v_j] * (v_j % 17));
    }
    return v_total;
}

fn v_strideGather(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    var v_pos: i64 = 0;
    for v_i in 0..v_n {
        v_t = v_t + v_a[v_pos];
        v_pos = ((v_pos + 61) % v_n);
    }
    return v_t;
}

fn v_permutedScatter(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    var v_j: i64 = (v_s % v_n);
    for v_i in 0..v_n {
        v_a[v_j] = (v_i + 1);
        v_j = ((v_j + 31) % v_n);
    }
    var v_t: i64 = 0;
    for v_k in 0..v_n {
        v_t = v_t + (v_a[v_k] * (v_k % 5));
    }
    return v_t;
}

fn v_chainedLoads(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    for v_i in 0..v_n {
        v_a[v_i] = ((v_a[v_i] + (v_i * 59)) % v_n);
    }
    var v_p: i64 = (v_s % v_n);
    var v_t: i64 = 0;
    for v_j in 0..v_n {
        v_p = v_a[v_p];
        v_t = v_t + v_p;
    }
    return v_t;
}

fn v_copyIsolation(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    for ix in 0..v_n {
        v_b[ix] = v_a[ix];
    }
    for v_i in 0..v_n {
        if ((v_i % 3) == 0) {
            v_b[v_i] = (v_a[v_i] + v_i);
        }
    }
    var v_t: i64 = 0;
    for v_j in 0..v_n {
        v_t = v_t + ((v_b[v_j] * 3) - v_a[v_j]);
    }
    return v_t;
}

fn v_scopeChurn(v_n: i64, v_s: i64) -> i64 {
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_width: i64 = ((v_val(v_i, v_s) % 377) + 4);
        var v_a: i64[>..] = [];
        v_a.resize(v_width, v_i);
        for v_j in 0..v_width {
            v_a[v_j] = ((v_a[v_j] + (v_j * 17)) % 173);
        }
        v_t = v_t + v_a[((v_i + v_s) % v_width)];
    }
    return v_t;
}

fn v_compactStable(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_write: i64 = 0;
    for v_i in 0..v_n {
        if ((v_a[v_i] % 3) == 0) {
            v_a[v_write] = v_a[v_i];
            v_write = v_write + 1;
        }
    }
    var v_t: i64 = 0;
    for v_j in 0..v_write {
        v_t = v_t + (v_a[v_j] * (v_j % 5));
    }
    return v_t;
}

fn v_interleaveBuffers(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    for ix in 0..v_n {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    var v_c: i64[>..] = [];
    v_c.resize((v_n * 2), 0);
    for v_i in 0..v_n {
        v_c[(2 * v_i)] = v_a[v_i];
        v_c[((2 * v_i) + 1)] = v_b[v_i];
    }
    var v_t: i64 = 0;
    for v_j in 1..(v_n * 2) {
        v_t = v_t + v_dist(v_c[v_j], v_c[(v_j - 1)]);
    }
    return v_t;
}

fn v_sparsePages(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, v_s);
    for v_i in 0..((v_n + 511) / 512) {
        v_a[(v_i * 512)] = v_val(v_i, v_s);
    }
    var v_t: i64 = 0;
    for v_k in 0..v_n {
        v_t = v_t + v_a[v_k];
    }
    return v_t;
}

fn v_dotProduct(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    for ix in 0..v_n {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        v_t = v_t + (v_a[v_i] * v_b[v_i]);
    }
    return v_t;
}

fn v_integerVariance(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        v_t = v_t + v_a[v_i];
    }
    var v_mean: i64 = (v_t / v_n);
    var v_v: i64 = 0;
    for v_j in 0..v_n {
        var v_d: i64 = (v_a[v_j] - v_mean);
        v_v = v_v + (v_d * v_d);
    }
    return v_v;
}

fn v_frequencyMode(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(257, 0);
    for v_i in 0..v_n {
        v_a[(v_val(v_i, v_s) % 257)] = v_a[(v_val(v_i, v_s) % 257)] + 1;
    }
    var v_best: i64 = 0;
    for v_k in 1..257 {
        if (v_a[v_k] > v_a[v_best]) {
            v_best = v_k;
        }
    }
    return v_best;
}

fn v_slidingWindow(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_window: i64 = 0;
    var v_best: i64 = 0;
    for v_i in 0..v_n {
        v_window = v_window + v_a[v_i];
        if (v_i >= 23) {
            v_window = v_window - v_a[(v_i - 23)];
        }
        v_best = v_high(v_best, v_window);
    }
    return v_best;
}

fn v_prefixQueries(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n + 1), 0);
    for v_i in 0..v_n {
        v_a[(v_i + 1)] = (v_a[v_i] + v_val(v_i, v_s));
    }
    var v_t: i64 = 0;
    for v_j in 0..(v_n / 4) {
        var v_lo: i64 = (v_val(v_j, v_s) % v_n);
        var v_hi: i64 = (v_lo + (v_val((v_j + 1), v_s) % (v_n - v_lo)));
        v_t = v_t + (v_a[(v_hi + 1)] - v_a[v_lo]);
    }
    return v_t;
}

fn v_minmaxSpan(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_mn: i64 = v_a[0];
    var v_mx: i64 = v_a[0];
    for v_i in 1..v_n {
        v_mn = v_low(v_mn, v_a[v_i]);
        v_mx = v_high(v_mx, v_a[v_i]);
    }
    return (v_mx - v_mn);
}

fn v_normalizedCov(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    for ix in 0..v_n {
        v_b[ix] = v_val(ix, (v_s + 2));
    }
    var v_x: i64 = 0;
    var v_y: i64 = 0;
    var v_xy: i64 = 0;
    for v_i in 0..v_n {
        v_x = v_x + v_a[v_i];
        v_y = v_y + v_b[v_i];
        v_xy = v_xy + (v_a[v_i] * v_b[v_i]);
    }
    return ((v_n * v_xy) - (v_x * v_y));
}

fn v_lowpassMedian(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_total: i64 = 0;
    for v_i in 2..v_n {
        var v_x: i64 = v_low(v_a[v_i], v_a[(v_i - 1)]);
        var v_y: i64 = v_high(v_a[v_i], v_a[(v_i - 1)]);
        v_total = v_total + v_high(v_x, v_low(v_a[(v_i - 2)], v_y));
    }
    return v_total;
}

fn v_lagCorrelation(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    var v_lag: i64 = ((v_s % 23) + 1);
    for v_i in v_lag..v_n {
        v_t = v_t + ((v_a[v_i] - 500) * (v_a[(v_i - v_lag)] - 500));
    }
    return v_t;
}

fn v_trimmedThreshold(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    var v_count: i64 = 0;
    for v_i in 0..v_n {
        if ((v_a[v_i] >= 100) && (v_a[v_i] < 900)) {
            v_t = v_t + v_a[v_i];
            v_count = v_count + 1;
        }
    }
    return (v_t / (v_count + 1));
}

fn v_matrixMultiply(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        for v_j in 0..v_n {
            var v_v: i64 = 0;
            for v_k in 0..v_n {
                v_v = v_v + (v_a[((v_i * v_n) + v_k)] * v_b[((v_k * v_n) + v_j)]);
            }
            v_t = v_t + (v_v % 101);
        }
    }
    return v_t;
}

fn v_matrixTranspose(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize((v_n * v_n), 0);
    for v_i in 0..v_n {
        for v_j in 0..v_n {
            v_b[((v_j * v_n) + v_i)] = v_a[((v_i * v_n) + v_j)];
        }
    }
    var v_t: i64 = 0;
    for v_k in 0..(v_n * v_n) {
        v_t = v_t + (v_b[v_k] * (v_k % 13));
    }
    return v_t;
}

fn v_fivePoint(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_i in 1..(v_n - 1) {
        for v_j in 1..(v_n - 1) {
            var v_p: i64 = ((v_i * v_n) + v_j);
            v_t = v_t + (((((v_a[v_p] + v_a[(v_p - 1)]) + v_a[(v_p + 1)]) + v_a[(v_p - v_n)]) + v_a[(v_p + v_n)]) / 5);
        }
    }
    return v_t;
}

fn v_sobelHorizontal(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_i in 1..(v_n - 1) {
        for v_j in 1..(v_n - 1) {
            var v_p: i64 = ((v_i * v_n) + v_j);
            var v_l: i64 = ((v_a[((v_p - v_n) - 1)] + (v_a[(v_p - 1)] * 2)) + v_a[((v_p + v_n) - 1)]);
            var v_r: i64 = ((v_a[((v_p - v_n) + 1)] + (v_a[(v_p + 1)] * 2)) + v_a[((v_p + v_n) + 1)]);
            v_t = v_t + v_dist(v_l, v_r);
        }
    }
    return v_t;
}

fn v_summedArea(v_n: i64, v_s: i64) -> i64 {
    var v_p: i64[>..] = [];
    v_p.resize(((v_n + 1) * (v_n + 1)), 0);
    var v_w: i64 = (v_n + 1);
    for v_i in 1..v_w {
        var v_row: i64 = 0;
        for v_j in 1..v_w {
            v_row = v_row + v_val(((v_i * v_w) + v_j), v_s);
            v_p[((v_i * v_w) + v_j)] = (v_row + v_p[(((v_i - 1) * v_w) + v_j)]);
        }
    }
    return (v_p[((v_n * v_w) + v_n)] + v_p[(((v_n / 2) * v_w) + (v_n / 3))]);
}

fn v_lifeOneStep(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_alive: i64 = 0;
    for v_i in 1..(v_n - 1) {
        for v_j in 1..(v_n - 1) {
            var v_p: i64 = ((v_i * v_n) + v_j);
            var v_count: i64 = 0;
            for v_y in 0..3 {
                for v_x in 0..3 {
                    if ((v_y != 1) || (v_x != 1)) {
                        v_count = v_count + (v_a[(((v_p + ((v_y - 1) * v_n)) + v_x) - 1)] % 2);
                    }
                }
            }
            if ((v_count == 3) || ((v_count == 2) && ((v_a[v_p] % 2) == 1))) {
                v_alive = v_alive + 1;
            }
        }
    }
    return v_alive;
}

fn v_diagonalEnergy(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_d in 0..v_n {
        var v_v: i64 = 0;
        for v_i in 0..(v_n - v_d) {
            v_v = v_v + v_a[(((v_i * v_n) + v_i) + v_d)];
        }
        v_t = v_t + (v_v * v_v);
    }
    return v_t;
}

fn v_triangularSolve(v_n: i64, v_s: i64) -> i64 {
    var v_x: i64[>..] = [];
    v_x.resize(v_n, 0);
    for v_i in 0..v_n {
        var v_v: i64 = v_val(v_i, v_s);
        for v_j in 0..v_i {
            v_v = v_v + ((v_val((v_i + v_j), v_s) % 5) * v_x[v_j]);
        }
        v_x[v_i] = (v_v % 997);
    }
    return v_x[(v_n - 1)];
}

fn v_rowNormalize(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_mx: i64 = 1;
        for v_j in 0..v_n {
            v_mx = v_high(v_mx, v_a[((v_i * v_n) + v_j)]);
        }
        for v_k in 0..v_n {
            v_t = v_t + ((v_a[((v_i * v_n) + v_k)] * 255) / v_mx);
        }
    }
    return v_t;
}

fn v_maxPool(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_i in 0..(v_n / 2) {
        for v_j in 0..(v_n / 2) {
            var v_p: i64 = (((2 * v_i) * v_n) + (2 * v_j));
            v_t = v_t + v_high(v_high(v_a[v_p], v_a[(v_p + 1)]), v_high(v_a[(v_p + v_n)], v_a[((v_p + v_n) + 1)]));
        }
    }
    return v_t;
}

fn v_editDistance(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    for ix in 0..v_n {
        v_b[ix] = v_val(ix, (v_s + 1));
    }
    var v_d: i64[>..] = [];
    v_d.resize((v_n + 1), 0);
    for v_j in 0..(v_n + 1) {
        v_d[v_j] = v_j;
    }
    for v_i in 1..(v_n + 1) {
        var v_diag: i64 = v_d[0];
        v_d[0] = v_i;
        for v_k in 1..(v_n + 1) {
            var v_old: i64 = v_d[v_k];
            var v_cost: i64 = 0;
            if ((v_a[(v_i - 1)] % 7) != (v_b[(v_k - 1)] % 7)) {
                v_cost = 1;
            }
            v_d[v_k] = v_low((v_low(v_d[(v_k - 1)], v_old) + 1), (v_diag + v_cost));
            v_diag = v_old;
        }
    }
    return v_d[v_n];
}

fn v_commonSubsequence(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_b: i64[>..] = [];
    v_b.resize(v_n, 0);
    for ix in 0..v_n {
        v_b[ix] = v_val(ix, (v_s + 2));
    }
    var v_d: i64[>..] = [];
    v_d.resize((v_n + 1), 0);
    for v_i in 0..v_n {
        var v_diag: i64 = 0;
        for v_j in 1..(v_n + 1) {
            var v_old: i64 = v_d[v_j];
            if ((v_a[v_i] % 11) == (v_b[(v_j - 1)] % 11)) {
                v_d[v_j] = (v_diag + 1);
            } else {
                v_d[v_j] = v_high(v_d[v_j], v_d[(v_j - 1)]);
            }
            v_diag = v_old;
        }
    }
    return v_d[v_n];
}

fn v_knapsack(v_n: i64, v_s: i64) -> i64 {
    var v_d: i64[>..] = [];
    v_d.resize((v_n + 1), 0);
    for v_i in 0..48 {
        var v_w: i64 = ((v_val(v_i, v_s) % 37) + 1);
        var v_price: i64 = (v_val((v_i + 1), v_s) % 89);
        var v_j: i64 = v_n;
        while (v_j >= v_w) {
            v_d[v_j] = v_high(v_d[v_j], (v_d[(v_j - v_w)] + v_price));
            v_j = v_j - 1;
        }
    }
    return v_d[v_n];
}

fn v_coinMinimum(v_n: i64, v_s: i64) -> i64 {
    var v_d: i64[>..] = [];
    v_d.resize((v_n + 1), (v_n + 1));
    v_d[0] = 0;
    for v_i in 1..(v_n + 1) {
        v_d[v_i] = (v_d[(v_i - 1)] + 1);
        for v_j in 0..5 {
            var v_c: i64 = ((v_val(v_j, v_s) % 33) + 1);
            if (v_i >= v_c) {
                v_d[v_i] = v_low(v_d[v_i], (v_d[(v_i - v_c)] + 1));
            }
        }
    }
    return v_d[v_n];
}

fn v_increasingSubseq(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_d: i64[>..] = [];
    v_d.resize(v_n, 1);
    var v_best: i64 = 0;
    for v_i in 0..v_n {
        for v_j in 0..v_i {
            if (v_a[v_j] < v_a[v_i]) {
                v_d[v_i] = v_high(v_d[v_i], (v_d[v_j] + 1));
            }
        }
        v_best = v_high(v_best, v_d[v_i]);
    }
    return v_best;
}

fn v_gridMinPath(v_n: i64, v_s: i64) -> i64 {
    var v_d: i64[>..] = [];
    v_d.resize(v_n, 0);
    for v_i in 0..v_n {
        for v_j in 0..v_n {
            var v_v: i64 = v_val(((v_i * v_n) + v_j), v_s);
            if (v_j == 0) {
                v_d[v_j] = v_d[v_j] + v_v;
            } else {
                if (v_i == 0) {
                    v_d[v_j] = (v_d[(v_j - 1)] + v_v);
                } else {
                    v_d[v_j] = (v_low(v_d[v_j], v_d[(v_j - 1)]) + v_v);
                }
            }
        }
    }
    return v_d[(v_n - 1)];
}

fn v_maxNonAdjacent(v_n: i64, v_s: i64) -> i64 {
    var v_prev: i64 = 0;
    var v_best: i64 = 0;
    for v_i in 0..v_n {
        var v_take: i64 = (v_prev + v_val(v_i, v_s));
        v_prev = v_best;
        v_best = v_high(v_best, v_take);
    }
    return v_best;
}

fn v_rodCut(v_n: i64, v_s: i64) -> i64 {
    var v_d: i64[>..] = [];
    v_d.resize((v_n + 1), 0);
    var v_price: i64[>..] = [];
    v_price.resize((v_n + 1), 0);
    for ix in 0..(v_n + 1) {
        v_price[ix] = v_val(ix, v_s);
    }
    for v_i in 1..(v_n + 1) {
        for v_j in 1..(v_i + 1) {
            v_d[v_i] = v_high(v_d[v_i], (v_price[v_j] + v_d[(v_i - v_j)]));
        }
    }
    return v_d[v_n];
}

fn v_segmentGain(v_n: i64, v_s: i64) -> i64 {
    var v_best: i64 = 0;
    var v_current: i64 = 0;
    for v_i in 0..v_n {
        v_current = v_high(0, ((v_current + v_val(v_i, v_s)) - 503));
        v_best = v_high(v_best, v_current);
    }
    return v_best;
}

fn v_subsetReach(v_n: i64, v_s: i64) -> i64 {
    var v_d: i64[>..] = [];
    v_d.resize((v_n + 1), 0);
    v_d[0] = 1;
    for v_i in 0..30 {
        var v_w: i64 = ((v_val(v_i, v_s) % 70) + 1);
        var v_j: i64 = v_n;
        while (v_j >= v_w) {
            if (v_d[(v_j - v_w)] == 1) {
                v_d[v_j] = 1;
            }
            v_j = v_j - 1;
        }
    }
    var v_total: i64 = 0;
    for v_k in 0..(v_n + 1) {
        v_total = v_total + v_d[v_k];
    }
    return v_total;
}

fn v_unionFind(v_n: i64, v_s: i64) -> i64 {
    var v_p: i64[>..] = [];
    v_p.resize(v_n, 0);
    for v_i in 0..v_n {
        v_p[v_i] = v_i;
    }
    var v_joined: i64 = 0;
    for v_j in 0..v_n {
        var v_a: i64 = (((v_j * 37) + v_s) % v_n);
        var v_b: i64 = (((v_j * 19) + v_val(v_j, v_s)) % v_n);
        while (v_p[v_a] != v_a) {
            v_p[v_a] = v_p[v_p[v_a]];
            v_a = v_p[v_a];
        }
        while (v_p[v_b] != v_b) {
            v_b = v_p[v_b];
        }
        if (v_a != v_b) {
            v_p[v_a] = v_b;
            v_joined = v_joined + 1;
        }
    }
    return v_joined;
}

fn v_fenwickUpdateQuery(v_n: i64, v_s: i64) -> i64 {
    var v_tree: i64[>..] = [];
    v_tree.resize((v_n + 1), 0);
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_k: i64 = (v_i + 1);
        var v_bit: i64 = 1;
        while ((v_k % (v_bit * 2)) == 0) {
            v_bit = v_bit * 2;
        }
        v_tree[v_k] = v_tree[v_k] + v_val(v_i, v_s);
        var v_parent: i64 = (v_k + v_bit);
        if (v_parent <= v_n) {
            v_tree[v_parent] = v_tree[v_parent] + v_tree[v_k];
        }
        if ((v_k % 17) == 0) {
            v_t = v_t + v_tree[v_k];
        }
    }
    return (v_t + v_tree[v_n]);
}

fn v_ringQueue(v_n: i64, v_s: i64) -> i64 {
    var v_q: i64[>..] = [];
    v_q.resize(127, 0);
    var v_head: i64 = 0;
    var v_tail: i64 = 0;
    var v_count: i64 = 0;
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = v_val(v_i, v_s);
        if ((v_count == 0) || ((v_count < 127) && ((v_x % 3) != 0))) {
            v_q[v_tail] = v_x;
            v_tail = ((v_tail + 1) % 127);
            v_count = v_count + 1;
        } else {
            v_t = v_t + v_q[v_head];
            v_head = ((v_head + 1) % 127);
            v_count = v_count - 1;
        }
    }
    return (v_t + v_count);
}

fn v_monotoneStack(v_n: i64, v_s: i64) -> i64 {
    var v_st: i64[>..] = [];
    v_st.resize(v_n, 0);
    var v_size: i64 = 0;
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = v_val(v_i, v_s);
        while ((v_size > 0) && (v_st[(v_size - 1)] <= v_x)) {
            v_size = v_size - 1;
        }
        if (v_size > 0) {
            v_t = v_t + v_st[(v_size - 1)];
        }
        v_st[v_size] = v_x;
        v_size = v_size + 1;
    }
    return v_t;
}

fn v_openAddress(v_n: i64, v_s: i64) -> i64 {
    var v_cap: i64 = ((2 * v_n) + 1);
    var v_slots: i64[>..] = [];
    v_slots.resize(v_cap, 0);
    var v_probes: i64 = 0;
    for v_i in 0..v_n {
        var v_key: i64 = (((v_i * 231) + v_val(v_i, v_s)) + 1);
        var v_p: i64 = (v_key % v_cap);
        while (v_slots[v_p] != 0) {
            v_probes = v_probes + 1;
            v_p = ((v_p + 1) % v_cap);
        }
        v_slots[v_p] = v_key;
    }
    return (v_probes + v_slots[(v_s % v_cap)]);
}

fn v_floydDistances(v_n: i64, v_s: i64) -> i64 {
    var v_d: i64[>..] = [];
    v_d.resize((v_n * v_n), 0);
    for ix in 0..(v_n * v_n) {
        v_d[ix] = v_val(ix, v_s);
    }
    for v_k in 0..v_n {
        for v_i in 0..v_n {
            for v_j in 0..v_n {
                var v_p: i64 = ((v_i * v_n) + v_j);
                v_d[v_p] = v_low(v_d[v_p], (v_d[((v_i * v_n) + v_k)] + v_d[((v_k * v_n) + v_j)]));
            }
        }
    }
    return (v_d[(v_s % v_n)] + v_d[((v_n * v_n) - 1)]);
}

fn v_breadthFirst(v_n: i64, v_s: i64) -> i64 {
    var v_seen: i64[>..] = [];
    v_seen.resize(v_n, 0);
    var v_q: i64[>..] = [];
    v_q.resize(v_n, 0);
    v_q[0] = (v_s % v_n);
    v_seen[v_q[0]] = 1;
    var v_head: i64 = 0;
    var v_tail: i64 = 1;
    var v_t: i64 = 0;
    while (v_head < v_tail) {
        var v_v: i64 = v_q[v_head];
        v_head = v_head + 1;
        for v_j in 0..2 {
            var v_w: i64 = ((((v_v * (v_j + 2)) + v_j) + 1) % v_n);
            if (v_seen[v_w] == 0) {
                v_seen[v_w] = (v_seen[v_v] + 1);
                v_q[v_tail] = v_w;
                v_tail = v_tail + 1;
                v_t = v_t + v_seen[v_w];
            }
        }
    }
    return v_t;
}

fn v_treeFold(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_i: i64 = (v_n - 1);
    while (v_i > 0) {
        v_a[((v_i - 1) / 2)] = v_a[((v_i - 1) / 2)] + v_a[v_i];
        v_i = v_i - 1;
    }
    return (v_a[0] + v_a[(v_n / 7)]);
}

fn v_sparseEdges(v_n: i64, v_s: i64) -> i64 {
    var v_target: i64[>..] = [];
    v_target.resize(v_n, 0);
    for v_i in 0..v_n {
        for v_j in 0..3 {
            var v_dst: i64 = ((((v_i * 17) + (v_j * 29)) + v_s) % v_n);
            v_target[v_dst] = v_target[v_dst] + (v_val((v_i + v_j), v_s) % 19);
        }
    }
    var v_t: i64 = 0;
    for v_k in 0..v_n {
        v_t = v_t + (v_target[v_k] * (v_k % 11));
    }
    return v_t;
}

fn v_intervalSweep(v_n: i64, v_s: i64) -> i64 {
    var v_hits: i64[>..] = [];
    v_hits.resize((v_n + 1), 0);
    for v_i in 0..v_n {
        var v_start: i64 = ((v_val(v_i, v_s) + v_i) % v_n);
        var v_end: i64 = v_low(v_n, ((v_start + (v_val((v_i + 1), v_s) % 41)) + 1));
        v_hits[v_start] = v_hits[v_start] + 1;
        v_hits[v_end] = v_hits[v_end] - 1;
    }
    var v_active: i64 = 0;
    var v_best: i64 = 0;
    for v_k in 0..v_n {
        v_active = v_active + v_hits[v_k];
        v_best = v_high(v_active, v_best);
    }
    return v_best;
}

fn v_luhnDigits(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_d: i64 = (v_val(v_i, v_s) % 10);
        if ((v_i % 2) == 1) {
            v_d = v_d * 2;
            if (v_d > 9) {
                v_d = v_d - 9;
            }
        }
        v_total = v_total + v_d;
    }
    return (v_total % 10);
}

fn v_runLengths(v_n: i64, v_s: i64) -> i64 {
    var v_prev: i64 = (-1);
    var v_size: i64 = 0;
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_v: i64 = (v_val(v_i, v_s) % 3);
        if (v_v == v_prev) {
            v_size = v_size + 1;
        } else {
            v_t = v_t + (v_size * v_size);
            v_size = 1;
            v_prev = v_v;
        }
    }
    return (v_t + (v_size * v_size));
}

fn v_varintLength(v_n: i64, v_s: i64) -> i64 {
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = ((v_i + v_val(v_i, v_s)) * (v_s + 1));
        v_t = v_t + 1;
        while (v_x >= 128) {
            v_t = v_t + 1;
            v_x = (v_x / 128);
        }
    }
    return v_t;
}

fn v_decimalFields(v_n: i64, v_s: i64) -> i64 {
    var v_value: i64 = 0;
    var v_total: i64 = 0;
    var v_digits: i64 = 0;
    for v_i in 0..v_n {
        var v_token: i64 = (v_val(v_i, v_s) % 13);
        if ((v_token < 10) && (v_digits < 8)) {
            v_value = ((v_value * 10) + v_token);
            v_digits = v_digits + 1;
        } else {
            v_total = v_total + v_value;
            v_value = 0;
            v_digits = 0;
        }
    }
    return (v_total + v_value);
}

fn v_csvQuoted(v_n: i64, v_s: i64) -> i64 {
    var v_quoted: i64 = 0;
    var v_fields: i64 = 1;
    for v_i in 0..v_n {
        var v_c: i64 = (v_val(v_i, v_s) % 17);
        if (v_c == 0) {
            v_quoted = (1 - v_quoted);
        }
        if ((v_c == 1) && (v_quoted == 0)) {
            v_fields = v_fields + 1;
        }
    }
    return v_fields;
}

fn v_bracketDepth(v_n: i64, v_s: i64) -> i64 {
    var v_depth: i64 = 0;
    var v_errors: i64 = 0;
    for v_i in 0..v_n {
        var v_k: i64 = (v_val(v_i, v_s) % 5);
        if (v_k == 0) {
            v_depth = v_depth + 1;
        }
        if (v_k == 1) {
            if (v_depth == 0) {
                v_errors = v_errors + 1;
            } else {
                v_depth = v_depth - 1;
            }
        }
    }
    return (v_errors + v_depth);
}

fn v_utf8Widths(v_n: i64, v_s: i64) -> i64 {
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_cp: i64 = (((v_val(v_i, v_s) * 1237) + v_i) % 1114112);
        var v_width: i64 = 1;
        if (v_cp >= 128) {
            v_width = v_width + 1;
        }
        if (v_cp >= 2048) {
            v_width = v_width + 1;
        }
        if (v_cp >= 65536) {
            v_width = v_width + 1;
        }
        v_total = v_total + v_width;
    }
    return v_total;
}

fn v_patternAutomaton(v_n: i64, v_s: i64) -> i64 {
    var v_state: i64 = 0;
    var v_hits: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = (v_val(v_i, v_s) % 3);
        if (v_x == 0) {
            if (v_state == 2) {
                v_hits = v_hits + 1;
            }
            v_state = 1;
        } else {
            if ((v_x == 1) && (v_state == 1)) {
                v_state = 2;
            } else {
                v_state = 0;
            }
        }
    }
    return v_hits;
}

fn v_zigzagDelta(v_n: i64, v_s: i64) -> i64 {
    var v_last: i64 = 0;
    var v_total: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = v_val(v_i, v_s);
        var v_d: i64 = (v_x - v_last);
        if (v_d < 0) {
            v_total = v_total + (((0 - v_d) * 2) - 1);
        } else {
            v_total = v_total + (v_d * 2);
        }
        v_last = v_x;
    }
    return v_total;
}

fn v_packedNibbles(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_i in 0..(v_n / 2) {
        var v_byte: i64 = (((v_a[(2 * v_i)] % 16) * 16) + (v_a[((2 * v_i) + 1)] % 16));
        v_t = v_t + (v_byte * ((v_i % 7) + 1));
    }
    return v_t;
}

fn v_tokenBucket(v_n: i64, v_s: i64) -> i64 {
    var v_credit: i64 = 65;
    var v_ok: i64 = 0;
    for v_i in 0..v_n {
        v_credit = v_low(100, (v_credit + 5));
        var v_request: i64 = (v_val(v_i, v_s) % 16);
        if (v_credit >= v_request) {
            v_credit = v_credit - v_request;
            v_ok = v_ok + 1;
        }
    }
    return v_ok;
}

fn v_orderBookLevel(v_n: i64, v_s: i64) -> i64 {
    var v_bids: i64[>..] = [];
    v_bids.resize(128, 0);
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = v_val(v_i, v_s);
        var v_index: i64 = (v_x % 128);
        if ((v_x % 3) == 0) {
            var v_used: i64 = v_low(v_bids[v_index], (v_x % 19));
            v_bids[v_index] = v_bids[v_index] - v_used;
            v_t = v_t + v_used;
        } else {
            v_bids[v_index] = v_bids[v_index] + (v_x % 23);
        }
    }
    return v_t;
}

fn v_roundRobin(v_n: i64, v_s: i64) -> i64 {
    var v_budget: i64[>..] = [];
    v_budget.resize(17, 0);
    for v_i in 0..17 {
        v_budget[v_i] = (v_val(v_i, v_s) + 1);
    }
    var v_served: i64 = 0;
    var v_p: i64 = 0;
    for v_j in 0..v_n {
        var v_take: i64 = v_low(13, v_budget[v_p]);
        v_served = v_served + v_take;
        v_budget[v_p] = v_budget[v_p] - v_take;
        if (v_budget[v_p] == 0) {
            v_budget[v_p] = (v_val(v_j, v_s) + 1);
        }
        v_p = ((v_p + 1) % 17);
    }
    return v_served;
}

fn v_inventoryReorder(v_n: i64, v_s: i64) -> i64 {
    var v_stock: i64[>..] = [];
    v_stock.resize(61, 20);
    var v_orders: i64 = 0;
    for v_i in 0..v_n {
        var v_k: i64 = (v_val(v_i, v_s) % 61);
        v_stock[v_k] = v_stock[v_k] - (v_i % 5);
        if (v_stock[v_k] < 5) {
            v_stock[v_k] = v_stock[v_k] + 24;
            v_orders = v_orders + 1;
        }
    }
    return v_orders;
}

fn v_thermostat(v_n: i64, v_s: i64) -> i64 {
    var v_temp: i64 = 190;
    var v_power: i64 = 0;
    var v_consumed: i64 = 0;
    for v_i in 0..v_n {
        if (v_temp < 184) {
            v_power = 1;
        }
        if (v_temp > 211) {
            v_power = 0;
        }
        v_temp = v_temp + ((v_power * 5) - (v_val(v_i, v_s) % 6));
        v_consumed = v_consumed + v_power;
    }
    return v_consumed;
}

fn v_resampleLinear(v_n: i64, v_s: i64) -> i64 {
    var v_a: i64[>..] = [];
    v_a.resize(v_n, 0);
    for ix in 0..v_n {
        v_a[ix] = v_val(ix, v_s);
    }
    var v_t: i64 = 0;
    for v_j in 0..((v_n * 3) - 3) {
        var v_p: i64 = (v_j / 3);
        var v_fraction: i64 = (v_j % 3);
        v_t = v_t + (((v_a[v_p] * (3 - v_fraction)) + (v_a[(v_p + 1)] * v_fraction)) / 3);
    }
    return v_t;
}

fn v_envelopeFollower(v_n: i64, v_s: i64) -> i64 {
    var v_env: i64 = 0;
    var v_t: i64 = 0;
    for v_i in 0..v_n {
        var v_x: i64 = v_val(v_i, v_s);
        if (v_x > v_env) {
            v_env = v_env + (((v_x - v_env) + 1) / 2);
        } else {
            v_env = v_env - ((v_env - v_x) / 8);
        }
        v_t = v_t + v_env;
    }
    return v_t;
}

fn v_telemetryBuckets(v_n: i64, v_s: i64) -> i64 {
    var v_b: i64[>..] = [];
    v_b.resize(11, 0);
    for v_i in 0..v_n {
        var v_v: i64 = (v_val(v_i, v_s) + 1);
        var v_level: i64 = 0;
        while (v_v > 1) {
            v_v = (v_v / 2);
            v_level = v_level + 1;
        }
        v_b[v_level] = v_b[v_level] + 1;
    }
    var v_target: i64 = ((v_n * 9) / 10);
    var v_k: i64 = 0;
    while (v_target > v_b[v_k]) {
        v_target = v_target - v_b[v_k];
        v_k = v_k + 1;
    }
    return v_k;
}

fn v_backoffSimulation(v_n: i64, v_s: i64) -> i64 {
    var v_delay: i64 = 1;
    var v_elapsed: i64 = 0;
    for v_i in 0..v_n {
        if ((v_val(v_i, v_s) % 4) != 0) {
            v_delay = 1;
        } else {
            v_delay = v_low(128, (v_delay * 2));
        }
        v_elapsed = v_elapsed + v_delay;
    }
    return v_elapsed;
}

fn v_packetJitter(v_n: i64, v_s: i64) -> i64 {
    var v_previous: i64 = 0;
    var v_jitter: i64 = 0;
    for v_i in 0..v_n {
        var v_transit: i64 = (v_val(v_i, v_s) % 127);
        var v_delta: i64 = v_dist(v_transit, v_previous);
        v_jitter = (((15 * v_jitter) + (16 * v_delta)) / 16);
        v_previous = v_transit;
    }
    return v_jitter;
}

fn v_dispatch(v_id: i64, v_n: i64, v_s: i64) -> i64 {
    if (v_id == 0) {
        return v_euclidBatch(v_n, v_s);
    }
    if (v_id == 1) {
        return v_primeTrial(v_n, v_s);
    }
    if (v_id == 2) {
        return v_modularPower(v_n, v_s);
    }
    if (v_id == 3) {
        return v_newtonRoot(v_n, v_s);
    }
    if (v_id == 4) {
        return v_digitSum(v_n, v_s);
    }
    if (v_id == 5) {
        return v_binomialRows(v_n, v_s);
    }
    if (v_id == 6) {
        return v_factorMultiplicity(v_n, v_s);
    }
    if (v_id == 7) {
        return v_binaryOnes(v_n, v_s);
    }
    if (v_id == 8) {
        return v_totientBatch(v_n, v_s);
    }
    if (v_id == 9) {
        return v_divisorsPaired(v_n, v_s);
    }
    if (v_id == 10) {
        return v_affineStream(v_n, v_s);
    }
    if (v_id == 11) {
        return v_fibonacciMod(v_n, v_s);
    }
    if (v_id == 12) {
        return v_adlerStream(v_n, v_s);
    }
    if (v_id == 13) {
        return v_polynomialHash(v_n, v_s);
    }
    if (v_id == 14) {
        return v_exponentialFilter(v_n, v_s);
    }
    if (v_id == 15) {
        return v_hysteresis(v_n, v_s);
    }
    if (v_id == 16) {
        return v_longestStreak(v_n, v_s);
    }
    if (v_id == 17) {
        return v_majorityVote(v_n, v_s);
    }
    if (v_id == 18) {
        return v_crossingCount(v_n, v_s);
    }
    if (v_id == 19) {
        return v_cumulativeDrawdown(v_n, v_s);
    }
    if (v_id == 20) {
        return v_insertionSort(v_n, v_s);
    }
    if (v_id == 21) {
        return v_selectionSort(v_n, v_s);
    }
    if (v_id == 22) {
        return v_bubbleEarly(v_n, v_s);
    }
    if (v_id == 23) {
        return v_shellSort(v_n, v_s);
    }
    if (v_id == 24) {
        return v_countingRank(v_n, v_s);
    }
    if (v_id == 25) {
        return v_lowerBound(v_n, v_s);
    }
    if (v_id == 26) {
        return v_sentinelFind(v_n, v_s);
    }
    if (v_id == 27) {
        return v_partitionPivot(v_n, v_s);
    }
    if (v_id == 28) {
        return v_mergeRuns(v_n, v_s);
    }
    if (v_id == 29) {
        return v_heapBuild(v_n, v_s);
    }
    if (v_id == 30) {
        return v_reverseBuffer(v_n, v_s);
    }
    if (v_id == 31) {
        return v_rotateCycles(v_n, v_s);
    }
    if (v_id == 32) {
        return v_strideGather(v_n, v_s);
    }
    if (v_id == 33) {
        return v_permutedScatter(v_n, v_s);
    }
    if (v_id == 34) {
        return v_chainedLoads(v_n, v_s);
    }
    if (v_id == 35) {
        return v_copyIsolation(v_n, v_s);
    }
    if (v_id == 36) {
        return v_scopeChurn(v_n, v_s);
    }
    if (v_id == 37) {
        return v_compactStable(v_n, v_s);
    }
    if (v_id == 38) {
        return v_interleaveBuffers(v_n, v_s);
    }
    if (v_id == 39) {
        return v_sparsePages(v_n, v_s);
    }
    if (v_id == 40) {
        return v_dotProduct(v_n, v_s);
    }
    if (v_id == 41) {
        return v_integerVariance(v_n, v_s);
    }
    if (v_id == 42) {
        return v_frequencyMode(v_n, v_s);
    }
    if (v_id == 43) {
        return v_slidingWindow(v_n, v_s);
    }
    if (v_id == 44) {
        return v_prefixQueries(v_n, v_s);
    }
    if (v_id == 45) {
        return v_minmaxSpan(v_n, v_s);
    }
    if (v_id == 46) {
        return v_normalizedCov(v_n, v_s);
    }
    if (v_id == 47) {
        return v_lowpassMedian(v_n, v_s);
    }
    if (v_id == 48) {
        return v_lagCorrelation(v_n, v_s);
    }
    if (v_id == 49) {
        return v_trimmedThreshold(v_n, v_s);
    }
    if (v_id == 50) {
        return v_matrixMultiply(v_n, v_s);
    }
    if (v_id == 51) {
        return v_matrixTranspose(v_n, v_s);
    }
    if (v_id == 52) {
        return v_fivePoint(v_n, v_s);
    }
    if (v_id == 53) {
        return v_sobelHorizontal(v_n, v_s);
    }
    if (v_id == 54) {
        return v_summedArea(v_n, v_s);
    }
    if (v_id == 55) {
        return v_lifeOneStep(v_n, v_s);
    }
    if (v_id == 56) {
        return v_diagonalEnergy(v_n, v_s);
    }
    if (v_id == 57) {
        return v_triangularSolve(v_n, v_s);
    }
    if (v_id == 58) {
        return v_rowNormalize(v_n, v_s);
    }
    if (v_id == 59) {
        return v_maxPool(v_n, v_s);
    }
    if (v_id == 60) {
        return v_editDistance(v_n, v_s);
    }
    if (v_id == 61) {
        return v_commonSubsequence(v_n, v_s);
    }
    if (v_id == 62) {
        return v_knapsack(v_n, v_s);
    }
    if (v_id == 63) {
        return v_coinMinimum(v_n, v_s);
    }
    if (v_id == 64) {
        return v_increasingSubseq(v_n, v_s);
    }
    if (v_id == 65) {
        return v_gridMinPath(v_n, v_s);
    }
    if (v_id == 66) {
        return v_maxNonAdjacent(v_n, v_s);
    }
    if (v_id == 67) {
        return v_rodCut(v_n, v_s);
    }
    if (v_id == 68) {
        return v_segmentGain(v_n, v_s);
    }
    if (v_id == 69) {
        return v_subsetReach(v_n, v_s);
    }
    if (v_id == 70) {
        return v_unionFind(v_n, v_s);
    }
    if (v_id == 71) {
        return v_fenwickUpdateQuery(v_n, v_s);
    }
    if (v_id == 72) {
        return v_ringQueue(v_n, v_s);
    }
    if (v_id == 73) {
        return v_monotoneStack(v_n, v_s);
    }
    if (v_id == 74) {
        return v_openAddress(v_n, v_s);
    }
    if (v_id == 75) {
        return v_floydDistances(v_n, v_s);
    }
    if (v_id == 76) {
        return v_breadthFirst(v_n, v_s);
    }
    if (v_id == 77) {
        return v_treeFold(v_n, v_s);
    }
    if (v_id == 78) {
        return v_sparseEdges(v_n, v_s);
    }
    if (v_id == 79) {
        return v_intervalSweep(v_n, v_s);
    }
    if (v_id == 80) {
        return v_luhnDigits(v_n, v_s);
    }
    if (v_id == 81) {
        return v_runLengths(v_n, v_s);
    }
    if (v_id == 82) {
        return v_varintLength(v_n, v_s);
    }
    if (v_id == 83) {
        return v_decimalFields(v_n, v_s);
    }
    if (v_id == 84) {
        return v_csvQuoted(v_n, v_s);
    }
    if (v_id == 85) {
        return v_bracketDepth(v_n, v_s);
    }
    if (v_id == 86) {
        return v_utf8Widths(v_n, v_s);
    }
    if (v_id == 87) {
        return v_patternAutomaton(v_n, v_s);
    }
    if (v_id == 88) {
        return v_zigzagDelta(v_n, v_s);
    }
    if (v_id == 89) {
        return v_packedNibbles(v_n, v_s);
    }
    if (v_id == 90) {
        return v_tokenBucket(v_n, v_s);
    }
    if (v_id == 91) {
        return v_orderBookLevel(v_n, v_s);
    }
    if (v_id == 92) {
        return v_roundRobin(v_n, v_s);
    }
    if (v_id == 93) {
        return v_inventoryReorder(v_n, v_s);
    }
    if (v_id == 94) {
        return v_thermostat(v_n, v_s);
    }
    if (v_id == 95) {
        return v_resampleLinear(v_n, v_s);
    }
    if (v_id == 96) {
        return v_envelopeFollower(v_n, v_s);
    }
    if (v_id == 97) {
        return v_telemetryBuckets(v_n, v_s);
    }
    if (v_id == 98) {
        return v_backoffSimulation(v_n, v_s);
    }
    if (v_id == 99) {
        return v_packetJitter(v_n, v_s);
    }
    return 0;
}

fn main() { print(v_dispatch(0, 2, 1)); }
